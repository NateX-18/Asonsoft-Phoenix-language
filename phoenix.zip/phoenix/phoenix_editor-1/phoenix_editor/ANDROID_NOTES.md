# Android / Cxxdroid notes

## 1. `libc++_shared.so` not found

Your `phx` binary was linked against LLVM `libc++`. Android will not start it unless the shared library is loadable.

**Fix:**
1. Find `libc++_shared.so` from your NDK / Cxxdroid toolchain (often under the NDK `sysroot` or Cxxdroid’s lib folder).
2. Copy it **next to** the `phx` executable (same directory).
3. Re-run from the editor. The updated editor sets `LD_LIBRARY_PATH` to the directory containing `phx`.

Example:
```text
/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/phx
/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/libc++_shared.so
```

## 2. `can't access tty; job control turned off`

Harmless with the old interactive shell. The new editor **does not** open an interactive shell for Run — it starts `phx` with `QProcess` directly, so this message should no longer appear when pressing F5/Run.

## 3. Soft keyboard disappears

- Output panel is read-only and does not take focus.
- Tapping the editor focuses it again.
- After Run, focus returns to the editor automatically.

## 4. Side panel stuck open

- Use the **✕** button in the panel header, or tap **☰** again, or tap the dimmed area outside the panel.

## 5. Many tabs

Tab bar uses scroll buttons (`«` `»`) so you can reach tabs that do not fit on screen.
