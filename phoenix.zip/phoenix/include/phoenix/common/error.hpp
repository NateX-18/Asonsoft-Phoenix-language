#ifndef PHOENIX_COMMON_ERROR_HPP
#define PHOENIX_COMMON_ERROR_HPP

#include <string>
#include <vector>
#include <exception>
#include <cstdint>

namespace phoenix {

struct SourceLocation {
    std::string file_path{"<source>"};
    uint32_t line{1};
    uint32_t column{1};

    std::string to_string() const;
};

enum class DiagnosticLevel {
    INFO,
    WARNING,
    ERROR,
    FATAL
};

enum class ErrorCategory {
    LEXER,
    PARSER,
    COMPILER,
    LINKER,
    RUNTIME,
    SANDBOX,
    PMI
};

// Compatible Alias
using ErrorType = ErrorCategory;

struct Diagnostic {
    DiagnosticLevel level;
    ErrorCategory category;
    std::string message;
    SourceLocation location;
};

class PhoenixException : public std::exception {
private:
    std::string full_message;
    ErrorCategory category;
    SourceLocation location;

public:
    PhoenixException(ErrorCategory cat, std::string msg, SourceLocation loc);
    const char* what() const noexcept override { return full_message.c_str(); }

    ErrorCategory get_category() const { return category; }
    SourceLocation get_location() const { return location; }
};

class DiagnosticEngine {
private:
    std::vector<Diagnostic> diagnostics;
    bool has_errors_{false};

public:
    DiagnosticEngine() = default;

    void report(ErrorCategory category, const std::string& message, SourceLocation loc, DiagnosticLevel level = DiagnosticLevel::ERROR);
    void report_error(const std::string& message, SourceLocation loc = { "<source>", 0, 0 });
    void report_warning(const std::string& message, SourceLocation loc = { "<source>", 0, 0 });

    bool has_errors() const { return has_errors_; }
    const std::vector<Diagnostic>& get_diagnostics() const { return diagnostics; }
    void clear();
};

} // namespace phoenix

#endif // PHOENIX_COMMON_ERROR_HPP