#ifndef PHOENIX_COMMON_CONFIG_HPP
#define PHOENIX_COMMON_CONFIG_HPP

#include <string_view>

namespace phoenix {

constexpr uint8_t PHX_VERSION_MAJOR = 1;
constexpr uint8_t PHX_VERSION_MINOR = 1;
constexpr uint8_t PHX_VERSION_PATCH = 0;

constexpr std::string_view PHX_VERSION_STRING = "1.1.0";
constexpr std::string_view PHX_VENDOR = "Asonsoft Phoenix Native Architecture";
constexpr std::string_view PHX_MOTTO = "Dynamic Scripting with Metal Control";
constexpr std::string_view PHX_TARGET_ABI = "PHX-C-ABI-v1";

#if defined(NDEBUG)
constexpr std::string_view PHX_BUILD_CONFIG = "Release";
#else
constexpr std::string_view PHX_BUILD_CONFIG = "Debug";
#endif

} // namespace phoenix

#endif // PHOENIX_COMMON_CONFIG_HPP