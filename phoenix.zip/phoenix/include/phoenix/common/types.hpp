#ifndef PHOENIX_COMMON_TYPES_HPP
#define PHOENIX_COMMON_TYPES_HPP

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <sstream>
#include <cstdint>

namespace phoenix {

enum class ValueType : uint8_t {
    NIL = 0,
    BOOLEAN,
    NUMBER,
    I8,
    I16,
    I32,
    I64,
    U8,
    U16,
    U32,
    U64,
    STRING,
    LIST,
    DICT,
    POINTER
};

using DataType = ValueType;

struct Value;

struct HeapList {
    std::vector<Value> elements;
};

struct HeapDict {
    std::vector<std::string> schema_columns;
    std::string primary_key_column;
    std::unordered_map<std::string, Value> entries;
    std::unordered_map<std::string, std::unordered_map<std::string, Value>> matrix_records;
};

struct Value {
    ValueType type{ValueType::NIL};
    
    union {
        bool boolean;
        double number;
        int64_t i64_val;
        uint64_t u64_val;
        void* pointer;
    } as{0};

    std::string str_val;
    std::shared_ptr<HeapList> list_val{nullptr};
    std::shared_ptr<HeapDict> dict_val{nullptr};

    bool marked{false};

    // Constructors
    Value() : type(ValueType::NIL) {}
    explicit Value(bool b) : type(ValueType::BOOLEAN) { as.boolean = b; }
    explicit Value(double n) : type(ValueType::NUMBER) { as.number = n; }
    explicit Value(int64_t n) : type(ValueType::I64) { as.i64_val = n; }
    explicit Value(uint64_t n) : type(ValueType::U64) { as.u64_val = n; }
    explicit Value(int32_t n) : type(ValueType::I32) { as.i64_val = n; }
    explicit Value(uint32_t n) : type(ValueType::U32) { as.u64_val = n; }
    explicit Value(std::string s) : type(ValueType::STRING), str_val(std::move(s)) {}
    explicit Value(const char* s) : type(ValueType::STRING), str_val(s ? s : "") {}
    explicit Value(std::shared_ptr<HeapList> l) : type(ValueType::LIST), list_val(std::move(l)) {}
    explicit Value(std::shared_ptr<HeapDict> d) : type(ValueType::DICT), dict_val(std::move(d)) {}
    explicit Value(void* ptr) : type(ValueType::POINTER) { as.pointer = ptr; }

    // Static Helpers
    static Value nil() { return Value(); }
    static Value boolean(bool b) { return Value(b); }
    static Value number(double n) { return Value(n); }
    static Value make_i8(int8_t v) { Value val; val.type = ValueType::I8; val.as.i64_val = v; return val; }
    static Value make_i16(int16_t v) { Value val; val.type = ValueType::I16; val.as.i64_val = v; return val; }
    static Value make_i32(int32_t v) { Value val; val.type = ValueType::I32; val.as.i64_val = v; return val; }
    static Value make_i64(int64_t v) { Value val; val.type = ValueType::I64; val.as.i64_val = v; return val; }
    static Value make_u8(uint8_t v) { Value val; val.type = ValueType::U8; val.as.u64_val = v; return val; }
    static Value make_u16(uint16_t v) { Value val; val.type = ValueType::U16; val.as.u64_val = v; return val; }
    static Value make_u32(uint32_t v) { Value val; val.type = ValueType::U32; val.as.u64_val = v; return val; }
    static Value make_u64(uint64_t v) { Value val; val.type = ValueType::U64; val.as.u64_val = v; return val; }
    static Value make_string(const std::string& s) { return Value(s); }
    static Value list(std::shared_ptr<HeapList> l) { return Value(l); }
    static Value dict(std::shared_ptr<HeapDict> d) { return Value(d); }
    static Value make_pointer(void* ptr) { return Value(ptr); }

    // Inspection
    bool is_nil() const { return type == ValueType::NIL; }
    bool is_bool() const { return type == ValueType::BOOLEAN; }
    bool is_number() const { return type == ValueType::NUMBER || is_integer(); }
    bool is_integer() const { 
        return type == ValueType::I8 || type == ValueType::I16 || type == ValueType::I32 || type == ValueType::I64 ||
               type == ValueType::U8 || type == ValueType::U16 || type == ValueType::U32 || type == ValueType::U64; 
    }
    bool is_string() const { return type == ValueType::STRING; }
    bool is_list() const { return type == ValueType::LIST; }
    bool is_dict() const { return type == ValueType::DICT; }
    bool is_pointer() const { return type == ValueType::POINTER; }

    bool is_truthy() const {
        if (type == ValueType::NIL) return false;
        if (type == ValueType::BOOLEAN) return as.boolean;
        if (type == ValueType::NUMBER) return as.number != 0.0;
        if (is_integer()) return as.i64_val != 0 || as.u64_val != 0;
        if (type == ValueType::STRING) return !str_val.empty();
        return true;
    }

    // Accessors
    bool as_bool() const { return as.boolean; }
    double as_number() const { 
        if (type == ValueType::NUMBER) return as.number;
        if (is_integer()) {
            if (type == ValueType::U8 || type == ValueType::U16 || type == ValueType::U32 || type == ValueType::U64) {
                return static_cast<double>(as.u64_val);
            }
            return static_cast<double>(as.i64_val);
        }
        return 0.0;
    }
    int64_t as_i64() const {
        if (type == ValueType::NUMBER) return static_cast<int64_t>(as.number);
        if (type == ValueType::U64 || type == ValueType::U32 || type == ValueType::U16 || type == ValueType::U8) {
            return static_cast<int64_t>(as.u64_val);
        }
        return as.i64_val;
    }
    uint64_t as_u64() const {
        if (type == ValueType::NUMBER) return static_cast<uint64_t>(as.number);
        if (type == ValueType::I64 || type == ValueType::I32 || type == ValueType::I16 || type == ValueType::I8) {
            return static_cast<uint64_t>(as.i64_val);
        }
        return as.u64_val;
    }
    std::string as_string() const { return str_val; }
    std::shared_ptr<HeapList> as_list() const { return list_val; }
    std::shared_ptr<HeapDict> as_dict() const { return dict_val; }
    void* as_pointer() const { return as.pointer; }

    std::string to_string() const;
    bool strict_equals(const Value& other) const;
    void cast_to(const std::string& target_type);

    Value query_primary_key(const Value& pk_val) const;
    void update_cell(const Value& pk_val, const std::string& col_name, const Value& new_val);
};

} // namespace phoenix

#endif // PHOENIX_COMMON_TYPES_HPP