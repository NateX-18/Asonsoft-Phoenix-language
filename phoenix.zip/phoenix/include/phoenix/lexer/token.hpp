#ifndef PHOENIX_LEXER_TOKEN_HPP
#define PHOENIX_LEXER_TOKEN_HPP

#include <string>
#include <utility>
#include <string_view>
#include "../common/types.hpp"
#include "../common/error.hpp"

namespace phoenix {

enum class TokenType;
std::string token_type_to_string(TokenType type);
TokenType lookup_keyword(std::string_view keyword);

enum class TokenType {
    TOKEN_EOF = 0,
    TOKEN_ERROR,
    IDENTIFIER,
    INT_LITERAL,
    FLOAT_LITERAL,
    STRING_LITERAL,

    // Keywords
    KEYWORD_LET,
    KEYWORD_LIST,
    KEYWORD_DICT,
    KEYWORD_DTYPE,
    KEYWORD_STATE,
    KEYWORD_STATE_DTYPE,
    KEYWORD_DEFINE,
    KEYWORD_CLASS,
    KEYWORD_EXTENDS,
    KEYWORD_SYSTEM,
    KEYWORD_STRUCT,
    KEYWORD_MODE,
    KEYWORD_IMPORT,
    KEYWORD_LOAD,
    KEYWORD_RETURN,
    KEYWORD_IF,
    KEYWORD_ELIF,
    KEYWORD_ELSE,
    KEYWORD_WHILE,
    KEYWORD_FOR,
    KEYWORD_FOREVERY,
    KEYWORD_IN,
    KEYWORD_BREAK,
    KEYWORD_CONTINUE,
    KEYWORD_AND,
    KEYWORD_OR,
    KEYWORD_ATTEMPT,
    KEYWORD_FAIL,
    KEYWORD_SUCCESS,
    KEYWORD_ALWAYS,
    KEYWORD_DISPLAY,
    KEYWORD_INPUT,
    KEYWORD_AS,
    KEYWORD_NATIVE,
    KEYWORD_NIL,
    KEYWORD_TRUE,
    KEYWORD_FALSE,
    KEYWORD_ASM,
    KEYWORD_VOLATILE,
    KEYWORD_CONSTANT,

    // Standalone File I/O Keywords
    KEYWORD_OPEN,
    KEYWORD_CLOSE,
    KEYWORD_READ,
    KEYWORD_READLN,
    KEYWORD_WRITE,
    KEYWORD_SEEK,
    KEYWORD_MKDIR,
    KEYWORD_COPY,
    KEYWORD_MOVE,
    KEYWORD_DELETE,

    // Operators & Symbols
    ASSIGN,             // =
    PLUS_ASSIGN,        // +=
    MINUS_ASSIGN,       // -=
    STAR_ASSIGN,        // *=
    SLASH_ASSIGN,       // /=
    PLUS,               // +
    MINUS,              // -
    STAR,               // *
    SLASH,              // /
    PERCENT,            // %
    EQUAL,              // ==
    NOT_EQUAL,          // !=
    LESS,               // <
    LESS_EQUAL,         // <=
    GREATER,            // >
    GREATER_EQUAL,      // >=
    AND,                // &&
    OR,                 // ||
    BANG,               // !
    TYPE_MAP,           // <~>
    STREAM_RIGHT,       // ~>
    STREAM_LEFT,        // <~
    PRIMARY_KEY_QUERY,  // *$
    DOLLAR,             // $
    AT,                 // @
    COLON,              // :
    COMMA,              // ,
    DOT,                // .
    SEMICOLON,          // ;
    LPAREN,             // (
    RPAREN,             // )
    LBRACKET,           // [
    RBRACKET,           // ]
    LBRACE,             // {
    RBRACE              // }
};

struct Token {
    TokenType type;
    std::string lexeme;
    Value literal{Value::nil()};
    SourceLocation location;

    Token() = default;
    Token(TokenType t, std::string l, SourceLocation loc) : type(t), lexeme(std::move(l)), location(std::move(loc)) {}
    Token(TokenType t, std::string l, Value v, SourceLocation loc) : type(t), lexeme(std::move(l)), literal(std::move(v)), location(std::move(loc)) {}

    std::string to_string() const;
};

} // namespace phoenix

#endif // PHOENIX_LEXER_TOKEN_HPP