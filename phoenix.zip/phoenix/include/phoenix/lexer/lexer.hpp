#ifndef PHOENIX_LEXER_LEXER_HPP
#define PHOENIX_LEXER_LEXER_HPP

#include <string>
#include <vector>
#include <string_view>
#include "token.hpp"
#include "../common/error.hpp"

namespace phoenix {

class Lexer {
private:
    std::string source_;
    std::string file_path_;
    DiagnosticEngine& diagnostics_;

    size_t start_{0};
    size_t current_{0};
    uint32_t line_{1};
    uint32_t column_{1};
    uint32_t start_column_{1};

    bool is_at_end() const noexcept { return current_ >= source_.size(); }
    char advance() noexcept;
    char peek() const noexcept;
    char peek_next() const noexcept;
    bool match(char expected) noexcept;

    void skip_whitespace_and_comments();
    Token scan_token();
    Token scan_string(char quote_type);
    Token scan_number();
    Token scan_identifier();

    Token make_token(TokenType type) const;
    Token make_token(TokenType type, Value literal) const;
    Token error_token(const std::string& message);

public:
    explicit Lexer(std::string source, DiagnosticEngine& diagnostics, std::string file_path = "<source>")
        : source_(std::move(source)), file_path_(std::move(file_path)), diagnostics_(diagnostics) {}

    std::vector<Token> tokenize();
};

} // namespace phoenix

#endif // PHOENIX_LEXER_LEXER_HPP