
#ifndef PHOENIX_LINKER_VERIFIER_HPP
#define PHOENIX_LINKER_VERIFIER_HPP

#include <vector>
#include <string>
#include <memory>
#include <cstdint>
#include "../common/error.hpp"
#include "../vm/bytecode.hpp"

namespace phoenix {

struct VerificationResult {
    bool valid{false};
    std::string error_message;
};

class Verifier {
private:
    DiagnosticEngine& m_diagnostics;

public:
    explicit Verifier(DiagnosticEngine& diagnostics);

    VerificationResult verify_chunk(std::shared_ptr<Chunk> chunk);
    bool validate_header(const std::vector<uint8_t>& binary_data);
    static uint32_t compute_checksum(const std::vector<uint8_t>& data);
};

} // namespace phoenix

#endif // PHOENIX_LINKER_VERIFIER_HPP

