
#ifndef PHOENIX_LINKER_LINKER_HPP
#define PHOENIX_LINKER_LINKER_HPP

#include <string>
#include <vector>
#include <memory>
#include <cstdint>
#include "../common/types.hpp"
#include "../common/error.hpp"
#include "../common/config.hpp"
#include "../vm/bytecode.hpp"

namespace phoenix {

class Linker {
private:
    DiagnosticEngine& m_diagnostics;

    void write_header(std::vector<uint8_t>& buffer);
    void serialize_value(std::vector<uint8_t>& buffer, const Value& val);
    Value deserialize_value(const std::vector<uint8_t>& buffer, size_t& offset);

public:
    explicit Linker(DiagnosticEngine& diagnostics);

    bool link_pxc(std::shared_ptr<Chunk> chunk, const std::string& output_path);
    bool link_pxe(std::shared_ptr<Chunk> chunk, const std::string& output_path, const std::string& runtime_path = "");
    std::shared_ptr<Chunk> load_pxc(const std::string& input_path);
    std::shared_ptr<Chunk> load_pxc_from_memory(const std::vector<uint8_t>& buffer);
};

} // namespace phoenix

#endif // PHOENIX_LINKER_LINKER_HPP


