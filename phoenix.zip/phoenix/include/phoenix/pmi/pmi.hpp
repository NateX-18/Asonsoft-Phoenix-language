#ifndef PHOENIX_PMI_PMI_HPP
#define PHOENIX_PMI_PMI_HPP

#include <string>
#include "../common/error.hpp"

namespace phoenix {

struct PackageManifest {
    std::string name;
    std::string version;
};


class PMI {
private:
    DiagnosticEngine& m_diagnostics;

public:
    explicit PMI(DiagnosticEngine& diagnostics) : m_diagnostics(diagnostics) {}

    std::string sanitize_path_param(const std::string& param);
    bool publish_package(const std::string& epkg_file, const std::string& api_token);
    bool fetch_info(const std::string& pkg_name);
    bool unzip_epkg(const std::string& epkg_path, const std::string& target_dir);
    bool zip_directory(const std::string& source_dir, const std::string& output_epkg);
    bool http_download(const std::string& url, const std::string& destination_path);
    bool http_upload(const std::string& url, const std::string& file_path, const std::string& api_token);
    PackageManifest parse_manifest(const std::string& json_path);

    bool init_package(const std::string& pkg_name);
    bool pack_package(const std::string& source_dir, const std::string& output_epkg);
    bool install_package(const std::string& epkg_path);
    bool remove_package(const std::string& pkg_name);
    bool list_installed();
};

} // namespace phoenix

#endif // PHOENIX_PMI_PMI_HPP