
#ifndef PHOENIX_STDLIB_NATIVE_BRIDGE_HPP
#define PHOENIX_STDLIB_NATIVE_BRIDGE_HPP

#include <string>
#include <unordered_map>
#include "../common/error.hpp"
#include "../vm/vm.hpp"

namespace phoenix {

class NativeBridge {
private:
    DiagnosticEngine& m_diagnostics;
    VM& m_vm;
    std::unordered_map<std::string, void*> m_loaded_handles;

public:
    NativeBridge(DiagnosticEngine& diagnostics, VM& vm);
    ~NativeBridge();

    bool load_shared_library(const std::string& module_name, const std::string& library_path);
    bool unload_shared_library(const std::string& module_name);
    void unload_all();
};

} // namespace phoenix

#endif // PHOENIX_STDLIB_NATIVE_BRIDGE_HPP
