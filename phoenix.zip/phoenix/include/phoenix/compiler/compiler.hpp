#ifndef PHOENIX_COMPILER_COMPILER_HPP
#define PHOENIX_COMPILER_COMPILER_HPP

#include <memory>
#include <vector>
#include <string>
#include <cstdint>
#include "../common/error.hpp"
#include "../parser/ast.hpp"
#include "../vm/bytecode.hpp"

namespace phoenix {

struct Local {
    std::string name;
    int depth{-1};
    bool is_captured{false};
};

struct LoopContext {
    size_t start_offset;
    std::vector<size_t> break_jumps;
};

enum class FunctionType {
    TYPE_SCRIPT,
    TYPE_FUNCTION,
    TYPE_METHOD,
    TYPE_INIT
};

class Compiler : public ASTVisitor {
private:
    DiagnosticEngine& m_diagnostics;
    std::shared_ptr<Chunk> m_current_chunk;
    std::vector<Local> m_locals;
    std::vector<LoopContext> m_loop_stack;
    std::vector<std::shared_ptr<Chunk>> m_sub_chunks;
    int m_scope_depth{0};
    FunctionType m_function_type{FunctionType::TYPE_SCRIPT};

    void emit_byte(uint8_t byte, uint32_t line = 0, uint32_t col = 0);
    void emit_op(OpCode op, uint32_t line = 0, uint32_t col = 0);
    void emit_constant_index(uint16_t idx, uint32_t line = 0, uint32_t col = 0);
    size_t emit_jump(OpCode op, uint32_t line = 0, uint32_t col = 0);
    void patch_jump(size_t offset);
    void emit_loop(size_t loop_start, uint32_t line = 0, uint32_t col = 0);
    uint16_t make_constant(Value value);

    void begin_scope();
    void end_scope();
    void declare_variable(const std::string& name, uint32_t line, uint32_t col);
    int resolve_local(const std::string& name);

public:
    explicit Compiler(DiagnosticEngine& diagnostics);

    std::shared_ptr<Chunk> compile(const ProgramAST& program);

    void visit(LiteralExprAST* node) override;
    void visit(IdentifierExprAST* node) override;
    void visit(ListLiteralExprAST* node) override;
    void visit(DictLiteralExprAST* node) override;
    void visit(UnaryExprAST* node) override;
    void visit(BinaryExprAST* node) override;
    void visit(AssignExprAST* node) override;
    void visit(CallExprAST* node) override;
    void visit(NativeCallExprAST* node) override;
    void visit(MemberExprAST* node) override;
    void visit(IndexExprAST* node) override;
    void visit(TypeMapExprAST* node) override;
    void visit(TableKeyExprAST* node) override;
    void visit(PrimaryKeyQueryExprAST* node) override;
    void visit(InputExprAST* node) override;

    void visit(ExprStmtAST* node) override;
    void visit(VarDeclStmtAST* node) override;
    void visit(BulkDeclStmtAST* node) override;
    void visit(DictSchemaAddColStmtAST* node) override;
    void visit(DictStreamUpsertStmtAST* node) override;
    void visit(AsmStmtAST* node) override;
    void visit(BlockStmtAST* node) override;
    void visit(IfStmtAST* node) override;
    void visit(WhileStmtAST* node) override;
    void visit(ForStmtAST* node) override;
    void visit(ForeveryStmtAST* node) override;
    void visit(ReturnStmtAST* node) override;
    void visit(BreakStmtAST* node) override;
    void visit(ContinueStmtAST* node) override;
    void visit(FunctionDeclStmtAST* node) override;
    void visit(ClassDeclStmtAST* node) override;
    void visit(SystemDeclStmtAST* node) override;
    void visit(ModeDeclStmtAST* node) override;
    void visit(ImportStmtAST* node) override;
    void visit(AttemptStmtAST* node) override;
    void visit(DisplayStmtAST* node) override;
};

} // namespace phoenix

#endif // PHOENIX_COMPILER_COMPILER_HPP