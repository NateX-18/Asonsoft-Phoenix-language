#ifndef PHOENIX_COMPILER_OPTIMIZER_HPP
#define PHOENIX_COMPILER_OPTIMIZER_HPP

#include <memory>
#include "../common/error.hpp"
#include "../parser/ast.hpp"
#include "../vm/bytecode.hpp"

namespace phoenix {

class Optimizer {
private:
    DiagnosticEngine& m_diagnostics;

    void fold_constants(ExprPtr& expr);
    void peephole_pass(Chunk& chunk);

public:
    explicit Optimizer(DiagnosticEngine& diagnostics);

    void optimize_ast(ProgramAST& program);
    void optimize_bytecode(std::shared_ptr<Chunk> chunk);
};

} // namespace phoenix

#endif // PHOENIX_COMPILER_OPTIMIZER_HPP