#ifndef PHOENIX_PARSER_PARSER_HPP
#define PHOENIX_PARSER_PARSER_HPP

#include <vector>
#include <memory>
#include <initializer_list>
#include "../lexer/token.hpp"
#include "../common/error.hpp"
#include "ast.hpp"

namespace phoenix {

enum class Precedence {
    NONE = 0,
    ASSIGNMENT,  // = += -= *= /= ~>
    OR,          // or ||
    AND,         // and &&
    EQUALITY,    // == !=
    COMPARISON,  // < > <= >=
    TYPE_MAP,    // <~>
    TERM,        // + -
    FACTOR,      // * / %
    UNARY,       // ! -
    CALL         // . () []
};

class Parser {
private:
    std::vector<Token> tokens_;
    size_t current_{0};
    DiagnosticEngine& diagnostics_;

    const Token& peek() const noexcept;
    const Token& previous() const noexcept;
    bool is_at_end() const noexcept;
    Token advance();
    bool check(TokenType type) const noexcept;
    bool match(TokenType type);
    bool match(std::initializer_list<TokenType> types);
    Token consume(TokenType type, const std::string& message);
    void report_error(const Token& token, const std::string& message);
    void synchronize();

    Precedence get_token_precedence(TokenType type) const noexcept;

    // Parser Expression Routines
    ExprPtr parse_expression(Precedence precedence = Precedence::NONE);
    ExprPtr parse_prefix();
    ExprPtr parse_infix(ExprPtr left, TokenType op_type);
    ExprPtr parse_primary();
    ExprPtr parse_input_expression();

    // Parser Statement Routines
    StmtPtr parse_statement();
    StmtPtr parse_var_decl_statement();
    StmtPtr parse_bulk_decl_statement();
    StmtPtr parse_dict_statement();
    StmtPtr parse_dict_schema_add_col();
    StmtPtr parse_asm_statement();
    StmtPtr parse_block_statement();
    StmtPtr parse_if_statement();
    StmtPtr parse_while_statement();
    StmtPtr parse_for_statement();
    StmtPtr parse_forevery_statement();
    StmtPtr parse_function_decl_statement(const std::string& kind = "function");
    StmtPtr parse_class_decl_statement();
    StmtPtr parse_system_decl_statement();
    StmtPtr parse_mode_statement();
    StmtPtr parse_attempt_statement();
    StmtPtr parse_display_statement();
    StmtPtr parse_import_statement();
    StmtPtr parse_expr_statement();

public:
    explicit Parser(std::vector<Token> tokens, DiagnosticEngine& diagnostics)
        : tokens_(std::move(tokens)), diagnostics_(diagnostics) {}

    ProgramAST parse_program();
    ASTNodePtr parse_expression_or_statement();
    bool has_errors() const { return diagnostics_.has_errors(); }
};

} // namespace phoenix

#endif // PHOENIX_PARSER_PARSER_HPP