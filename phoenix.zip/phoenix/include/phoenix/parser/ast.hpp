#ifndef PHOENIX_PARSER_AST_HPP
#define PHOENIX_PARSER_AST_HPP

#include <string>
#include <vector>
#include <memory>
#include "../common/types.hpp"
#include "../lexer/token.hpp"

namespace phoenix {

class LiteralExprAST;
class IdentifierExprAST;
class ListLiteralExprAST;
class DictLiteralExprAST;
class UnaryExprAST;
class BinaryExprAST;
class AssignExprAST;
class CallExprAST;
class NativeCallExprAST;
class MemberExprAST;
class IndexExprAST;
class TypeMapExprAST;
class TableKeyExprAST;
class PrimaryKeyQueryExprAST;
class InputExprAST;

class ExprStmtAST;
class VarDeclStmtAST;
class BulkDeclStmtAST;
class DictSchemaAddColStmtAST;
class DictStreamUpsertStmtAST;
class AsmStmtAST;
class BlockStmtAST;
class IfStmtAST;
class WhileStmtAST;
class ForStmtAST;
class ForeveryStmtAST;
class ReturnStmtAST;
class BreakStmtAST;
class ContinueStmtAST;
class FunctionDeclStmtAST;
class ClassDeclStmtAST;
class SystemDeclStmtAST;
class ModeDeclStmtAST;
class ImportStmtAST;
class AttemptStmtAST;
class DisplayStmtAST;

class ASTVisitor {
public:
    virtual ~ASTVisitor() = default;

    virtual void visit(LiteralExprAST* node) = 0;
    virtual void visit(IdentifierExprAST* node) = 0;
    virtual void visit(ListLiteralExprAST* node) = 0;
    virtual void visit(DictLiteralExprAST* node) = 0;
    virtual void visit(UnaryExprAST* node) = 0;
    virtual void visit(BinaryExprAST* node) = 0;
    virtual void visit(AssignExprAST* node) = 0;
    virtual void visit(CallExprAST* node) = 0;
    virtual void visit(NativeCallExprAST* node) = 0;
    virtual void visit(MemberExprAST* node) = 0;
    virtual void visit(IndexExprAST* node) = 0;
    virtual void visit(TypeMapExprAST* node) = 0;
    virtual void visit(TableKeyExprAST* node) = 0;
    virtual void visit(PrimaryKeyQueryExprAST* node) = 0;
    virtual void visit(InputExprAST* node) = 0;

    virtual void visit(ExprStmtAST* node) = 0;
    virtual void visit(VarDeclStmtAST* node) = 0;
    virtual void visit(BulkDeclStmtAST* node) = 0;
    virtual void visit(DictSchemaAddColStmtAST* node) = 0;
    virtual void visit(DictStreamUpsertStmtAST* node) = 0;
    virtual void visit(AsmStmtAST* node) = 0;
    virtual void visit(BlockStmtAST* node) = 0;
    virtual void visit(IfStmtAST* node) = 0;
    virtual void visit(WhileStmtAST* node) = 0;
    virtual void visit(ForStmtAST* node) = 0;
    virtual void visit(ForeveryStmtAST* node) = 0;
    virtual void visit(ReturnStmtAST* node) = 0;
    virtual void visit(BreakStmtAST* node) = 0;
    virtual void visit(ContinueStmtAST* node) = 0;
    virtual void visit(FunctionDeclStmtAST* node) = 0;
    virtual void visit(ClassDeclStmtAST* node) = 0;
    virtual void visit(SystemDeclStmtAST* node) = 0;
    virtual void visit(ModeDeclStmtAST* node) = 0;
    virtual void visit(ImportStmtAST* node) = 0;
    virtual void visit(AttemptStmtAST* node) = 0;
    virtual void visit(DisplayStmtAST* node) = 0;
};

class ASTNode {
public:
    SourceLocation location;
    explicit ASTNode(SourceLocation loc = { "<source>", 0, 0 }) : location(loc) {}
    virtual ~ASTNode() = default;
    virtual void accept(ASTVisitor* visitor) = 0;
};

using ASTNodePtr = std::unique_ptr<ASTNode>;

class ExprAST : public ASTNode {
public:
    using ASTNode::ASTNode;
};
using ExprPtr = std::unique_ptr<ExprAST>;

class StmtAST : public ASTNode {
public:
    using ASTNode::ASTNode;
};
using StmtPtr = std::unique_ptr<StmtAST>;

class LiteralExprAST : public ExprAST {
public:
    Value value;
    LiteralExprAST(Value val, SourceLocation loc = {}) : ExprAST(loc), value(std::move(val)) {}
    void accept(ASTVisitor* visitor) override;
};

class IdentifierExprAST : public ExprAST {
public:
    std::string name;
    IdentifierExprAST(std::string n, SourceLocation loc = {}) : ExprAST(loc), name(std::move(n)) {}
    void accept(ASTVisitor* visitor) override;
};

class ListLiteralExprAST : public ExprAST {
public:
    std::vector<ExprPtr> elements;
    ListLiteralExprAST(std::vector<ExprPtr> elems, SourceLocation loc = {})
        : ExprAST(loc), elements(std::move(elems)) {}
    void accept(ASTVisitor* visitor) override;
};

class DictLiteralExprAST : public ExprAST {
public:
    std::vector<std::string> schema_columns;
    std::string primary_key;
    std::vector<std::vector<ExprPtr>> rows;
    DictLiteralExprAST(std::vector<std::string> cols, std::string pk, std::vector<std::vector<ExprPtr>> r, SourceLocation loc = {})
        : ExprAST(loc), schema_columns(std::move(cols)), primary_key(std::move(pk)), rows(std::move(r)) {}
    void accept(ASTVisitor* visitor) override;
};

class UnaryExprAST : public ExprAST {
public:
    TokenType op;
    ExprPtr operand;
    UnaryExprAST(TokenType o, ExprPtr op_expr, SourceLocation loc = {})
        : ExprAST(loc), op(o), operand(std::move(op_expr)) {}
    void accept(ASTVisitor* visitor) override;
};

class BinaryExprAST : public ExprAST {
public:
    TokenType op_type;
    std::string op_str;
    ExprPtr left;
    ExprPtr right;
    BinaryExprAST(TokenType o, ExprPtr l, ExprPtr r, SourceLocation loc = {})
        : ExprAST(loc), op_type(o), left(std::move(l)), right(std::move(r)) {}
    void accept(ASTVisitor* visitor) override;
};

class AssignExprAST : public ExprAST {
public:
    std::string name;
    TokenType op;
    ExprPtr value;
    // If non-null, this is a member assignment: object.name = value
    // (e.g. struct.model = model inside new_init__).
    ExprPtr object;

    AssignExprAST(std::string n, TokenType o, ExprPtr v, SourceLocation loc = {})
        : ExprAST(loc), name(std::move(n)), op(o), value(std::move(v)), object(nullptr) {}

    AssignExprAST(ExprPtr obj, std::string n, TokenType o, ExprPtr v, SourceLocation loc = {})
        : ExprAST(loc), name(std::move(n)), op(o), value(std::move(v)), object(std::move(obj)) {}

    void accept(ASTVisitor* visitor) override;
};

class CallExprAST : public ExprAST {
public:
    ExprPtr callee;
    std::vector<ExprPtr> arguments;
    CallExprAST(ExprPtr c, std::vector<ExprPtr> args, SourceLocation loc = {})
        : ExprAST(loc), callee(std::move(c)), arguments(std::move(args)) {}
    void accept(ASTVisitor* visitor) override;
};

class NativeCallExprAST : public ExprAST {
public:
    std::string module_name;
    std::string function_name;
    std::vector<ExprPtr> arguments;
    NativeCallExprAST(std::string mod, std::string fn, std::vector<ExprPtr> args, SourceLocation loc = {})
        : ExprAST(loc), module_name(std::move(mod)), function_name(std::move(fn)), arguments(std::move(args)) {}
    void accept(ASTVisitor* visitor) override;
};

class MemberExprAST : public ExprAST {
public:
    ExprPtr object;
    std::string member;
    MemberExprAST(ExprPtr obj, std::string mem, SourceLocation loc = {})
        : ExprAST(loc), object(std::move(obj)), member(std::move(mem)) {}
    void accept(ASTVisitor* visitor) override;
};

class IndexExprAST : public ExprAST {
public:
    ExprPtr target;
    ExprPtr index;
    IndexExprAST(ExprPtr t, ExprPtr idx, SourceLocation loc = {})
        : ExprAST(loc), target(std::move(t)), index(std::move(idx)) {}
    void accept(ASTVisitor* visitor) override;
};

class TypeMapExprAST : public ExprAST {
public:
    ExprPtr expression;
    std::string target_type;
    TypeMapExprAST(ExprPtr expr, std::string t_type, SourceLocation loc = {})
        : ExprAST(loc), expression(std::move(expr)), target_type(std::move(t_type)) {}
    void accept(ASTVisitor* visitor) override;
};

class TableKeyExprAST : public ExprAST {
public:
    std::string table_name;
    ExprPtr key_expr;
    bool is_primary{false};
    TableKeyExprAST(std::string t_name, ExprPtr k_expr, bool is_pk = false, SourceLocation loc = {})
        : ExprAST(loc), table_name(std::move(t_name)), key_expr(std::move(k_expr)), is_primary(is_pk) {}
    void accept(ASTVisitor* visitor) override;
};

class PrimaryKeyQueryExprAST : public ExprAST {
public:
    std::string dict_name;
    ExprPtr key_expr;
    PrimaryKeyQueryExprAST(std::string d_name, ExprPtr k_expr, SourceLocation loc = {})
        : ExprAST(loc), dict_name(std::move(d_name)), key_expr(std::move(k_expr)) {}
    void accept(ASTVisitor* visitor) override;
};

class InputExprAST : public ExprAST {
public:
    ExprPtr prompt;
    explicit InputExprAST(ExprPtr p = nullptr, SourceLocation loc = {})
        : ExprAST(loc), prompt(std::move(p)) {}
    void accept(ASTVisitor* visitor) override;
};

class ExprStmtAST : public StmtAST {
public:
    ExprPtr expression;
    explicit ExprStmtAST(ExprPtr expr, SourceLocation loc = {})
        : StmtAST(loc), expression(std::move(expr)) {}
    void accept(ASTVisitor* visitor) override;
};

enum class VarDeclKind { LET, LIST, DICT };

class VarDeclStmtAST : public StmtAST {
public:
    VarDeclKind kind{VarDeclKind::LET};
    std::string name;
    ExprPtr initializer;
    std::string type_map_annotation;
    VarDeclStmtAST(VarDeclKind k, std::string n, ExprPtr init, SourceLocation loc = {})
        : StmtAST(loc), kind(k), name(std::move(n)), initializer(std::move(init)) {}
    VarDeclStmtAST(std::string n, ExprPtr init, std::string t_ann = "", SourceLocation loc = {})
        : StmtAST(loc), kind(VarDeclKind::LET), name(std::move(n)), initializer(std::move(init)), type_map_annotation(std::move(t_ann)) {}
    void accept(ASTVisitor* visitor) override;
};

class BulkDeclStmtAST : public StmtAST {
public:
    std::vector<std::string> variables;
    std::string data_type;
    std::string state_modifier;
    bool is_dtype{false};
    bool is_state{false};
    BulkDeclStmtAST(std::vector<std::string> vars, std::string d_type, std::string s_mod, bool is_dt, bool is_st, SourceLocation loc = {})
        : StmtAST(loc), variables(std::move(vars)), data_type(std::move(d_type)), state_modifier(std::move(s_mod)), is_dtype(is_dt), is_state(is_st) {}
    void accept(ASTVisitor* visitor) override;
};

class DictSchemaAddColStmtAST : public StmtAST {
public:
    std::string dict_name;
    std::string col_name;
    DictSchemaAddColStmtAST(std::string d_name, std::string c_name, SourceLocation loc = {})
        : StmtAST(loc), dict_name(std::move(d_name)), col_name(std::move(c_name)) {}
    void accept(ASTVisitor* visitor) override;
};

class DictStreamUpsertStmtAST : public StmtAST {
public:
    std::string dict_name;
    ExprPtr pk_key;
    std::string target_column;
    ExprPtr value_or_row;
    bool is_upsert{false};
    DictStreamUpsertStmtAST(std::string d_name, ExprPtr pk, std::string col, ExprPtr val, bool upsert = true, SourceLocation loc = {})
        : StmtAST(loc), dict_name(std::move(d_name)), pk_key(std::move(pk)), target_column(std::move(col)), value_or_row(std::move(val)), is_upsert(upsert) {}
    void accept(ASTVisitor* visitor) override;
};

class AsmStmtAST : public StmtAST {
public:
    std::vector<std::string> instructions;
    explicit AsmStmtAST(std::vector<std::string> insts, SourceLocation loc = {})
        : StmtAST(loc), instructions(std::move(insts)) {}
    void accept(ASTVisitor* visitor) override;
};

class BlockStmtAST : public StmtAST {
public:
    std::vector<StmtPtr> statements;
    explicit BlockStmtAST(std::vector<StmtPtr> stmts, SourceLocation loc = {})
        : StmtAST(loc), statements(std::move(stmts)) {}
    void accept(ASTVisitor* visitor) override;
};

struct ElifBranchAST {
    ExprPtr condition;
    StmtPtr body;
};

class IfStmtAST : public StmtAST {
public:
    ExprPtr condition;
    StmtPtr then_branch;
    std::vector<ElifBranchAST> elif_branches;
    StmtPtr else_branch;
    IfStmtAST(ExprPtr cond, StmtPtr then_b, std::vector<ElifBranchAST> elif_b, StmtPtr else_b, SourceLocation loc = {})
        : StmtAST(loc), condition(std::move(cond)), then_branch(std::move(then_b)), elif_branches(std::move(elif_b)), else_branch(std::move(else_b)) {}
    void accept(ASTVisitor* visitor) override;
};

class WhileStmtAST : public StmtAST {
public:
    ExprPtr condition;
    StmtPtr body;
    WhileStmtAST(ExprPtr cond, StmtPtr b, SourceLocation loc = {})
        : StmtAST(loc), condition(std::move(cond)), body(std::move(b)) {}
    void accept(ASTVisitor* visitor) override;
};

class ForStmtAST : public StmtAST {
public:
    StmtPtr initializer;
    ExprPtr condition;
    ExprPtr increment;
    StmtPtr body;
    ForStmtAST(StmtPtr init, ExprPtr cond, ExprPtr inc, StmtPtr b, SourceLocation loc = {})
        : StmtAST(loc), initializer(std::move(init)), condition(std::move(cond)), increment(std::move(inc)), body(std::move(b)) {}
    void accept(ASTVisitor* visitor) override;
};

class ForeveryStmtAST : public StmtAST {
public:
    std::string item_var;
    ExprPtr collection;
    StmtPtr body;
    ForeveryStmtAST(std::string item, ExprPtr coll, StmtPtr b, SourceLocation loc = {})
        : StmtAST(loc), item_var(std::move(item)), collection(std::move(coll)), body(std::move(b)) {}
    void accept(ASTVisitor* visitor) override;
};

class ReturnStmtAST : public StmtAST {
public:
    ExprPtr value;
    explicit ReturnStmtAST(ExprPtr val = nullptr, SourceLocation loc = {})
        : StmtAST(loc), value(std::move(val)) {}
    void accept(ASTVisitor* visitor) override;
};

class BreakStmtAST : public StmtAST {
public:
    explicit BreakStmtAST(SourceLocation loc = {}) : StmtAST(loc) {}
    void accept(ASTVisitor* visitor) override;
};

class ContinueStmtAST : public StmtAST {
public:
    explicit ContinueStmtAST(SourceLocation loc = {}) : StmtAST(loc) {}
    void accept(ASTVisitor* visitor) override;
};

class FunctionDeclStmtAST : public StmtAST {
public:
    std::string name;
    std::vector<std::string> parameters;
    std::string return_type_map;
    StmtPtr body;
    ExprPtr interrupt_vector;

    FunctionDeclStmtAST(std::string n, std::vector<std::string> params, std::string ret_map, StmtPtr b, SourceLocation loc = {})
        : StmtAST(loc), name(std::move(n)), parameters(std::move(params)), return_type_map(std::move(ret_map)), body(std::move(b)) {}
    void accept(ASTVisitor* visitor) override;
};

class ClassDeclStmtAST : public StmtAST {
public:
    std::string name;
    std::string parent_class;
    std::vector<std::unique_ptr<FunctionDeclStmtAST>> methods;
    ClassDeclStmtAST(std::string n, std::string parent, std::vector<std::unique_ptr<FunctionDeclStmtAST>> m, SourceLocation loc = {})
        : StmtAST(loc), name(std::move(n)), parent_class(std::move(parent)), methods(std::move(m)) {}
    void accept(ASTVisitor* visitor) override;
};

class SystemDeclStmtAST : public StmtAST {
public:
    std::string name;
    std::string parent_system;
    std::vector<StmtPtr> fields;
    std::vector<std::unique_ptr<FunctionDeclStmtAST>> components;
    SystemDeclStmtAST(std::string n, std::string parent, std::vector<StmtPtr> f, std::vector<std::unique_ptr<FunctionDeclStmtAST>> c, SourceLocation loc = {})
        : StmtAST(loc), name(std::move(n)), parent_system(std::move(parent)), fields(std::move(f)), components(std::move(c)) {}
    void accept(ASTVisitor* visitor) override;
};

class ModeDeclStmtAST : public StmtAST {
public:
    std::string mode_name;
    ModeDeclStmtAST(std::string m, SourceLocation loc = {})
        : StmtAST(loc), mode_name(std::move(m)) {}
    void accept(ASTVisitor* visitor) override;
};

class ImportStmtAST : public StmtAST {
public:
    std::string path;
    std::string alias;
    bool is_load{false};
    ImportStmtAST(std::string p, std::string a, bool load_flag = false, SourceLocation loc = {})
        : StmtAST(loc), path(std::move(p)), alias(std::move(a)), is_load(load_flag) {}
    void accept(ASTVisitor* visitor) override;
};

class AttemptStmtAST : public StmtAST {
public:
    StmtPtr try_block;
    std::string catch_type;
    std::string catch_var;
    StmtPtr catch_block;
    StmtPtr success_block;
    StmtPtr always_block;

    AttemptStmtAST(StmtPtr try_b, std::string c_type, std::string c_var, StmtPtr c_b, StmtPtr s_b, StmtPtr a_b, SourceLocation loc = {})
        : StmtAST(loc), try_block(std::move(try_b)), catch_type(std::move(c_type)), catch_var(std::move(c_var)), catch_block(std::move(c_b)), success_block(std::move(s_b)), always_block(std::move(a_b)) {}
    void accept(ASTVisitor* visitor) override;
};

class DisplayStmtAST : public StmtAST {
public:
    std::vector<ExprPtr> expressions;
    explicit DisplayStmtAST(std::vector<ExprPtr> exprs, SourceLocation loc = {})
        : StmtAST(loc), expressions(std::move(exprs)) {}
    void accept(ASTVisitor* visitor) override;
};

struct ProgramAST {
    std::vector<StmtPtr> statements;
    explicit ProgramAST(std::vector<StmtPtr> stmts) : statements(std::move(stmts)) {}
};

} // namespace phoenix

#endif // PHOENIX_PARSER_AST_HPP