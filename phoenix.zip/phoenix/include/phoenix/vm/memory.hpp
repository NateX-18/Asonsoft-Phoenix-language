
#ifndef PHOENIX_VM_MEMORY_HPP
#define PHOENIX_VM_MEMORY_HPP

#include <vector>
#include <unordered_map>
#include <string>
#include <memory>
#include <cstddef>
#include <cstdint>
#include "../common/types.hpp"

namespace phoenix {

struct ChunkHeader {
    size_t capacity{0};
    size_t used{0};
    ChunkHeader* next{nullptr};
};

class MemoryArena {
private:
    ChunkHeader* m_head{nullptr};
    size_t m_default_chunk_size{1024 * 64}; // 64 KB

    void allocate_chunk(size_t min_size);

public:
    explicit MemoryArena(size_t chunk_size = 1024 * 64);
    ~MemoryArena();

    MemoryArena(const MemoryArena&) = delete;
    MemoryArena& operator=(const MemoryArena&) = delete;

    void* allocate(size_t bytes);
    void reset();
};

class DynamicTableRegistry {
private:
    std::unordered_map<std::string, std::shared_ptr<HeapDict>> m_tables;

public:
    DynamicTableRegistry() = default;

    void register_table(const std::string& table_name, std::shared_ptr<HeapDict> initial_schema = nullptr);
    std::shared_ptr<HeapDict> get_table(const std::string& table_name);
    bool query_and_mutate(const std::string& table_name, const std::string& pattern, const Value& value);
};

class MemoryManager {
private:
    size_t m_allocated_bytes{0};
    size_t m_next_gc_threshold{1024 * 1024}; // 1 MB
    std::vector<Value*> m_heap_objects;

    void mark_value(Value* val);

public:
    MemoryManager();
    ~MemoryManager();

    void track_allocation(size_t bytes);
    Value* allocate_value(Value val);
    void run_garbage_collection(std::vector<Value>& root_stack, std::unordered_map<std::string, Value>& globals);
    
    size_t get_allocated_bytes() const { return m_allocated_bytes; }
};

} // namespace phoenix

#endif // PHOENIX_VM_MEMORY_HPP

