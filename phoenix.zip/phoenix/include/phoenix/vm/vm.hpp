#ifndef PHOENIX_VM_VM_HPP
#define PHOENIX_VM_VM_HPP

#include <vector>
#include <unordered_map>
#include <string>
#include <memory>
#include <functional>
#include <fstream>
#include <cstdint>
#include "../common/types.hpp"
#include "../common/error.hpp"
#include "bytecode.hpp"
#include "memory.hpp"
#include "sandbox.hpp"

namespace phoenix {

// Increased from 2048 → 16384 to support realistic function call depth,
// recursion and expression temporaries without frequent stack overflows.
constexpr size_t PHX_MAX_STACK_SIZE = 16384;

enum class InterpretResult {
    OK,
    COMPILE_ERROR,
    RUNTIME_ERROR
};

struct CallFrame {
    std::shared_ptr<Chunk> chunk;
    size_t ip{0};
    size_t stack_base{0};
};

struct TryFrame {
    size_t catch_ip{0};
    size_t stack_depth{0};
    size_t call_frame_depth{0};
};

class VM {
public:
    using NativeFn = std::function<Value(const std::vector<Value>&, VM&)>;

private:
    DiagnosticEngine& m_diagnostics;
    SandboxEnforcer m_sandbox;
    MemoryManager m_memory_manager;

    std::vector<Value> m_stack;
    std::vector<CallFrame> m_frames;
    std::vector<TryFrame> m_try_stack;
    std::unordered_map<std::string, Value> m_globals;
    std::unordered_map<std::string, std::unordered_map<std::string, NativeFn>> m_native_modules;

    std::unordered_map<uint64_t, std::shared_ptr<std::fstream>> open_files;
    uint64_t next_file_id{1};
    std::string current_mode{"std"};
    size_t m_max_stack_size{PHX_MAX_STACK_SIZE};

    void push(Value val);
    Value pop();
    Value peek(size_t distance = 0) const;

    uint8_t read_byte();
    uint16_t read_short();
    Value read_constant();

    void raise_runtime_error(const std::string& message);
    void init_builtins();
    bool load_external_native_package(const std::string& module_name);

public:
    explicit VM(DiagnosticEngine& diagnostics, SandboxPolicy policy = SandboxPolicy::UNRESTRICTED);
    ~VM();

    VM(const VM&) = delete;
    VM& operator=(const VM&) = delete;

    InterpretResult interpret(std::shared_ptr<Chunk> chunk);
    void set_max_stack_size(size_t n) { m_max_stack_size = n > 256 ? n : 256; }
    size_t max_stack_size() const { return m_max_stack_size; }
    const std::string& mode() const { return current_mode; }
    InterpretResult run();

    void set_global(const std::string& name, Value val);
    Value get_global(const std::string& name);
    void register_native_module(const std::string& mod_name, const std::string& fn_name, NativeFn fn);

    SandboxEnforcer& get_sandbox() { return m_sandbox; }
    DiagnosticEngine& get_diagnostics() { return m_diagnostics; }
};

} // namespace phoenix

#endif // PHOENIX_VM_VM_HPP