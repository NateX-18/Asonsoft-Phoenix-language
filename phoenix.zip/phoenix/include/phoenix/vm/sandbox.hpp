
#ifndef PHOENIX_VM_SANDBOX_HPP
#define PHOENIX_VM_SANDBOX_HPP

#include <string>
#include <vector>
#include <filesystem>
#include "../common/error.hpp"

namespace phoenix {

enum class SandboxPolicy {
    UNRESTRICTED,
    READ_ONLY,
    ISOLATED
};

class SandboxEnforcer {
private:
    DiagnosticEngine& m_diagnostics;
    SandboxPolicy m_policy;
    std::vector<std::string> m_allowed_directories;

    std::string canonicalize_path(const std::string& raw_path);

public:
    SandboxEnforcer(DiagnosticEngine& diagnostics, SandboxPolicy policy = SandboxPolicy::UNRESTRICTED);

    void allow_directory(const std::string& dir_path);
    bool is_path_allowed(const std::string& path) const;
    bool validate_file_access(const std::string& file_path, bool write_access = false);
    bool validate_system_command(const std::string& command);

    void set_policy(SandboxPolicy policy) { m_policy = policy; }
    SandboxPolicy get_policy() const { return m_policy; }
};

} // namespace phoenix

#endif // PHOENIX_VM_SANDBOX_HPP

