#ifndef PHOENIX_VM_BYTECODE_HPP
#define PHOENIX_VM_BYTECODE_HPP

#include <vector>
#include <string>
#include <cstdint>
#include <cstddef>
#include "../common/types.hpp"
#include "../common/error.hpp"

namespace phoenix {

enum class OpCode : uint8_t {
    OP_NOP = 0,
    OP_CONSTANT,
    OP_NIL,
    OP_TRUE,
    OP_FALSE,
    OP_POP,
    OP_DUP,

    OP_DEFINE_GLOBAL,
    OP_GET_GLOBAL,
    OP_SET_GLOBAL,
    OP_GET_LOCAL,
    OP_SET_LOCAL,

    OP_BUILD_LIST,
    OP_BUILD_DICT,
    OP_GET_INDEX,
    OP_SET_INDEX,
    OP_GET_PROPERTY,
    OP_SET_PROPERTY,

    OP_QUERY_TABLE,
    OP_MUTATE_TABLE,
    OP_TYPE_CAST,
    OP_INPUT,
    OP_ADD_COLUMN,
    OP_UPSERT_ROW,
    OP_ASM,
    OP_MODE,

    OP_ADD,
    OP_SUBTRACT,
    OP_MULTIPLY,
    OP_DIVIDE,
    OP_MODULO,
    OP_NEGATE,

    OP_NOT,
    OP_EQUAL,
    OP_NOT_EQUAL,
    OP_GREATER,
    OP_GREATER_EQUAL,
    OP_LESS,
    OP_LESS_EQUAL,
    OP_BIT_AND,
    OP_BIT_OR,
    OP_BIT_XOR,
    OP_BIT_NOT,

    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_LOOP,

    OP_CALL,
    OP_INVOKE_NATIVE,
    OP_RETURN,

    OP_PUSH_TRY,
    OP_POP_TRY,
    OP_RAISE,
    OP_SYSTEM_CMD,

    OP_LOAD_SCRIPT,
    OP_IMPORT_MODULE,

    OP_CLASS,
    OP_METHOD,
    OP_SYSTEM,
    OP_INHERIT,
    OP_HALT
};

struct Chunk {
    std::vector<uint8_t> code;
    std::vector<Value> constants;
    std::vector<SourceLocation> debug_lines;
    std::string source_name{"<chunk>"};

    // Owns nested function / method chunks so their bytecode stays alive
    // as long as this chunk (or any Value pointing into it) is alive.
    std::vector<std::shared_ptr<Chunk>> child_chunks;

    void write(uint8_t byte, uint32_t line = 0, uint32_t col = 0) {
        code.push_back(byte);
        debug_lines.push_back(SourceLocation{source_name, line, col});
    }

    void write_op(OpCode op, uint32_t line = 0, uint32_t col = 0) {
        write(static_cast<uint8_t>(op), line, col);
    }

    uint16_t add_constant(Value value) {
        constants.push_back(std::move(value));
        return static_cast<uint16_t>(constants.size() - 1);
    }

    void add_child_chunk(std::shared_ptr<Chunk> child) {
        if (child) child_chunks.push_back(std::move(child));
    }

    void disassemble(const std::string& name) const;
    size_t disassemble_instruction(size_t offset) const;
};

} // namespace phoenix

#endif // PHOENIX_VM_BYTECODE_HPP