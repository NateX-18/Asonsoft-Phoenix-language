#ifndef PHOENIX_C_API_H
#define PHOENIX_C_API_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct PhxVM PhxVM;
typedef struct PhxValue PhxValue;

typedef enum {
    PHX_TYPE_NIL = 0,
    PHX_TYPE_BOOL,
    PHX_TYPE_NUMBER,
    PHX_TYPE_I8,
    PHX_TYPE_I16,
    PHX_TYPE_I32,
    PHX_TYPE_I64,
    PHX_TYPE_U8,
    PHX_TYPE_U16,
    PHX_TYPE_U32,
    PHX_TYPE_U64,
    PHX_TYPE_STRING,
    PHX_TYPE_LIST,
    PHX_TYPE_DICT,
    PHX_TYPE_POINTER
} PhxValueType;

typedef PhxValue* (*PhxNativeFunc)(PhxVM* vm, int arg_count, PhxValue** args);

// Value Allocation & Memory Lifecycle
PhxValue* phx_value_nil(void);
PhxValue* phx_value_bool(bool val);
PhxValue* phx_value_number(double val);
PhxValue* phx_value_i32(int32_t val);
PhxValue* phx_value_i64(int64_t val);
PhxValue* phx_value_u32(uint32_t val);
PhxValue* phx_value_u64(uint64_t val);
PhxValue* phx_value_string(const char* str);
void phx_value_free(PhxValue* val);

// Value Inspection & Conversions
PhxValueType phx_value_get_type(const PhxValue* val);
bool phx_value_to_bool(const PhxValue* val);
double phx_value_to_number(const PhxValue* val);
int64_t phx_value_to_i64(const PhxValue* val);
uint64_t phx_value_to_u64(const PhxValue* val);
const char* phx_value_to_string(const PhxValue* val);

// Engine VM State Control & Execution
PhxVM* phx_vm_create(void);
void phx_vm_destroy(PhxVM* vm);
bool phx_vm_eval_string(PhxVM* vm, const char* code);
bool phx_vm_run_file(PhxVM* vm, const char* filepath);
void phx_register_native_function(PhxVM* vm, const char* module_name, const char* function_name, PhxNativeFunc fn);

#ifdef __cplusplus
}
#endif

#endif // PHOENIX_C_API_H