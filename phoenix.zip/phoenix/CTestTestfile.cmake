# CMake generated Testfile for 
# Source directory: /storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed
# Build directory: /storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
