// libphx_utils — general utility helpers for Phoenix
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"
#include <algorithm>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

using namespace phoenix;

extern "C" void phoenix_module_init(VM* vm) {
    if (!vm) return;

    vm->register_native_module("utils", "upper", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string s = args[0].to_string();
        std::transform(s.begin(), s.end(), s.begin(), ::toupper);
        return Value::make_string(s);
    });
    vm->register_native_module("utils", "lower", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string s = args[0].to_string();
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        return Value::make_string(s);
    });
    vm->register_native_module("utils", "trim", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string s = args[0].to_string();
        size_t start = s.find_first_not_of(" \t\n\r");
        if (start == std::string::npos) return Value::make_string("");
        size_t end = s.find_last_not_of(" \t\n\r");
        return Value::make_string(s.substr(start, end - start + 1));
    });
    vm->register_native_module("utils", "len", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(0);
        const Value& v = args[0];
        if (v.is_string()) return Value::make_i64((int64_t)v.as_string().size());
        if (v.is_list() && v.as_list()) return Value::make_i64((int64_t)v.as_list()->elements.size());
        if (v.is_dict() && v.as_dict()) return Value::make_i64((int64_t)v.as_dict()->entries.size());
        return Value::make_i64(0);
    });
    vm->register_native_module("utils", "split", [](const std::vector<Value>& args, VM&) {
        auto list = std::make_shared<HeapList>();
        if (args.empty()) return Value::list(list);
        std::string s = args[0].to_string();
        std::string delim = args.size() > 1 ? args[1].to_string() : " ";
        if (delim.empty()) delim = " ";
        size_t pos = 0;
        while (true) {
            size_t found = s.find(delim, pos);
            if (found == std::string::npos) {
                list->elements.push_back(Value::make_string(s.substr(pos)));
                break;
            }
            list->elements.push_back(Value::make_string(s.substr(pos, found - pos)));
            pos = found + delim.size();
        }
        return Value::list(list);
    });
    vm->register_native_module("utils", "join", [](const std::vector<Value>& args, VM&) {
        if (args.empty() || !args[0].is_list() || !args[0].as_list()) return Value::make_string("");
        std::string delim = args.size() > 1 ? args[1].to_string() : "";
        std::ostringstream oss;
        auto& elems = args[0].as_list()->elements;
        for (size_t i = 0; i < elems.size(); ++i) {
            if (i) oss << delim;
            oss << elems[i].to_string();
        }
        return Value::make_string(oss.str());
    });
    vm->register_native_module("utils", "contains", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        return Value::boolean(args[0].to_string().find(args[1].to_string()) != std::string::npos);
    });
    vm->register_native_module("utils", "replace", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 3) return args.empty() ? Value::make_string("") : Value::make_string(args[0].to_string());
        std::string s = args[0].to_string();
        std::string from = args[1].to_string();
        std::string to = args[2].to_string();
        if (from.empty()) return Value::make_string(s);
        size_t pos = 0;
        while ((pos = s.find(from, pos)) != std::string::npos) {
            s.replace(pos, from.size(), to);
            pos += to.size();
        }
        return Value::make_string(s);
    });
}
