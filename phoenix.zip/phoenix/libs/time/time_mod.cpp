// libphx_time — comprehensive time & date module for Phoenix
// Usage: @time.now(), @time.format(...), import time, etc.
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"
#include <chrono>
#include <ctime>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <thread>
#include <cstring>
#include <map>
#include <vector>
#include <string>

using namespace phoenix;

namespace phoenix {

namespace {

std::map<int64_t, std::chrono::steady_clock::time_point> g_timers;
int64_t g_next_timer_id = 1;

std::tm local_tm_from_epoch(int64_t epoch) {
    std::time_t t = static_cast<std::time_t>(epoch);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    return tm;
}

std::tm utc_tm_from_epoch(int64_t epoch) {
    std::time_t t = static_cast<std::time_t>(epoch);
    std::tm tm{};
#if defined(_WIN32)
    gmtime_s(&tm, &t);
#else
    gmtime_r(&t, &tm);
#endif
    return tm;
}

int64_t epoch_now() {
    return static_cast<int64_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

int64_t epoch_ms_now() {
    return static_cast<int64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

int64_t epoch_us_now() {
    return static_cast<int64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

std::string strftime_fmt(const std::tm& tm, const char* fmt) {
    char buf[512];
    if (std::strftime(buf, sizeof(buf), fmt, &tm) == 0) return "";
    return std::string(buf);
}

bool is_leap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

} // namespace

void register_phx_time_module(VM* vm) {
    if (!vm) return;

    // ---- clocks & timestamps ----
    vm->register_native_module("time", "now", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(epoch_now());
    });
    vm->register_native_module("time", "time", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(epoch_now());
    });
    vm->register_native_module("time", "timestamp", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(epoch_now());
    });
    vm->register_native_module("time", "millis", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(epoch_ms_now());
    });
    vm->register_native_module("time", "micros", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(epoch_us_now());
    });
    vm->register_native_module("time", "nanos", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(static_cast<int64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count()));
    });
    vm->register_native_module("time", "clock", [](const std::vector<Value>&, VM&) {
        // monotonic seconds as float
        auto ns = std::chrono::steady_clock::now().time_since_epoch();
        double s = std::chrono::duration<double>(ns).count();
        return Value::number(s);
    });
    vm->register_native_module("time", "monotonic", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(static_cast<int64_t>(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count()));
    });
    vm->register_native_module("time", "perf_counter", [](const std::vector<Value>&, VM&) {
        auto ns = std::chrono::high_resolution_clock::now().time_since_epoch();
        return Value::number(std::chrono::duration<double>(ns).count());
    });

    // ---- sleep ----
    vm->register_native_module("time", "sleep", [](const std::vector<Value>& args, VM&) {
        double sec = args.empty() ? 0.0 : args[0].as_number();
        if (sec < 0) sec = 0;
        std::this_thread::sleep_for(std::chrono::duration<double>(sec));
        return Value::nil();
    });
    vm->register_native_module("time", "msleep", [](const std::vector<Value>& args, VM&) {
        int64_t ms = args.empty() ? 0 : args[0].as_i64();
        if (ms < 0) ms = 0;
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
        return Value::nil();
    });
    vm->register_native_module("time", "usleep", [](const std::vector<Value>& args, VM&) {
        int64_t us = args.empty() ? 0 : args[0].as_i64();
        if (us < 0) us = 0;
        std::this_thread::sleep_for(std::chrono::microseconds(us));
        return Value::nil();
    });

    // ---- calendar components (local) ----
    auto component = [](const std::vector<Value>& args, int field) -> Value {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        std::tm tm = local_tm_from_epoch(ep);
        switch (field) {
            case 0: return Value::make_i64(tm.tm_year + 1900);
            case 1: return Value::make_i64(tm.tm_mon + 1);
            case 2: return Value::make_i64(tm.tm_mday);
            case 3: return Value::make_i64(tm.tm_hour);
            case 4: return Value::make_i64(tm.tm_min);
            case 5: return Value::make_i64(tm.tm_sec);
            case 6: return Value::make_i64(tm.tm_wday);      // 0=Sun
            case 7: return Value::make_i64(tm.tm_yday + 1);  // 1..366
            case 8: return Value::boolean(tm.tm_isdst > 0);
            default: return Value::nil();
        }
    };
    vm->register_native_module("time", "year", [component](const std::vector<Value>& a, VM&) { return component(a, 0); });
    vm->register_native_module("time", "month", [component](const std::vector<Value>& a, VM&) { return component(a, 1); });
    vm->register_native_module("time", "day", [component](const std::vector<Value>& a, VM&) { return component(a, 2); });
    vm->register_native_module("time", "hour", [component](const std::vector<Value>& a, VM&) { return component(a, 3); });
    vm->register_native_module("time", "minute", [component](const std::vector<Value>& a, VM&) { return component(a, 4); });
    vm->register_native_module("time", "second", [component](const std::vector<Value>& a, VM&) { return component(a, 5); });
    vm->register_native_module("time", "weekday", [component](const std::vector<Value>& a, VM&) { return component(a, 6); });
    vm->register_native_module("time", "yearday", [component](const std::vector<Value>& a, VM&) { return component(a, 7); });
    vm->register_native_module("time", "isdst", [component](const std::vector<Value>& a, VM&) { return component(a, 8); });

    vm->register_native_module("time", "isleap", [](const std::vector<Value>& args, VM&) {
        int year = args.empty() ? local_tm_from_epoch(epoch_now()).tm_year + 1900
                                : static_cast<int>(args[0].as_i64());
        return Value::boolean(is_leap(year));
    });

    vm->register_native_module("time", "days_in_month", [](const std::vector<Value>& args, VM&) {
        int year = args.size() > 0 ? static_cast<int>(args[0].as_i64()) : local_tm_from_epoch(epoch_now()).tm_year + 1900;
        int month = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : local_tm_from_epoch(epoch_now()).tm_mon + 1;
        static const int dim[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
        if (month < 1 || month > 12) return Value::make_i64(0);
        int d = dim[month];
        if (month == 2 && is_leap(year)) d = 29;
        return Value::make_i64(d);
    });

    // ---- formatting ----
    vm->register_native_module("time", "format", [](const std::vector<Value>& args, VM&) {
        std::string fmt = args.size() > 0 ? args[0].to_string() : "%Y-%m-%d %H:%M:%S";
        int64_t ep = args.size() > 1 ? args[1].as_i64() : epoch_now();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), fmt.c_str()));
    });
    vm->register_native_module("time", "format_utc", [](const std::vector<Value>& args, VM&) {
        std::string fmt = args.size() > 0 ? args[0].to_string() : "%Y-%m-%dT%H:%M:%SZ";
        int64_t ep = args.size() > 1 ? args[1].as_i64() : epoch_now();
        return Value::make_string(strftime_fmt(utc_tm_from_epoch(ep), fmt.c_str()));
    });
    vm->register_native_module("time", "iso8601", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(utc_tm_from_epoch(ep), "%Y-%m-%dT%H:%M:%SZ"));
    });
    vm->register_native_module("time", "rfc2822", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(utc_tm_from_epoch(ep), "%a, %d %b %Y %H:%M:%S GMT"));
    });
    vm->register_native_module("time", "date", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%Y-%m-%d"));
    });
    vm->register_native_module("time", "datetime", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%Y-%m-%d %H:%M:%S"));
    });
    vm->register_native_module("time", "time_of_day", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%H:%M:%S"));
    });
    vm->register_native_module("time", "ctime", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        std::time_t t = static_cast<std::time_t>(ep);
        char* s = std::ctime(&t);
        std::string out = s ? s : "";
        if (!out.empty() && out.back() == '\n') out.pop_back();
        return Value::make_string(out);
    });

    // ---- construct from parts ----
    vm->register_native_module("time", "mktime", [](const std::vector<Value>& args, VM&) {
        // mktime(year, month, day, hour=0, min=0, sec=0)
        std::tm tm{};
        tm.tm_year = (args.size() > 0 ? static_cast<int>(args[0].as_i64()) : 1970) - 1900;
        tm.tm_mon  = (args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 1) - 1;
        tm.tm_mday = args.size() > 2 ? static_cast<int>(args[2].as_i64()) : 1;
        tm.tm_hour = args.size() > 3 ? static_cast<int>(args[3].as_i64()) : 0;
        tm.tm_min  = args.size() > 4 ? static_cast<int>(args[4].as_i64()) : 0;
        tm.tm_sec  = args.size() > 5 ? static_cast<int>(args[5].as_i64()) : 0;
        tm.tm_isdst = -1;
        std::time_t t = std::mktime(&tm);
        return Value::make_i64(static_cast<int64_t>(t));
    });
    vm->register_native_module("time", "from_epoch", [](const std::vector<Value>& args, VM&) {
        return Value::make_i64(args.empty() ? 0 : args[0].as_i64());
    });

    // ---- arithmetic ----
    vm->register_native_module("time", "add_seconds", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.size() > 0 ? args[0].as_i64() : epoch_now();
        int64_t sec = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(ep + sec);
    });
    vm->register_native_module("time", "add_minutes", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.size() > 0 ? args[0].as_i64() : epoch_now();
        int64_t n = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(ep + n * 60);
    });
    vm->register_native_module("time", "add_hours", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.size() > 0 ? args[0].as_i64() : epoch_now();
        int64_t n = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(ep + n * 3600);
    });
    vm->register_native_module("time", "add_days", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.size() > 0 ? args[0].as_i64() : epoch_now();
        int64_t n = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(ep + n * 86400);
    });
    vm->register_native_module("time", "add_weeks", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.size() > 0 ? args[0].as_i64() : epoch_now();
        int64_t n = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(ep + n * 604800);
    });
    vm->register_native_module("time", "diff", [](const std::vector<Value>& args, VM&) {
        int64_t a = args.size() > 0 ? args[0].as_i64() : 0;
        int64_t b = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64(a - b);
    });
    vm->register_native_module("time", "diff_days", [](const std::vector<Value>& args, VM&) {
        int64_t a = args.size() > 0 ? args[0].as_i64() : 0;
        int64_t b = args.size() > 1 ? args[1].as_i64() : 0;
        return Value::make_i64((a - b) / 86400);
    });
    vm->register_native_module("time", "compare", [](const std::vector<Value>& args, VM&) {
        int64_t a = args.size() > 0 ? args[0].as_i64() : 0;
        int64_t b = args.size() > 1 ? args[1].as_i64() : 0;
        if (a < b) return Value::make_i64(-1);
        if (a > b) return Value::make_i64(1);
        return Value::make_i64(0);
    });

    // ---- timezone helpers ----
    vm->register_native_module("time", "timezone", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_string("local");
#else
        const char* tz = std::getenv("TZ");
        if (tz && *tz) return Value::make_string(tz);
        return Value::make_string(strftime_fmt(local_tm_from_epoch(epoch_now()), "%Z"));
#endif
    });
    vm->register_native_module("time", "utc_offset", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        std::tm local = local_tm_from_epoch(ep);
        std::tm utc = utc_tm_from_epoch(ep);
        // approximate offset in seconds
        std::mktime(&local);
        // Approximate: difference between local and UTC representations
        std::tm local2 = local;
        std::tm utc2 = utc;
        local2.tm_isdst = -1;
        utc2.tm_isdst = 0;
        std::time_t tl2 = std::mktime(&local2);
        // Build UTC as if it were local without DST
        std::tm fake = utc2;
        fake.tm_isdst = 0;
        std::time_t tu2 = std::mktime(&fake);
        // Correct by timezone offset is hard portably; return 0 on failure
        if (tl2 == -1 || tu2 == -1) return Value::make_i64(0);
        return Value::make_i64(static_cast<int64_t>(tl2 - tu2));
    });

    // ---- stopwatch / timers ----
    vm->register_native_module("time", "timer_start", [](const std::vector<Value>&, VM&) {
        int64_t id = g_next_timer_id++;
        g_timers[id] = std::chrono::steady_clock::now();
        return Value::make_i64(id);
    });
    vm->register_native_module("time", "timer_elapsed", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        int64_t id = args[0].as_i64();
        auto it = g_timers.find(id);
        if (it == g_timers.end()) return Value::number(0);
        auto dur = std::chrono::steady_clock::now() - it->second;
        return Value::number(std::chrono::duration<double>(dur).count());
    });
    vm->register_native_module("time", "timer_elapsed_ms", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(0);
        int64_t id = args[0].as_i64();
        auto it = g_timers.find(id);
        if (it == g_timers.end()) return Value::make_i64(0);
        auto dur = std::chrono::steady_clock::now() - it->second;
        return Value::make_i64(std::chrono::duration_cast<std::chrono::milliseconds>(dur).count());
    });
    vm->register_native_module("time", "timer_stop", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        int64_t id = args[0].as_i64();
        auto it = g_timers.find(id);
        if (it == g_timers.end()) return Value::number(0);
        auto dur = std::chrono::steady_clock::now() - it->second;
        double sec = std::chrono::duration<double>(dur).count();
        g_timers.erase(it);
        return Value::number(sec);
    });

    // ---- weekday / month names ----
    vm->register_native_module("time", "weekday_name", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%A"));
    });
    vm->register_native_module("time", "weekday_abbr", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%a"));
    });
    vm->register_native_module("time", "month_name", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%B"));
    });
    vm->register_native_module("time", "month_abbr", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        return Value::make_string(strftime_fmt(local_tm_from_epoch(ep), "%b"));
    });

    // ---- breakdown dict ----
    vm->register_native_module("time", "breakdown", [](const std::vector<Value>& args, VM&) {
        int64_t ep = args.empty() ? epoch_now() : args[0].as_i64();
        std::tm tm = local_tm_from_epoch(ep);
        auto d = std::make_shared<HeapDict>();
        d->entries["year"] = Value::make_i64(tm.tm_year + 1900);
        d->entries["month"] = Value::make_i64(tm.tm_mon + 1);
        d->entries["day"] = Value::make_i64(tm.tm_mday);
        d->entries["hour"] = Value::make_i64(tm.tm_hour);
        d->entries["minute"] = Value::make_i64(tm.tm_min);
        d->entries["second"] = Value::make_i64(tm.tm_sec);
        d->entries["weekday"] = Value::make_i64(tm.tm_wday);
        d->entries["yearday"] = Value::make_i64(tm.tm_yday + 1);
        d->entries["epoch"] = Value::make_i64(ep);
        return Value::dict(d);
    });
}

} // namespace phoenix

#if defined(PHX_MODULE_SHARED)
extern "C" void phoenix_module_init(VM* vm) {
    phoenix::register_phx_time_module(vm);
}
#endif
