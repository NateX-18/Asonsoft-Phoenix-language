// libphx_packager — package Phoenix .pxc bytecode for distribution
//
// Windows .exe layout:
//   [stub PE — usually Windows phx.exe] + [raw .pxc] + [40-byte footer]
//
// Footer (little-endian, 40 bytes):
//   magic[8] = "PHXPAYLD"
//   version  = u32 (1)
//   flags    = u32 (bit0 = payload-only, no stub)
//   offset   = u64 (pxc offset from start of file)
//   size     = u64 (pxc size)
//   crc32    = u32 (CRC-32 of pxc)
//   reserved = u32 (0)
//
// Functions:
//   @packager.pxc_to_exe(pxc, out_exe, stub_path?)
//   @packager.pxc_to_pxe(pxc, out_pxe)
//   @packager.pxc_to_sh(pxc, out_sh)
//   @packager.pxc_to_bat(pxc, out_bat)
//   @packager.verify(path)
//   @packager.info(path)
//   @packager.extract_pxc(path, out_pxc)
//   @packager.version()
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"

#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace phoenix;
namespace fs = std::filesystem;

namespace phoenix {
namespace {

#pragma pack(push, 1)
struct PayloadFooter {
    char     magic[8];
    uint32_t version;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
    uint32_t crc32;
    uint32_t reserved;
};
#pragma pack(pop)

uint32_t crc32_bytes(const std::vector<uint8_t>& bytes) {
    uint32_t crc = 0xFFFFFFFFu;
    for (uint8_t b : bytes) {
        crc ^= b;
        for (int i = 0; i < 8; ++i) {
            uint32_t mask = -(crc & 1u);
            crc = (crc >> 1) ^ (0xEDB88320u & mask);
        }
    }
    return ~crc;
}

bool read_file_bytes(const std::string& path, std::vector<uint8_t>& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    out.assign(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
    return true;
}

bool write_file_bytes(const std::string& path, const std::vector<uint8_t>& data) {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(data.data()),
              static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(out);
}

std::string base64_encode(const std::vector<uint8_t>& bytes) {
    static const char* table =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    int val = 0, valb = -6;
    for (uint8_t c : bytes) {
        val = (val << 8) + c;
        valb += 8;
        while (valb >= 0) {
            out.push_back(table[(val >> valb) & 0x3F]);
            valb -= 6;
        }
    }
    if (valb > -6) out.push_back(table[((val << 8) >> (valb + 8)) & 0x3F]);
    while (out.size() % 4) out.push_back('=');
    return out;
}

bool write_footer_package(const std::string& stub_path,
                          const std::string& pxc_path,
                          const std::string& out_path) {
    std::vector<uint8_t> stub;
    std::vector<uint8_t> pxc;
    if (!stub_path.empty()) {
        if (!read_file_bytes(stub_path, stub)) return false;
    }
    if (!read_file_bytes(pxc_path, pxc)) return false;
    if (pxc.size() < 4) return false;

    std::vector<uint8_t> out;
    out.reserve(stub.size() + pxc.size() + sizeof(PayloadFooter));
    out.insert(out.end(), stub.begin(), stub.end());
    uint64_t offset = static_cast<uint64_t>(out.size());
    out.insert(out.end(), pxc.begin(), pxc.end());

    PayloadFooter foot{};
    std::memcpy(foot.magic, "PHXPAYLD", 8);
    foot.version = 1;
    foot.flags = stub.empty() ? 1u : 0u;
    foot.offset = offset;
    foot.size = static_cast<uint64_t>(pxc.size());
    foot.crc32 = crc32_bytes(pxc);
    foot.reserved = 0;

    const uint8_t* fp = reinterpret_cast<const uint8_t*>(&foot);
    out.insert(out.end(), fp, fp + sizeof(foot));
    return write_file_bytes(out_path, out);
}

bool read_footer(const std::string& path, PayloadFooter& foot, std::vector<uint8_t>& file) {
    if (!read_file_bytes(path, file)) return false;
    if (file.size() < sizeof(PayloadFooter)) return false;
    std::memcpy(&foot, file.data() + file.size() - sizeof(PayloadFooter), sizeof(PayloadFooter));
    if (std::memcmp(foot.magic, "PHXPAYLD", 8) != 0) return false;
    if (foot.version != 1) return false;
    if (foot.offset + foot.size + sizeof(PayloadFooter) > file.size()) return false;
    return true;
}

bool write_unix_launcher(const std::string& pxc_path, const std::string& out_path) {
    std::vector<uint8_t> bytes;
    if (!read_file_bytes(pxc_path, bytes)) return false;
    std::string b64 = base64_encode(bytes);
    std::ofstream out(out_path, std::ios::binary);
    if (!out) return false;
    out << "#!/usr/bin/env bash\n"
        << "set -euo pipefail\n"
        << "TMP=$(mktemp /tmp/phx_embed.XXXXXX.pxc)\n"
        << "trap 'rm -f \"$TMP\"' EXIT\n"
        << "base64 -d > \"$TMP\" << 'PHX_PAYLOAD_EOF'\n"
        << b64 << "\nPHX_PAYLOAD_EOF\n"
        << "exec phx run \"$TMP\" \"$@\"\n";
    out.close();
    fs::permissions(out_path,
        fs::perms::owner_all | fs::perms::group_read | fs::perms::group_exec |
        fs::perms::others_read | fs::perms::others_exec,
        fs::perm_options::add);
    return true;
}

bool write_windows_bat_launcher(const std::string& pxc_path, const std::string& out_path) {
    std::vector<uint8_t> bytes;
    if (!read_file_bytes(pxc_path, bytes)) return false;
    std::string b64 = base64_encode(bytes);
    std::ofstream out(out_path, std::ios::binary);
    if (!out) return false;
    out << "@echo off\r\nsetlocal\r\n";
    out << "set TMP=%TEMP%\\phx_embed_%RANDOM%.pxc\r\n";
    out << "set B64=%TEMP%\\phx_embed_%RANDOM%.b64\r\n";
    out << "(\r\n";
    const size_t chunk = 128;
    for (size_t i = 0; i < b64.size(); i += chunk) {
        out << "echo " << b64.substr(i, chunk) << "\r\n";
    }
    out << ") > \"%B64%\"\r\n";
    out << "certutil -decode \"%B64%\" \"%TMP%\" >nul\r\n";
    out << "del \"%B64%\" >nul 2>nul\r\n";
    out << "where phx >nul 2>nul\r\n";
    out << "if errorlevel 1 (\r\n";
    out << "  echo Phoenix runtime phx.exe not found in PATH\r\n";
    out << "  exit /b 127\r\n)\r\n";
    out << "phx run \"%TMP%\" %*\r\n";
    out << "set EC=%ERRORLEVEL%\r\n";
    out << "del \"%TMP%\" >nul 2>nul\r\n";
    out << "exit /b %EC%\r\n";
    out.close();
    return true;
}

} // anonymous namespace

void register_phx_packager_module(VM* vm) {
    if (!vm) return;

    vm->register_native_module("packager", "version", [](const std::vector<Value>&, VM&) {
        return Value::make_string("packager-1.1.0");
    });

    // pxc_to_exe(pxc, out_exe, stub_path?)
    // Builds: stub + pxc + footer. Stub should be Windows phx.exe (runtime).
    vm->register_native_module("packager", "pxc_to_exe", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        std::string pxc = args[0].to_string();
        std::string out = args[1].to_string();
        std::string stub = args.size() > 2 ? args[2].to_string() : "";
        if (stub.empty()) {
            if (fs::exists("phx.exe")) stub = "phx.exe";
            else if (fs::exists("phx_stub_windows.exe")) stub = "phx_stub_windows.exe";
        }
        if (stub.empty()) return Value::boolean(false);
        return Value::boolean(write_footer_package(stub, pxc, out));
    });

    vm->register_native_module("packager", "pxc_to_pxe", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        return Value::boolean(write_footer_package("", args[0].to_string(), args[1].to_string()));
    });

    vm->register_native_module("packager", "pxc_to_sh", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        return Value::boolean(write_unix_launcher(args[0].to_string(), args[1].to_string()));
    });

    vm->register_native_module("packager", "pxc_to_bat", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        return Value::boolean(write_windows_bat_launcher(args[0].to_string(), args[1].to_string()));
    });

    vm->register_native_module("packager", "verify", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        PayloadFooter foot{};
        std::vector<uint8_t> file;
        if (!read_footer(args[0].to_string(), foot, file)) return Value::boolean(false);
        std::vector<uint8_t> payload(
            file.begin() + static_cast<std::ptrdiff_t>(foot.offset),
            file.begin() + static_cast<std::ptrdiff_t>(foot.offset + foot.size));
        return Value::boolean(crc32_bytes(payload) == foot.crc32);
    });

    vm->register_native_module("packager", "info", [](const std::vector<Value>& args, VM&) {
        auto d = std::make_shared<HeapDict>();
        if (args.empty()) return Value::dict(d);
        PayloadFooter foot{};
        std::vector<uint8_t> file;
        if (!read_footer(args[0].to_string(), foot, file)) {
            d->entries["valid"] = Value::boolean(false);
            return Value::dict(d);
        }
        d->entries["valid"] = Value::boolean(true);
        d->entries["version"] = Value::make_u32(foot.version);
        d->entries["flags"] = Value::make_u32(foot.flags);
        d->entries["offset"] = Value::make_u64(foot.offset);
        d->entries["size"] = Value::make_u64(foot.size);
        d->entries["crc32"] = Value::make_u32(foot.crc32);
        d->entries["file_size"] = Value::make_u64(static_cast<uint64_t>(file.size()));
        d->entries["has_stub"] = Value::boolean((foot.flags & 1u) == 0u && foot.offset > 0);
        return Value::dict(d);
    });

    vm->register_native_module("packager", "extract_pxc", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        PayloadFooter foot{};
        std::vector<uint8_t> file;
        if (!read_footer(args[0].to_string(), foot, file)) return Value::boolean(false);
        std::vector<uint8_t> payload(
            file.begin() + static_cast<std::ptrdiff_t>(foot.offset),
            file.begin() + static_cast<std::ptrdiff_t>(foot.offset + foot.size));
        if (crc32_bytes(payload) != foot.crc32) return Value::boolean(false);
        return Value::boolean(write_file_bytes(args[1].to_string(), payload));
    });

    vm->register_native_module("packager", "version", [](const std::vector<Value>&, VM&) {
        return Value::make_string("packager-1.1.0");
    });
}

} // namespace phoenix

#if defined(PHX_MODULE_SHARED)
extern "C" void phoenix_module_init(VM* vm) {
    phoenix::register_phx_packager_module(vm);
}
#endif
