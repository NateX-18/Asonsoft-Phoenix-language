// libphx_math — native math module for Phoenix
// Loadable as: import math / @math.sqrt etc.
#include "phoenix/c_api/phoenix_c.h"
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"
#include <cmath>
#include <string>

using namespace phoenix;

// Registration entry point expected by NativeBridge loaders
extern "C" void phoenix_module_init(VM* vm) {
    if (!vm) return;

    vm->register_native_module("math", "sqrt", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::sqrt(args[0].as_number()));
    });
    vm->register_native_module("math", "pow", [](const std::vector<Value>& args, VM&) {
        double a = args.size() > 0 ? args[0].as_number() : 0;
        double b = args.size() > 1 ? args[1].as_number() : 0;
        return Value::number(std::pow(a, b));
    });
    vm->register_native_module("math", "abs", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::fabs(args[0].as_number()));
    });
    vm->register_native_module("math", "floor", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::floor(args[0].as_number()));
    });
    vm->register_native_module("math", "ceil", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::ceil(args[0].as_number()));
    });
    vm->register_native_module("math", "sin", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::sin(args[0].as_number()));
    });
    vm->register_native_module("math", "cos", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::cos(args[0].as_number()));
    });
    vm->register_native_module("math", "tan", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        return Value::number(std::tan(args[0].as_number()));
    });
    vm->register_native_module("math", "min", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        double m = args[0].as_number();
        for (size_t i = 1; i < args.size(); ++i) m = std::min(m, args[i].as_number());
        return Value::number(m);
    });
    vm->register_native_module("math", "max", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::number(0);
        double m = args[0].as_number();
        for (size_t i = 1; i < args.size(); ++i) m = std::max(m, args[i].as_number());
        return Value::number(m);
    });
    vm->register_native_module("math", "pi", [](const std::vector<Value>&, VM&) {
        return Value::number(3.14159265358979323846);
    });
    vm->register_native_module("math", "e", [](const std::vector<Value>&, VM&) {
        return Value::number(2.71828182845904523536);
    });
}
