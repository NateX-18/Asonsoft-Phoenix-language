// libphx_os — comprehensive operating-system module for Phoenix
// Usage: @os.cwd(), @os.env_get("PATH"), @os.path_exists(...), etc.
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <algorithm>
#include <sys/stat.h>
#include <sys/types.h>

#if defined(_WIN32)
#  include <windows.h>
#  include <direct.h>
#  include <process.h>
#  include <io.h>
#  define PATH_SEP '\\'
#  define stat_struct _stat
#  define STAT_FN _stat
#else
#  include <unistd.h>
#  include <dirent.h>
#  include <limits.h>
#  include <pwd.h>
#  include <sys/utsname.h>
#  if defined(__linux__)
#    include <sys/sysinfo.h>
#  endif
#  define PATH_SEP '/'
#  define stat_struct stat
#  define STAT_FN stat
#endif

#if !defined(_WIN32)
extern "C" char **environ;
#endif

using namespace phoenix;

namespace phoenix {

namespace {

std::string join_path(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    char last = a.back();
    if (last == '/' || last == '\\') return a + b;
    return a + PATH_SEP + b;
}

bool path_exists(const std::string& p) {
    struct stat_struct st{};
    return STAT_FN(p.c_str(), &st) == 0;
}

bool path_is_dir(const std::string& p) {
    struct stat_struct st{};
    if (STAT_FN(p.c_str(), &st) != 0) return false;
#if defined(_WIN32)
    return (st.st_mode & _S_IFDIR) != 0;
#else
    return S_ISDIR(st.st_mode);
#endif
}

bool path_is_file(const std::string& p) {
    struct stat_struct st{};
    if (STAT_FN(p.c_str(), &st) != 0) return false;
#if defined(_WIN32)
    return (st.st_mode & _S_IFREG) != 0;
#else
    return S_ISREG(st.st_mode);
#endif
}

std::string getenv_str(const char* key) {
    const char* v = std::getenv(key);
    return v ? std::string(v) : std::string();
}

} // namespace

void register_phx_os_module(VM* vm) {
    if (!vm) return;

    // ---- platform identity ----
    vm->register_native_module("os", "name", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_string("windows");
#elif defined(__APPLE__)
        return Value::make_string("macos");
#elif defined(__ANDROID__)
        return Value::make_string("android");
#elif defined(__linux__)
        return Value::make_string("linux");
#elif defined(__unix__)
        return Value::make_string("unix");
#else
        return Value::make_string("unknown");
#endif
    });
    vm->register_native_module("os", "platform", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_string("win32");
#elif defined(__APPLE__)
        return Value::make_string("darwin");
#elif defined(__ANDROID__)
        return Value::make_string("android");
#elif defined(__linux__)
        return Value::make_string("linux");
#else
        return Value::make_string("unknown");
#endif
    });
    vm->register_native_module("os", "arch", [](const std::vector<Value>&, VM&) {
#if defined(__x86_64__) || defined(_M_X64)
        return Value::make_string("x86_64");
#elif defined(__i386__) || defined(_M_IX86)
        return Value::make_string("x86");
#elif defined(__aarch64__) || defined(_M_ARM64)
        return Value::make_string("arm64");
#elif defined(__arm__) || defined(_M_ARM)
        return Value::make_string("arm");
#else
        return Value::make_string("unknown");
#endif
    });
    vm->register_native_module("os", "is_windows", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::boolean(true);
#else
        return Value::boolean(false);
#endif
    });
    vm->register_native_module("os", "is_linux", [](const std::vector<Value>&, VM&) {
#if defined(__linux__) && !defined(__ANDROID__)
        return Value::boolean(true);
#else
        return Value::boolean(false);
#endif
    });
    vm->register_native_module("os", "is_macos", [](const std::vector<Value>&, VM&) {
#if defined(__APPLE__)
        return Value::boolean(true);
#else
        return Value::boolean(false);
#endif
    });
    vm->register_native_module("os", "is_android", [](const std::vector<Value>&, VM&) {
#if defined(__ANDROID__)
        return Value::boolean(true);
#else
        return Value::boolean(false);
#endif
    });
    vm->register_native_module("os", "is_unix", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::boolean(false);
#else
        return Value::boolean(true);
#endif
    });

    vm->register_native_module("os", "uname", [](const std::vector<Value>&, VM&) {
        auto d = std::make_shared<HeapDict>();
#if defined(_WIN32)
        d->entries["sysname"] = Value::make_string("Windows");
        d->entries["nodename"] = Value::make_string("");
        d->entries["release"] = Value::make_string("");
        d->entries["version"] = Value::make_string("");
        d->entries["machine"] = Value::make_string("");
#else
        struct utsname u{};
        if (uname(&u) == 0) {
            d->entries["sysname"] = Value::make_string(u.sysname);
            d->entries["nodename"] = Value::make_string(u.nodename);
            d->entries["release"] = Value::make_string(u.release);
            d->entries["version"] = Value::make_string(u.version);
            d->entries["machine"] = Value::make_string(u.machine);
        }
#endif
        return Value::dict(d);
    });

    // ---- host / user ----
    vm->register_native_module("os", "hostname", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        char buf[256]; DWORD n = sizeof(buf);
        if (GetComputerNameA(buf, &n)) return Value::make_string(buf);
        return Value::make_string("");
#else
        char buf[256];
        if (gethostname(buf, sizeof(buf)) == 0) return Value::make_string(buf);
        return Value::make_string("");
#endif
    });
    vm->register_native_module("os", "username", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        char buf[256]; DWORD n = sizeof(buf);
        if (GetUserNameA(buf, &n)) return Value::make_string(buf);
        return Value::make_string(getenv_str("USERNAME"));
#else
        const char* u = std::getenv("USER");
        if (u) return Value::make_string(u);
        u = std::getenv("LOGNAME");
        if (u) return Value::make_string(u);
        passwd* pw = getpwuid(geteuid());
        if (pw && pw->pw_name) return Value::make_string(pw->pw_name);
        return Value::make_string("");
#endif
    });
    vm->register_native_module("os", "home", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        std::string h = getenv_str("USERPROFILE");
        if (h.empty()) h = getenv_str("HOME");
        return Value::make_string(h);
#else
        const char* h = std::getenv("HOME");
        if (h) return Value::make_string(h);
        passwd* pw = getpwuid(geteuid());
        if (pw && pw->pw_dir) return Value::make_string(pw->pw_dir);
        return Value::make_string("");
#endif
    });
    vm->register_native_module("os", "tmpdir", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        char buf[MAX_PATH];
        DWORD n = GetTempPathA(MAX_PATH, buf);
        if (n > 0) return Value::make_string(std::string(buf, n));
        return Value::make_string(getenv_str("TEMP"));
#else
        const char* t = std::getenv("TMPDIR");
        if (t) return Value::make_string(t);
        t = std::getenv("TMP");
        if (t) return Value::make_string(t);
        return Value::make_string("/tmp");
#endif
    });

    // ---- process ----
    vm->register_native_module("os", "pid", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_i64(static_cast<int64_t>(GetCurrentProcessId()));
#else
        return Value::make_i64(static_cast<int64_t>(getpid()));
#endif
    });
    vm->register_native_module("os", "ppid", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_i64(0);
#else
        return Value::make_i64(static_cast<int64_t>(getppid()));
#endif
    });
    vm->register_native_module("os", "exit", [](const std::vector<Value>& args, VM&) {
        int code = args.empty() ? 0 : static_cast<int>(args[0].as_i64());
        std::exit(code);
        return Value::nil();
    });
    vm->register_native_module("os", "abort", [](const std::vector<Value>&, VM&) {
        std::abort();
        return Value::nil();
    });
    vm->register_native_module("os", "system", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(-1);
        int rc = std::system(args[0].to_string().c_str());
        return Value::make_i64(rc);
    });
    vm->register_native_module("os", "shell", [](const std::vector<Value>& args, VM&) {
        // shell(cmd) → captured stdout as string
        if (args.empty()) return Value::make_string("");
        std::string cmd = args[0].to_string();
#if defined(_WIN32)
        FILE* pipe = _popen(cmd.c_str(), "r");
#else
        FILE* pipe = popen(cmd.c_str(), "r");
#endif
        if (!pipe) return Value::make_string("");
        std::string out;
        char buf[4096];
        while (fgets(buf, sizeof(buf), pipe)) out += buf;
#if defined(_WIN32)
        _pclose(pipe);
#else
        pclose(pipe);
#endif
        return Value::make_string(out);
    });
    vm->register_native_module("os", "cpu_count", [](const std::vector<Value>&, VM&) {
        unsigned n = std::thread::hardware_concurrency();
        return Value::make_i64(n ? static_cast<int64_t>(n) : 1);
    });

    // ---- cwd ----
    vm->register_native_module("os", "cwd", [](const std::vector<Value>&, VM&) {
        char buf[4096];
#if defined(_WIN32)
        if (_getcwd(buf, sizeof(buf))) return Value::make_string(buf);
#else
        if (getcwd(buf, sizeof(buf))) return Value::make_string(buf);
#endif
        return Value::make_string("");
    });
    vm->register_native_module("os", "chdir", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
#if defined(_WIN32)
        return Value::boolean(_chdir(args[0].to_string().c_str()) == 0);
#else
        return Value::boolean(chdir(args[0].to_string().c_str()) == 0);
#endif
    });
    vm->register_native_module("os", "getcwd", [](const std::vector<Value>&, VM&) {
        char buf[4096];
#if defined(_WIN32)
        if (_getcwd(buf, sizeof(buf))) return Value::make_string(buf);
#else
        if (getcwd(buf, sizeof(buf))) return Value::make_string(buf);
#endif
        return Value::make_string("");
    });

    // ---- environment ----
    vm->register_native_module("os", "env_get", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::nil();
        std::string v = getenv_str(args[0].to_string().c_str());
        if (v.empty() && !std::getenv(args[0].to_string().c_str())) return Value::nil();
        return Value::make_string(v);
    });
    vm->register_native_module("os", "getenv", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::nil();
        const char* v = std::getenv(args[0].to_string().c_str());
        if (!v) return args.size() > 1 ? Value::make_string(args[1].to_string()) : Value::nil();
        return Value::make_string(v);
    });
    vm->register_native_module("os", "env_set", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
#if defined(_WIN32)
        return Value::boolean(_putenv_s(args[0].to_string().c_str(), args[1].to_string().c_str()) == 0);
#else
        return Value::boolean(setenv(args[0].to_string().c_str(), args[1].to_string().c_str(), 1) == 0);
#endif
    });
    vm->register_native_module("os", "putenv", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
#if defined(_WIN32)
        return Value::boolean(_putenv_s(args[0].to_string().c_str(), args[1].to_string().c_str()) == 0);
#else
        return Value::boolean(setenv(args[0].to_string().c_str(), args[1].to_string().c_str(), 1) == 0);
#endif
    });
    vm->register_native_module("os", "env_unset", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
#if defined(_WIN32)
        return Value::boolean(_putenv_s(args[0].to_string().c_str(), "") == 0);
#else
        return Value::boolean(unsetenv(args[0].to_string().c_str()) == 0);
#endif
    });
    vm->register_native_module("os", "env_list", [](const std::vector<Value>&, VM&) {
        auto list = std::make_shared<HeapList>();
#if !defined(_WIN32)
        if (environ) {
            for (char **e = environ; *e; ++e) {
                list->elements.push_back(Value::make_string(*e));
            }
        }
#endif
        return Value::list(list);
    });

    // ---- path helpers ----
    vm->register_native_module("os", "path_sep", [](const std::vector<Value>&, VM&) {
        return Value::make_string(std::string(1, PATH_SEP));
    });
    vm->register_native_module("os", "path_join", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string acc = args[0].to_string();
        for (size_t i = 1; i < args.size(); ++i) acc = join_path(acc, args[i].to_string());
        return Value::make_string(acc);
    });
    vm->register_native_module("os", "path_basename", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string p = args[0].to_string();
        auto pos = p.find_last_of("/\\");
        if (pos == std::string::npos) return Value::make_string(p);
        return Value::make_string(p.substr(pos + 1));
    });
    vm->register_native_module("os", "path_dirname", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string p = args[0].to_string();
        auto pos = p.find_last_of("/\\");
        if (pos == std::string::npos) return Value::make_string(".");
        if (pos == 0) return Value::make_string(p.substr(0, 1));
        return Value::make_string(p.substr(0, pos));
    });
    vm->register_native_module("os", "path_ext", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string base = args[0].to_string();
        auto slash = base.find_last_of("/\\");
        if (slash != std::string::npos) base = base.substr(slash + 1);
        auto dot = base.find_last_of('.');
        if (dot == std::string::npos || dot == 0) return Value::make_string("");
        return Value::make_string(base.substr(dot));
    });
    vm->register_native_module("os", "path_split", [](const std::vector<Value>& args, VM&) {
        auto list = std::make_shared<HeapList>();
        if (args.empty()) return Value::list(list);
        std::string p = args[0].to_string();
        auto pos = p.find_last_of("/\\");
        if (pos == std::string::npos) {
            list->elements.push_back(Value::make_string("."));
            list->elements.push_back(Value::make_string(p));
        } else {
            list->elements.push_back(Value::make_string(p.substr(0, pos == 0 ? 1 : pos)));
            list->elements.push_back(Value::make_string(p.substr(pos + 1)));
        }
        return Value::list(list);
    });
    vm->register_native_module("os", "path_exists", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        return Value::boolean(path_exists(args[0].to_string()));
    });
    vm->register_native_module("os", "path_isfile", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        return Value::boolean(path_is_file(args[0].to_string()));
    });
    vm->register_native_module("os", "path_isdir", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        return Value::boolean(path_is_dir(args[0].to_string()));
    });
    vm->register_native_module("os", "path_size", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(-1);
        struct stat_struct st{};
        if (STAT_FN(args[0].to_string().c_str(), &st) != 0) return Value::make_i64(-1);
        return Value::make_i64(static_cast<int64_t>(st.st_size));
    });
    vm->register_native_module("os", "path_mtime", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(-1);
        struct stat_struct st{};
        if (STAT_FN(args[0].to_string().c_str(), &st) != 0) return Value::make_i64(-1);
        return Value::make_i64(static_cast<int64_t>(st.st_mtime));
    });
    vm->register_native_module("os", "path_abspath", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string p = args[0].to_string();
#if defined(_WIN32)
        char buf[MAX_PATH];
        DWORD n = GetFullPathNameA(p.c_str(), MAX_PATH, buf, nullptr);
        if (n > 0 && n < MAX_PATH) return Value::make_string(buf);
        return Value::make_string(p);
#else
        char buf[PATH_MAX];
        if (realpath(p.c_str(), buf)) return Value::make_string(buf);
        // if doesn't exist yet, join with cwd
        if (!p.empty() && p[0] == '/') return Value::make_string(p);
        char cwd[PATH_MAX];
        if (getcwd(cwd, sizeof(cwd))) return Value::make_string(join_path(cwd, p));
        return Value::make_string(p);
#endif
    });
    vm->register_native_module("os", "path_realpath", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
#if defined(_WIN32)
        char buf[MAX_PATH];
        DWORD n = GetFullPathNameA(args[0].to_string().c_str(), MAX_PATH, buf, nullptr);
        return Value::make_string(n ? buf : args[0].to_string());
#else
        char buf[PATH_MAX];
        if (realpath(args[0].to_string().c_str(), buf)) return Value::make_string(buf);
        return Value::make_string("");
#endif
    });
    vm->register_native_module("os", "path_mkdir", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        std::string p = args[0].to_string();
#if defined(_WIN32)
        return Value::boolean(_mkdir(p.c_str()) == 0 || path_is_dir(p));
#else
        return Value::boolean(mkdir(p.c_str(), 0755) == 0 || path_is_dir(p));
#endif
    });
    vm->register_native_module("os", "path_rmdir", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
#if defined(_WIN32)
        return Value::boolean(_rmdir(args[0].to_string().c_str()) == 0);
#else
        return Value::boolean(rmdir(args[0].to_string().c_str()) == 0);
#endif
    });
    vm->register_native_module("os", "path_remove", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        return Value::boolean(std::remove(args[0].to_string().c_str()) == 0);
    });
    vm->register_native_module("os", "path_rename", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        return Value::boolean(std::rename(args[0].to_string().c_str(), args[1].to_string().c_str()) == 0);
    });
    vm->register_native_module("os", "path_copy", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        std::ifstream in(args[0].to_string(), std::ios::binary);
        if (!in) return Value::boolean(false);
        std::ofstream out(args[1].to_string(), std::ios::binary);
        if (!out) return Value::boolean(false);
        out << in.rdbuf();
        return Value::boolean(static_cast<bool>(out));
    });
    vm->register_native_module("os", "path_listdir", [](const std::vector<Value>& args, VM&) {
        auto list = std::make_shared<HeapList>();
        std::string dir = args.empty() ? "." : args[0].to_string();
#if defined(_WIN32)
        std::string pattern = join_path(dir, "*");
        WIN32_FIND_DATAA fd;
        HANDLE h = FindFirstFileA(pattern.c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                std::string name = fd.cFileName;
                if (name != "." && name != "..") list->elements.push_back(Value::make_string(name));
            } while (FindNextFileA(h, &fd));
            FindClose(h);
        }
#else
        DIR* d = opendir(dir.c_str());
        if (d) {
            while (dirent* ent = readdir(d)) {
                std::string name = ent->d_name;
                if (name != "." && name != "..") list->elements.push_back(Value::make_string(name));
            }
            closedir(d);
        }
#endif
        return Value::list(list);
    });
    vm->register_native_module("os", "which", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::nil();
        std::string cmd = args[0].to_string();
        std::string path = getenv_str("PATH");
        char sep = ':';
#if defined(_WIN32)
        sep = ';';
#endif
        std::stringstream ss(path);
        std::string part;
        while (std::getline(ss, part, sep)) {
            if (part.empty()) continue;
            std::string candidate = join_path(part, cmd);
#if defined(_WIN32)
            if (path_is_file(candidate) || path_is_file(candidate + ".exe")) {
                if (path_is_file(candidate + ".exe")) candidate += ".exe";
                return Value::make_string(candidate);
            }
#else
            if (path_is_file(candidate)) return Value::make_string(candidate);
#endif
        }
        return Value::nil();
    });

    // ---- memory / uptime (best-effort) ----
    vm->register_native_module("os", "uptime", [](const std::vector<Value>&, VM&) {
#if defined(__linux__)
        struct sysinfo info{};
        if (sysinfo(&info) == 0) return Value::make_i64(static_cast<int64_t>(info.uptime));
#endif
        return Value::make_i64(-1);
    });
    vm->register_native_module("os", "memory_total", [](const std::vector<Value>&, VM&) {
#if defined(__linux__)
        struct sysinfo info{};
        if (sysinfo(&info) == 0)
            return Value::make_i64(static_cast<int64_t>(info.totalram) * info.mem_unit);
#endif
        return Value::make_i64(-1);
    });
    vm->register_native_module("os", "memory_free", [](const std::vector<Value>&, VM&) {
#if defined(__linux__)
        struct sysinfo info{};
        if (sysinfo(&info) == 0)
            return Value::make_i64(static_cast<int64_t>(info.freeram) * info.mem_unit);
#endif
        return Value::make_i64(-1);
    });

    // ---- uid/gid ----
    vm->register_native_module("os", "getuid", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_i64(0);
#else
        return Value::make_i64(static_cast<int64_t>(getuid()));
#endif
    });
    vm->register_native_module("os", "geteuid", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_i64(0);
#else
        return Value::make_i64(static_cast<int64_t>(geteuid()));
#endif
    });
    vm->register_native_module("os", "getgid", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_i64(0);
#else
        return Value::make_i64(static_cast<int64_t>(getgid()));
#endif
    });

    // ---- newline / line ending ----
    vm->register_native_module("os", "linesep", [](const std::vector<Value>&, VM&) {
#if defined(_WIN32)
        return Value::make_string("\r\n");
#else
        return Value::make_string("\n");
#endif
    });
}

} // namespace phoenix

#if defined(PHX_MODULE_SHARED)
extern "C" void phoenix_module_init(VM* vm) {
    phoenix::register_phx_os_module(vm);
}
#endif
