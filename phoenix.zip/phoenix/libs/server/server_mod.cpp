// libphx_server — TCP sockets + lightweight HTTP helpers for Phoenix
// Usage: @server.tcp_listen(8080), @server.http_response(200, "text/plain", "hi"), etc.
#include "phoenix/vm/vm.hpp"
#include "phoenix/common/types.hpp"
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <cstring>
#include <cerrno>
#include <algorithm>
#include <thread>
#include <chrono>

#if defined(_WIN32)
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  pragma comment(lib, "ws2_32.lib")
   using socklen_t = int;
   static bool g_wsa = false;
   static void ensure_wsa() {
       if (!g_wsa) {
           WSADATA wsa;
           WSAStartup(MAKEWORD(2, 2), &wsa);
           g_wsa = true;
       }
   }
#  define CLOSESOCK closesocket
#  define SOCK_ERR SOCKET_ERROR
#else
#  include <sys/types.h>
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#  include <netdb.h>
#  include <unistd.h>
#  include <fcntl.h>
   using SOCKET = int;
#  define INVALID_SOCKET (-1)
#  define CLOSESOCK close
#  define SOCK_ERR (-1)
   static void ensure_wsa() {}
#endif

using namespace phoenix;

namespace phoenix {

namespace {

std::map<int64_t, SOCKET> g_sockets;
int64_t g_next_sock_id = 1;

int64_t track_socket(SOCKET s) {
    if (s == INVALID_SOCKET) return -1;
    int64_t id = g_next_sock_id++;
    g_sockets[id] = s;
    return id;
}

SOCKET get_socket(int64_t id) {
    auto it = g_sockets.find(id);
    if (it == g_sockets.end()) return INVALID_SOCKET;
    return it->second;
}

void release_socket(int64_t id) {
    auto it = g_sockets.find(id);
    if (it == g_sockets.end()) return;
    CLOSESOCK(it->second);
    g_sockets.erase(it);
}

std::string status_text(int code) {
    switch (code) {
        case 200: return "OK";
        case 201: return "Created";
        case 204: return "No Content";
        case 301: return "Moved Permanently";
        case 302: return "Found";
        case 304: return "Not Modified";
        case 400: return "Bad Request";
        case 401: return "Unauthorized";
        case 403: return "Forbidden";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 500: return "Internal Server Error";
        case 502: return "Bad Gateway";
        case 503: return "Service Unavailable";
        default:  return "OK";
    }
}

} // namespace

void register_phx_server_module(VM* vm) {
    if (!vm) return;

    // ---- socket lifecycle ----
    vm->register_native_module("server", "tcp_socket", [](const std::vector<Value>&, VM&) {
        ensure_wsa();
        SOCKET s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (s == INVALID_SOCKET) return Value::make_i64(-1);
        int yes = 1;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));
        return Value::make_i64(track_socket(s));
    });

    vm->register_native_module("server", "tcp_bind", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::boolean(false);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::boolean(false);
        int port = static_cast<int>(args[1].as_i64());
        std::string host = args.size() > 2 ? args[2].to_string() : "0.0.0.0";
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(static_cast<uint16_t>(port));
        if (host == "0.0.0.0" || host.empty()) {
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
        } else {
            inet_pton(AF_INET, host.c_str(), &addr.sin_addr);
        }
        int rc = ::bind(s, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
        return Value::boolean(rc != SOCK_ERR);
    });

    vm->register_native_module("server", "tcp_listen", [](const std::vector<Value>& args, VM&) {
        // tcp_listen(port [, backlog=128 [, host]])
        // convenience: create+bind+listen → socket id
        ensure_wsa();
        if (args.empty()) return Value::make_i64(-1);
        int port = static_cast<int>(args[0].as_i64());
        int backlog = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 128;
        std::string host = args.size() > 2 ? args[2].to_string() : "0.0.0.0";

        SOCKET s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (s == INVALID_SOCKET) return Value::make_i64(-1);
        int yes = 1;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(static_cast<uint16_t>(port));
        if (host == "0.0.0.0" || host.empty()) addr.sin_addr.s_addr = htonl(INADDR_ANY);
        else inet_pton(AF_INET, host.c_str(), &addr.sin_addr);

        if (::bind(s, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCK_ERR) {
            CLOSESOCK(s);
            return Value::make_i64(-1);
        }
        if (::listen(s, backlog) == SOCK_ERR) {
            CLOSESOCK(s);
            return Value::make_i64(-1);
        }
        return Value::make_i64(track_socket(s));
    });

    vm->register_native_module("server", "listen", [](const std::vector<Value>& args, VM&) {
        // listen(sock_id [, backlog])
        if (args.empty()) return Value::boolean(false);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::boolean(false);
        int backlog = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 128;
        return Value::boolean(::listen(s, backlog) != SOCK_ERR);
    });

    vm->register_native_module("server", "tcp_accept", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(-1);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_i64(-1);
        sockaddr_in client{};
        socklen_t len = sizeof(client);
        SOCKET c = ::accept(s, reinterpret_cast<sockaddr*>(&client), &len);
        if (c == INVALID_SOCKET) return Value::make_i64(-1);
        return Value::make_i64(track_socket(c));
    });

    vm->register_native_module("server", "tcp_connect", [](const std::vector<Value>& args, VM&) {
        // tcp_connect(host, port) → sock id
        ensure_wsa();
        if (args.size() < 2) return Value::make_i64(-1);
        std::string host = args[0].to_string();
        int port = static_cast<int>(args[1].as_i64());
        SOCKET s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (s == INVALID_SOCKET) return Value::make_i64(-1);

        addrinfo hints{};
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        addrinfo* res = nullptr;
        std::string port_s = std::to_string(port);
        if (getaddrinfo(host.c_str(), port_s.c_str(), &hints, &res) != 0 || !res) {
            CLOSESOCK(s);
            return Value::make_i64(-1);
        }
        int rc = ::connect(s, res->ai_addr, static_cast<socklen_t>(res->ai_addrlen));
        freeaddrinfo(res);
        if (rc == SOCK_ERR) {
            CLOSESOCK(s);
            return Value::make_i64(-1);
        }
        return Value::make_i64(track_socket(s));
    });

    vm->register_native_module("server", "tcp_send", [](const std::vector<Value>& args, VM&) {
        if (args.size() < 2) return Value::make_i64(-1);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_i64(-1);
        std::string data = args[1].to_string();
        int n = ::send(s, data.data(), static_cast<int>(data.size()), 0);
        return Value::make_i64(n);
    });

    vm->register_native_module("server", "tcp_recv", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_string("");
        int maxlen = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 8192;
        if (maxlen <= 0) maxlen = 8192;
        if (maxlen > 1 << 20) maxlen = 1 << 20;
        std::vector<char> buf(static_cast<size_t>(maxlen));
        int n = ::recv(s, buf.data(), maxlen, 0);
        if (n <= 0) return Value::make_string("");
        return Value::make_string(std::string(buf.data(), static_cast<size_t>(n)));
    });

    vm->register_native_module("server", "tcp_close", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        int64_t id = args[0].as_i64();
        if (g_sockets.find(id) == g_sockets.end()) return Value::boolean(false);
        release_socket(id);
        return Value::boolean(true);
    });

    vm->register_native_module("server", "tcp_shutdown", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::boolean(false);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::boolean(false);
        int how = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 2; // SHUT_RDWR
#if defined(_WIN32)
        return Value::boolean(shutdown(s, how) != SOCKET_ERROR);
#else
        return Value::boolean(shutdown(s, how) == 0);
#endif
    });

    vm->register_native_module("server", "set_timeout", [](const std::vector<Value>& args, VM&) {
        // set_timeout(sock, seconds)
        if (args.size() < 2) return Value::boolean(false);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::boolean(false);
        int sec = static_cast<int>(args[1].as_i64());
#if defined(_WIN32)
        DWORD ms = static_cast<DWORD>(sec * 1000);
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&ms), sizeof(ms));
        setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char*>(&ms), sizeof(ms));
#else
        timeval tv{};
        tv.tv_sec = sec;
        tv.tv_usec = 0;
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
#endif
        return Value::boolean(true);
    });

    // ---- peer info ----
    vm->register_native_module("server", "peer_addr", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_string("");
        sockaddr_in addr{};
        socklen_t len = sizeof(addr);
        if (getpeername(s, reinterpret_cast<sockaddr*>(&addr), &len) != 0) return Value::make_string("");
        char buf[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &addr.sin_addr, buf, sizeof(buf));
        return Value::make_string(buf);
    });
    vm->register_native_module("server", "peer_port", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(0);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_i64(0);
        sockaddr_in addr{};
        socklen_t len = sizeof(addr);
        if (getpeername(s, reinterpret_cast<sockaddr*>(&addr), &len) != 0) return Value::make_i64(0);
        return Value::make_i64(ntohs(addr.sin_port));
    });
    vm->register_native_module("server", "local_port", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_i64(0);
        SOCKET s = get_socket(args[0].as_i64());
        if (s == INVALID_SOCKET) return Value::make_i64(0);
        sockaddr_in addr{};
        socklen_t len = sizeof(addr);
        if (getsockname(s, reinterpret_cast<sockaddr*>(&addr), &len) != 0) return Value::make_i64(0);
        return Value::make_i64(ntohs(addr.sin_port));
    });

    // ---- DNS ----
    vm->register_native_module("server", "resolve", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        ensure_wsa();
        addrinfo hints{};
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        addrinfo* res = nullptr;
        if (getaddrinfo(args[0].to_string().c_str(), nullptr, &hints, &res) != 0 || !res)
            return Value::make_string("");
        char buf[INET_ADDRSTRLEN] = {};
        auto* sin = reinterpret_cast<sockaddr_in*>(res->ai_addr);
        inet_ntop(AF_INET, &sin->sin_addr, buf, sizeof(buf));
        freeaddrinfo(res);
        return Value::make_string(buf);
    });
    vm->register_native_module("server", "resolve_all", [](const std::vector<Value>& args, VM&) {
        auto list = std::make_shared<HeapList>();
        if (args.empty()) return Value::list(list);
        ensure_wsa();
        addrinfo hints{};
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        addrinfo* res = nullptr;
        if (getaddrinfo(args[0].to_string().c_str(), nullptr, &hints, &res) != 0 || !res)
            return Value::list(list);
        for (addrinfo* p = res; p; p = p->ai_next) {
            char buf[INET_ADDRSTRLEN] = {};
            auto* sin = reinterpret_cast<sockaddr_in*>(p->ai_addr);
            inet_ntop(AF_INET, &sin->sin_addr, buf, sizeof(buf));
            list->elements.push_back(Value::make_string(buf));
        }
        freeaddrinfo(res);
        return Value::list(list);
    });

    // ---- HTTP helpers ----
    vm->register_native_module("server", "http_status_text", [](const std::vector<Value>& args, VM&) {
        int code = args.empty() ? 200 : static_cast<int>(args[0].as_i64());
        return Value::make_string(status_text(code));
    });

    vm->register_native_module("server", "http_response", [](const std::vector<Value>& args, VM&) {
        // http_response(status, content_type, body [, extra_headers])
        int status = args.size() > 0 ? static_cast<int>(args[0].as_i64()) : 200;
        std::string ctype = args.size() > 1 ? args[1].to_string() : "text/plain; charset=utf-8";
        std::string body = args.size() > 2 ? args[2].to_string() : "";
        std::string extra = args.size() > 3 ? args[3].to_string() : "";
        std::ostringstream oss;
        oss << "HTTP/1.1 " << status << " " << status_text(status) << "\r\n";
        oss << "Content-Type: " << ctype << "\r\n";
        oss << "Content-Length: " << body.size() << "\r\n";
        oss << "Connection: close\r\n";
        if (!extra.empty()) {
            oss << extra;
            if (extra.back() != '\n') oss << "\r\n";
        }
        oss << "\r\n" << body;
        return Value::make_string(oss.str());
    });

    vm->register_native_module("server", "http_json", [](const std::vector<Value>& args, VM&) {
        // http_json(status, json_body)
        int status = args.size() > 0 ? static_cast<int>(args[0].as_i64()) : 200;
        std::string body = args.size() > 1 ? args[1].to_string() : "{}";
        std::ostringstream oss;
        oss << "HTTP/1.1 " << status << " " << status_text(status) << "\r\n";
        oss << "Content-Type: application/json; charset=utf-8\r\n";
        oss << "Content-Length: " << body.size() << "\r\n";
        oss << "Connection: close\r\n\r\n" << body;
        return Value::make_string(oss.str());
    });

    vm->register_native_module("server", "http_html", [](const std::vector<Value>& args, VM&) {
        int status = args.size() > 0 ? static_cast<int>(args[0].as_i64()) : 200;
        std::string body = args.size() > 1 ? args[1].to_string() : "";
        std::ostringstream oss;
        oss << "HTTP/1.1 " << status << " " << status_text(status) << "\r\n";
        oss << "Content-Type: text/html; charset=utf-8\r\n";
        oss << "Content-Length: " << body.size() << "\r\n";
        oss << "Connection: close\r\n\r\n" << body;
        return Value::make_string(oss.str());
    });

    vm->register_native_module("server", "http_redirect", [](const std::vector<Value>& args, VM&) {
        // http_redirect(url [, status=302])
        std::string url = args.size() > 0 ? args[0].to_string() : "/";
        int status = args.size() > 1 ? static_cast<int>(args[1].as_i64()) : 302;
        std::ostringstream oss;
        oss << "HTTP/1.1 " << status << " " << status_text(status) << "\r\n";
        oss << "Location: " << url << "\r\n";
        oss << "Content-Length: 0\r\n";
        oss << "Connection: close\r\n\r\n";
        return Value::make_string(oss.str());
    });

    // Parse first line + headers of an HTTP request into a dict
    vm->register_native_module("server", "http_parse_request", [](const std::vector<Value>& args, VM&) {
        auto d = std::make_shared<HeapDict>();
        d->entries["method"] = Value::make_string("");
        d->entries["path"] = Value::make_string("");
        d->entries["version"] = Value::make_string("");
        d->entries["query"] = Value::make_string("");
        d->entries["body"] = Value::make_string("");
        d->entries["headers"] = Value::dict(std::make_shared<HeapDict>());
        if (args.empty()) return Value::dict(d);

        std::string raw = args[0].to_string();
        auto header_end = raw.find("\r\n\r\n");
        std::string header_part = header_end == std::string::npos ? raw : raw.substr(0, header_end);
        std::string body = header_end == std::string::npos ? "" : raw.substr(header_end + 4);

        std::istringstream iss(header_part);
        std::string line;
        if (std::getline(iss, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            std::istringstream ls(line);
            std::string method, path, ver;
            ls >> method >> path >> ver;
            d->entries["method"] = Value::make_string(method);
            d->entries["version"] = Value::make_string(ver);
            auto q = path.find('?');
            if (q != std::string::npos) {
                d->entries["path"] = Value::make_string(path.substr(0, q));
                d->entries["query"] = Value::make_string(path.substr(q + 1));
            } else {
                d->entries["path"] = Value::make_string(path);
            }
        }
        auto headers = std::make_shared<HeapDict>();
        while (std::getline(iss, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            auto colon = line.find(':');
            if (colon == std::string::npos) continue;
            std::string key = line.substr(0, colon);
            std::string val = line.substr(colon + 1);
            while (!val.empty() && val[0] == ' ') val.erase(0, 1);
            // lowercase key
            std::transform(key.begin(), key.end(), key.begin(),
                           [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            headers->entries[key] = Value::make_string(val);
        }
        d->entries["headers"] = Value::dict(headers);
        d->entries["body"] = Value::make_string(body);
        return Value::dict(d);
    });

    // url_parse("http://host:port/path?query") → dict
    vm->register_native_module("server", "url_parse", [](const std::vector<Value>& args, VM&) {
        auto d = std::make_shared<HeapDict>();
        d->entries["scheme"] = Value::make_string("");
        d->entries["host"] = Value::make_string("");
        d->entries["port"] = Value::make_i64(0);
        d->entries["path"] = Value::make_string("/");
        d->entries["query"] = Value::make_string("");
        d->entries["fragment"] = Value::make_string("");
        if (args.empty()) return Value::dict(d);

        std::string url = args[0].to_string();
        std::string scheme, rest = url;
        auto scheme_pos = url.find("://");
        if (scheme_pos != std::string::npos) {
            scheme = url.substr(0, scheme_pos);
            rest = url.substr(scheme_pos + 3);
        }
        d->entries["scheme"] = Value::make_string(scheme);

        std::string hostport, pathquery;
        auto slash = rest.find('/');
        if (slash == std::string::npos) {
            hostport = rest;
            pathquery = "/";
        } else {
            hostport = rest.substr(0, slash);
            pathquery = rest.substr(slash);
        }

        std::string host = hostport;
        int port = 0;
        auto colon = hostport.rfind(':');
        if (colon != std::string::npos) {
            host = hostport.substr(0, colon);
            try { port = std::stoi(hostport.substr(colon + 1)); } catch (...) { port = 0; }
        }
        if (port == 0) {
            if (scheme == "https") port = 443;
            else if (scheme == "http") port = 80;
        }
        d->entries["host"] = Value::make_string(host);
        d->entries["port"] = Value::make_i64(port);

        std::string path = pathquery, query, frag;
        auto hash = path.find('#');
        if (hash != std::string::npos) {
            frag = path.substr(hash + 1);
            path = path.substr(0, hash);
        }
        auto q = path.find('?');
        if (q != std::string::npos) {
            query = path.substr(q + 1);
            path = path.substr(0, q);
        }
        d->entries["path"] = Value::make_string(path.empty() ? "/" : path);
        d->entries["query"] = Value::make_string(query);
        d->entries["fragment"] = Value::make_string(frag);
        return Value::dict(d);
    });

    // url_encode / url_decode
    vm->register_native_module("server", "url_encode", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string s = args[0].to_string();
        std::ostringstream oss;
        oss << std::hex << std::uppercase;
        for (unsigned char c : s) {
            if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') oss << c;
            else oss << '%' << ((c >> 4) & 0xF) << (c & 0xF);
        }
        return Value::make_string(oss.str());
    });
    vm->register_native_module("server", "url_decode", [](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string s = args[0].to_string();
        std::string out;
        for (size_t i = 0; i < s.size(); ++i) {
            if (s[i] == '%' && i + 2 < s.size()) {
                auto hex = s.substr(i + 1, 2);
                try {
                    out.push_back(static_cast<char>(std::stoi(hex, nullptr, 16)));
                    i += 2;
                } catch (...) {
                    out.push_back(s[i]);
                }
            } else if (s[i] == '+') {
                out.push_back(' ');
            } else {
                out.push_back(s[i]);
            }
        }
        return Value::make_string(out);
    });

    // Simple one-shot HTTP serve helper: accept one request, reply with fixed body
    vm->register_native_module("server", "http_serve_once", [](const std::vector<Value>& args, VM&) {
        // http_serve_once(port, response_string) → true/false
        if (args.size() < 2) return Value::boolean(false);
        ensure_wsa();
        int port = static_cast<int>(args[0].as_i64());
        std::string response = args[1].to_string();

        SOCKET s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (s == INVALID_SOCKET) return Value::boolean(false);
        int yes = 1;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(static_cast<uint16_t>(port));
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if (::bind(s, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCK_ERR) {
            CLOSESOCK(s);
            return Value::boolean(false);
        }
        if (::listen(s, 1) == SOCK_ERR) {
            CLOSESOCK(s);
            return Value::boolean(false);
        }
        SOCKET c = ::accept(s, nullptr, nullptr);
        if (c == INVALID_SOCKET) {
            CLOSESOCK(s);
            return Value::boolean(false);
        }
        char buf[8192];
        ::recv(c, buf, sizeof(buf), 0); // drain request
        ::send(c, response.data(), static_cast<int>(response.size()), 0);
        CLOSESOCK(c);
        CLOSESOCK(s);
        return Value::boolean(true);
    });

    // socket count (debug)
    vm->register_native_module("server", "socket_count", [](const std::vector<Value>&, VM&) {
        return Value::make_i64(static_cast<int64_t>(g_sockets.size()));
    });
}

} // namespace phoenix

#if defined(PHX_MODULE_SHARED)
extern "C" void phoenix_module_init(VM* vm) {
    phoenix::register_phx_server_module(vm);
}
#endif
