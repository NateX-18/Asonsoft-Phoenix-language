#!/usr/bin/env python3
"""
pyside6_editor.py — Phoenix Language IDE (Mobile & Desktop)
Updated for the C++ Phoenix 1.1.0 runtime (native `phx` executable).

Config: phx_editor_config.json  (or ~/.phx_editor_config.json)
  { "runtime_path": "/absolute/path/to/phx", "autosave": false, ... }

Features:
  - Multitab editor with line numbers & Phoenix syntax highlighting
  - Touch-friendly drag scrolling (NoWrap + kinetic gestures)
  - Integrated terminal that runs the C++ phx binary
  - Compile to .pxc / package helpers via the real CLI
  - Samples matching current Phoenix (time/os/server/classes/dicts)
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from argparse import ArgumentParser, RawTextHelpFormatter
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import (
    Qt, QEvent, QProcess, QRect, QRegularExpression, QSize, QStringListModel, QTimer, Slot,
)
from PySide6.QtGui import (
    QAction, QColor, QFont, QKeySequence, QPainter, QPaintEvent, QPalette,
    QSyntaxHighlighter, QTextCharFormat, QTextCursor,
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QCompleter, QDialog, QFileDialog, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit,
    QPushButton, QSplitter, QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

# =============================================================================
# Defaults
# =============================================================================
DEFAULT_FILENAME = "untitled.phx"
WINDOW_TITLE = "Phoenix Editor"
CONFIG_NAME = "phx_editor_config.json"
TAB_WIDTH = 2

COLORS = {
    "background": "#0b0b0b",
    "comment": "#8a8a8a",
    "module_orange": "#ff8c00",
    "identifier_pink": "#ff69b4",
    "kw_deep_sky": "#00bfff",
    "kw_light_blue": "#4da6ff",
    "kw_crimson": "#dc143c",
    "kw_brown": "#c4783a",
    "kw_purple": "#c084fc",
    "kw_green": "#34d399",
    "kw_teal": "#2dd4bf",
    "string": "#90ee90",
    "number": "#00ced1",
    "bools_blue": "#1e90ff",
    "func_yellow": "#ffd700",
    "type_cyan": "#67e8f9",
    "terminal_bg": "#000000",
    "terminal_fg": "#aaffaa",
}

# Full keyword set for current Phoenix 1.1 language
PHX_KEYWORDS_GROUPS = {
    "decls": ["let", "const", "var", "dict", "list", "class", "system", "define", "struct"],
    "flow": ["if", "elif", "else", "while", "for", "forevery", "break", "continue", "return"],
    "error": ["attempt", "fail", "always", "success", "throw", "catch"],
    "modules": ["import", "load", "from", "as", "export", "module"],
    "bools": ["True", "False", "true", "false", "nil", "null", "and", "or", "not", "in"],
    "types": ["int", "float", "str", "bool", "void", "any", "i8", "i16", "i32", "i64",
              "u8", "u16", "u32", "u64", "number", "string"],
    "mode": ["mode", "std", "net", "gui", "safe"],
    "misc": ["new_init__", "new__init__", "display", "input", "len", "open", "close",
             "read", "readln", "write", "seek", "mkdir", "copy", "move", "delete"],
}

# Native module names highlighted as modules
PHX_NATIVE_MODULES = [
    "time", "os", "server", "http", "net", "urlrequest", "math", "utils",
    "packager", "sys", "fs",
]

# =============================================================================
# Current Phoenix samples (C++ runtime compatible)
# =============================================================================
SAMPLES = {
    "Hello + Time": r'''// Phoenix 1.1 — Hello + time module
mode std

display("Hello from Phoenix!")
display("Now:", @time.datetime())
display("ISO :", @time.iso8601())
display("Platform:", @os.platform())
''',

    "Functions": r'''// Phoenix 1.1 — Functions & return types
mode std

define add(a, b) <~> int {
    let s = a + b
    return s
}

define greet(name) <~> str {
    let text = "Hello, " + name
    display(text)
    return text
}

let n = add(12, 30)
display("12+30 =", n)
display(greet("Phoenix"))
''',

    "Class + Methods": r'''// Phoenix 1.1 — Class with constructor & methods
mode std

class Point {
    define new_init__(struct, x, y) {
        struct.x = x
        struct.y = y
    }

    define move(struct, dx, dy) {
        struct.x = struct.x + dx
        struct.y = struct.y + dy
    }

    define info(struct) <~> str {
        return "Point(" + struct.x + ", " + struct.y + ")"
    }
}

let p = Point(10, 20)
display(p.info())
p.move(5, -3)
display(p.info())
''',

    "Relational Dict": r'''// Phoenix 1.1 — Relational dict table
mode std

dict users[*"id", "name", "role"] = {
    [1, "Nathaniel", "Admin"],
    [2, "Ada", "Dev"],
    [3, "Grace", "Ops"]
}

display("User 1:", *$users[1])
display("User 2:", *$users[2])

$users["status"]
users[1] ~> ("status", "Active")
users[2] ~> ("status", "Active")
users[3] ~> ("status", "Review")

display("After status column:")
display(*$users[1])
display(*$users[3])
''',

    "OS + Paths": r'''// Phoenix 1.1 — OS module tour
mode std

display("OS      :", @os.name())
display("Arch    :", @os.arch())
display("Host    :", @os.hostname())
display("User    :", @os.username())
display("CWD     :", @os.cwd())
display("Home    :", @os.home())
display("CPUs    :", @os.cpu_count())

list entries = @os.path_listdir(".")
let i = 0
forevery (name in entries) {
    if (i < 8) {
        display(" ", name)
        i = i + 1
    }
}
''',

    "TCP Echo": r'''// Phoenix 1.1 — Single-shot TCP echo
mode net

let port = 18765
let server = @server.tcp_listen(port)
if (server < 0) {
    display("Could not listen on", port)
} else {
    let client = @server.tcp_connect("127.0.0.1", port)
    let peer = @server.tcp_accept(server)
    @server.tcp_send(client, "ping from Phoenix")
    let got = @server.tcp_recv(peer, 1024)
    display("Server got:", got)
    @server.tcp_send(peer, "ECHO: " + got)
    display("Client got:", @server.tcp_recv(client, 1024))
    @server.tcp_close(peer)
    @server.tcp_close(client)
    @server.tcp_close(server)
}
''',

    "HTTP Probe": r'''// Phoenix 1.1 — URL tools + optional live GET
mode net

let u = @server.url_parse("https://example.com/api?q=1")
display("host:", u.host, " path:", u.path, " query:", u.query)

display("encoded:", @server.url_encode("hello world"))
display("status :", @server.http_status_text(404))

let body = @http.get("https://example.com")
display("GET bytes:", len(body))
''',

    "Loops + Timer": r'''// Phoenix 1.1 — Loops & stopwatch
mode std

let t = @time.timer_start()
let sum = 0
let i = 1
while (i <= 100) {
    sum = sum + i
    i = i + 1
}
display("Sum 1..100 =", sum)
display("Elapsed s  =", @time.timer_stop(t))

list nums = [10, 20, 30]
forevery (n in nums) {
    display(" item:", n)
}
''',
}


# =============================================================================
# Config helpers
# =============================================================================
def bundle_dir() -> Path:
    if getattr(sys, "_MEIPASS", None):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def config_candidates() -> List[Path]:
    return [
        bundle_dir() / CONFIG_NAME,
        Path.cwd() / CONFIG_NAME,
        Path.home() / f".{CONFIG_NAME}",
        Path.home() / CONFIG_NAME,
    ]


def load_config() -> dict:
    defaults = {
        "runtime_path": "",
        "runtime_args": [],
        "autosave": False,
        "font_family": "Monospace",
        "font_size": 12,
        "tab_width": TAB_WIDTH,
        "theme": "dark",
    }
    for p in config_candidates():
        if p.is_file():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                defaults.update({k: v for k, v in data.items() if not str(k).startswith("notes")})
                defaults["_config_file"] = str(p)
                return defaults
            except Exception:
                continue
    # seed a local config next to the editor if missing
    seed = bundle_dir() / CONFIG_NAME
    try:
        if not seed.exists():
            seed.write_text(json.dumps({
                "runtime_path": "",
                "runtime_args": [],
                "autosave": False,
                "font_family": "Monospace",
                "font_size": 12,
                "tab_width": 2,
                "theme": "dark",
                "notes": "Set runtime_path to your native phx binary (e.g. /usr/local/bin/phx or C:\\\\phx\\\\phx.exe).",
            }, indent=2), encoding="utf-8")
        defaults["_config_file"] = str(seed)
    except Exception:
        pass
    return defaults


def save_config(cfg: dict) -> None:
    path = Path(cfg.get("_config_file") or (bundle_dir() / CONFIG_NAME))
    out = {k: v for k, v in cfg.items() if not k.startswith("_")}
    try:
        path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    except Exception as e:
        print("Could not save config:", e, file=sys.stderr)


def resolve_runtime(cfg: dict) -> List[str]:
    """Return argv prefix that launches the C++ phx runtime."""
    path = (cfg.get("runtime_path") or "").strip()
    extra = list(cfg.get("runtime_args") or [])

    def as_cmd(p: Path) -> List[str]:
        s = str(p)
        if p.suffix.lower() == ".py":
            return [sys.executable, s] + extra
        return [s] + extra

    if path:
        p = Path(path).expanduser()
        if p.is_file():
            return as_cmd(p.resolve())
        # allow bare name on PATH
        found = shutil.which(path)
        if found:
            return as_cmd(Path(found))

    # Auto-search near editor / CWD / PATH
    names = ["phx", "phx.exe", "phoenix", "phoenix.exe"]
    search_dirs = [bundle_dir(), Path.cwd(), Path.cwd() / "build", bundle_dir() / "build"]
    for d in search_dirs:
        for name in names:
            cand = d / name
            if cand.is_file() and os.access(cand, os.X_OK):
                return as_cmd(cand.resolve())
    for name in names:
        found = shutil.which(name)
        if found:
            return as_cmd(Path(found))
    return []


# =============================================================================
# Line numbers
# =============================================================================
class LineNumberArea(QWidget):
    def __init__(self, editor: "PhoenixTextEdit"):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event: QPaintEvent):
        self.editor.line_number_area_paint_event(event)


# =============================================================================
# Syntax highlighter
# =============================================================================
class PhoenixHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rules = []

        def fmt(color: str, bold=False, italic=False):
            f = QTextCharFormat()
            f.setForeground(QColor(color))
            if bold:
                f.setFontWeight(QFont.Bold)
            if italic:
                f.setFontItalic(True)
            return f

        self.comment_format = fmt(COLORS["comment"], italic=True)
        self.string_format = fmt(COLORS["string"])
        self.number_format = fmt(COLORS["number"])
        self.func_format = fmt(COLORS["func_yellow"], bold=True)
        self.identifier_format = fmt(COLORS["identifier_pink"])
        self.module_at_format = fmt(COLORS["module_orange"], bold=True)
        self.type_arrow_format = fmt(COLORS["type_cyan"])

        group_colors = {
            "decls": COLORS["kw_deep_sky"],
            "flow": COLORS["kw_crimson"],
            "error": COLORS["kw_crimson"],
            "modules": COLORS["kw_purple"],
            "bools": COLORS["bools_blue"],
            "types": COLORS["type_cyan"],
            "mode": COLORS["kw_teal"],
            "misc": COLORS["kw_light_blue"],
        }

        # Schema $name
        self.rules.append((QRegularExpression(r"\$[A-Za-z_][A-Za-z0-9_]*"),
                           fmt(COLORS["kw_deep_sky"], bold=True)))
        # @module.fn
        self.rules.append((QRegularExpression(r"@[A-Za-z_][A-Za-z0-9_]*"),
                           self.module_at_format))
        # <~> type arrow
        self.rules.append((QRegularExpression(r"<~>"), self.type_arrow_format))
        # ~> stream
        self.rules.append((QRegularExpression(r"~>"), fmt(COLORS["kw_green"], bold=True)))
        # *$ dereference
        self.rules.append((QRegularExpression(r"\*\$"), fmt(COLORS["kw_deep_sky"], bold=True)))

        for group, words in PHX_KEYWORDS_GROUPS.items():
            color = group_colors.get(group, COLORS["kw_light_blue"])
            f = fmt(color, bold=True)
            for w in words:
                self.rules.append((QRegularExpression(rf"\b{re.escape(w)}\b"), f))

        for mod in PHX_NATIVE_MODULES:
            self.rules.append((QRegularExpression(rf"\b{re.escape(mod)}\b"),
                               fmt(COLORS["module_orange"])))

        self.rules.append((QRegularExpression(r"\b\d+(\.\d+)?\b"), self.number_format))
        self.rules.append((QRegularExpression(r"\b[A-Za-z_][A-Za-z0-9_]*(?=\()"), self.func_format))

    def highlightBlock(self, text: str):
        self.setFormat(0, len(text), self.identifier_format)
        for pattern, form in self.rules:
            it = pattern.globalMatch(text)
            while it.hasNext():
                m = it.next()
                self.setFormat(m.capturedStart(), m.capturedLength(), form)

        # strings
        for pattern in (r"'([^'\\]|\\.)*'", r'"([^"\\]|\\.)*"'):
            it = QRegularExpression(pattern).globalMatch(text)
            while it.hasNext():
                m = it.next()
                self.setFormat(m.capturedStart(), m.capturedLength(), self.string_format)

        # comments last
        it = QRegularExpression(r"(//[^\n]*|#[^\n]*)").globalMatch(text)
        while it.hasNext():
            m = it.next()
            self.setFormat(m.capturedStart(), m.capturedLength(), self.comment_format)


# =============================================================================
# Editor (touch scroll + pairs + completer)
# =============================================================================
class PhoenixTextEdit(QPlainTextEdit):
    def __init__(self, parent=None, font_family="Monospace", font_size=12):
        super().__init__(parent)
        self.parent_app = parent
        self.setStyleSheet(
            f"background-color: {COLORS['background']}; color: #ffffff; "
            f"selection-background-color: #444444; border: none;"
        )
        self.setFont(QFont(font_family, font_size))
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(" ") * TAB_WIDTH)

        # Touch / trackpad friendly scrolling
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.viewport().setAttribute(Qt.WA_AcceptTouchEvents, True)
        self.setAttribute(Qt.WA_AcceptTouchEvents, True)
        try:
            # Qt 5.12+ kinetic scrolling on touch
            from PySide6.QtWidgets import QScroller
            QScroller.grabGesture(self.viewport(), QScroller.LeftMouseButtonGesture)
            QScroller.grabGesture(self.viewport(), QScroller.TouchGesture)
        except Exception:
            pass

        self._touch_last_y = None
        self._touch_last_x = None

        self.completer = QCompleter(self)
        self.completer.setWidget(self)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.activated.connect(self.insert_completion)

        self.highlighter = PhoenixHighlighter(self.document())
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)
        self.update_line_number_area_width(0)

    def line_number_area_width(self) -> int:
        digits = max(1, len(str(max(1, self.blockCount()))))
        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def update_line_number_area_width(self, _=None):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect: QRect, dy: int):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height()))

    def line_number_area_paint_event(self, event: QPaintEvent):
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#141416"))
        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.setPen(QColor("#71717a"))
                painter.drawText(0, int(top), self.line_number_area.width() - 4,
                                 self.fontMetrics().height(), Qt.AlignRight, str(block_number + 1))
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1

    def highlight_current_line(self):
        extra = []
        if not self.isReadOnly():
            sel = QTextEdit.ExtraSelection()
            sel.format.setBackground(QColor("#1e1e24"))
            sel.format.setProperty(QTextCharFormat.FullWidthSelection, True)
            sel.cursor = self.textCursor()
            sel.cursor.clearSelection()
            extra.append(sel)
        self.setExtraSelections(extra)

    def event(self, event):
        # Manual touch drag scroll (fallback if QScroller unavailable)
        if event.type() in (QEvent.TouchBegin, QEvent.TouchUpdate, QEvent.TouchEnd):
            try:
                points = event.points() if hasattr(event, "points") else event.touchPoints()
            except Exception:
                points = []
            if points:
                p = points[0]
                pos = p.position() if hasattr(p, "position") else p.pos()
                if event.type() == QEvent.TouchBegin:
                    self._touch_last_y = pos.y()
                    self._touch_last_x = pos.x()
                elif event.type() == QEvent.TouchUpdate and self._touch_last_y is not None:
                    dy = int(self._touch_last_y - pos.y())
                    dx = int(self._touch_last_x - pos.x())
                    self.verticalScrollBar().setValue(self.verticalScrollBar().value() + dy)
                    self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() + dx)
                    self._touch_last_y = pos.y()
                    self._touch_last_x = pos.x()
                elif event.type() == QEvent.TouchEnd:
                    self._touch_last_y = None
                    self._touch_last_x = None
                return True
        return super().event(event)

    def keyPressEvent(self, event):
        pairs = {"(": ")", "[": "]", "{": "}", '"': '"', "'": "'"}
        char = event.text()
        if char in pairs:
            tc = self.textCursor()
            if tc.hasSelection():
                selected = tc.selectedText()
                tc.insertText(char + selected + pairs[char])
            else:
                pos = tc.position()
                self.insertPlainText(char + pairs[char])
                tc.setPosition(pos + 1)
                self.setTextCursor(tc)
            return
        super().keyPressEvent(event)
        if char and (char.isalnum() or char == "_" or char == "@"):
            self.show_autocomplete()

    def show_autocomplete(self):
        tc = self.textCursor()
        tc.select(QTextCursor.WordUnderCursor)
        word = tc.selectedText()
        if len(word) < 1:
            self.completer.popup().hide()
            return
        words = set(re.findall(r"@?[A-Za-z_][A-Za-z0-9_]*", self.toPlainText()))
        for group in PHX_KEYWORDS_GROUPS.values():
            words.update(group)
        for m in PHX_NATIVE_MODULES:
            words.add(m)
            words.add("@" + m)
        model = QStringListModel(sorted(words), self.completer)
        self.completer.setModel(model)
        self.completer.setCompletionPrefix(word)
        cr = self.cursorRect()
        cr.setWidth(self.completer.popup().sizeHintForColumn(0)
                    + self.completer.popup().verticalScrollBar().sizeHint().width() + 20)
        self.completer.complete(cr)

    def insert_completion(self, completion: str):
        tc = self.textCursor()
        prefix = self.completer.completionPrefix()
        extra = len(completion) - len(prefix)
        if extra > 0:
            tc.movePosition(QTextCursor.Left)
            tc.movePosition(QTextCursor.EndOfWord)
            tc.insertText(completion[-extra:])
            self.setTextCursor(tc)

    def format_code(self):
        lines = [ln.rstrip().replace("\t", " " * TAB_WIDTH) for ln in self.toPlainText().splitlines()]
        self.setPlainText("\n".join(lines) + ("\n" if lines else ""))


# =============================================================================
# Terminal (runs native phx via shell)
# =============================================================================
class OSTerminalPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_app = parent
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        header = QWidget()
        header.setStyleSheet("background-color: #1e1e24; border-bottom: 1px solid #333;")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(8, 4, 8, 4)
        title = QLabel("Phoenix Terminal")
        title.setStyleSheet("color: #fff; font-weight: bold;")
        hl.addWidget(title)
        hl.addStretch()
        self.runtime_label = QLabel("")
        self.runtime_label.setStyleSheet("color: #71717a; font-size: 9pt;")
        hl.addWidget(self.runtime_label)
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet("background:#ef4444;color:#fff;border-radius:4px;padding:2px 10px;")
        close_btn.clicked.connect(lambda: self.parent_app.toggle_terminal_view(False))
        hl.addWidget(close_btn)
        layout.addWidget(header)

        self.terminal_display = QTextEdit()
        self.terminal_display.setStyleSheet(
            f"background:{COLORS['terminal_bg']}; color:{COLORS['terminal_fg']}; "
            f"font-family: Monospace; font-size: 11pt; border: none;"
        )
        self.terminal_display.setReadOnly(False)
        self.terminal_display.installEventFilter(self)
        try:
            from PySide6.QtWidgets import QScroller
            QScroller.grabGesture(self.terminal_display.viewport(), QScroller.TouchGesture)
            QScroller.grabGesture(self.terminal_display.viewport(), QScroller.LeftMouseButtonGesture)
        except Exception:
            pass
        layout.addWidget(self.terminal_display)

        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self._read_stdout)
        self.process.readyReadStandardError.connect(self._read_stderr)
        self.process.finished.connect(self._on_finished)
        self._prompt_pos = 0
        self._starting = False
        self.start_shell()

    def start_shell(self):
        if self.process.state() != QProcess.NotRunning:
            self.process.kill()
            self.process.waitForFinished(1000)
        if sys.platform.startswith("win"):
            shell, args = "cmd.exe", []
        else:
            # Prefer interactive bash/sh available on desktop & Android
            if os.path.exists("/bin/bash"):
                shell, args = "/bin/bash", ["-i"]
            elif os.path.exists("/system/bin/sh"):
                shell, args = "/system/bin/sh", ["-i"]
            else:
                shell, args = "/bin/sh", ["-i"]
        self.process.start(shell, args)
        self.append_text(f">>> Terminal ready ({shell})\n")
        self._prompt_pos = self.terminal_display.textCursor().position()

    def append_text(self, text: str):
        self.terminal_display.moveCursor(QTextCursor.End)
        self.terminal_display.insertPlainText(text)
        self.terminal_display.moveCursor(QTextCursor.End)
        self._prompt_pos = self.terminal_display.textCursor().position()

    def _read_stdout(self):
        data = bytes(self.process.readAllStandardOutput()).decode("utf-8", errors="replace")
        if data:
            self.append_text(data)

    def _read_stderr(self):
        data = bytes(self.process.readAllStandardError()).decode("utf-8", errors="replace")
        if data:
            self.append_text(data)

    def _on_finished(self, code, _status):
        self.append_text(f"\n[shell exited: {code}] — restarting...\n")
        QTimer.singleShot(300, self.start_shell)

    def write_command(self, cmd: str):
        if not cmd.endswith("\n"):
            cmd += "\n"
        self.append_text(cmd)
        if self.process.state() == QProcess.Running:
            self.process.write(cmd.encode("utf-8"))

    def set_runtime_hint(self, text: str):
        self.runtime_label.setText(text)

    def eventFilter(self, obj, event):
        if obj is self.terminal_display and event.type() == QEvent.KeyPress:
            key = event.key()
            if key in (Qt.Key_Return, Qt.Key_Enter):
                cursor = self.terminal_display.textCursor()
                cursor.movePosition(QTextCursor.End)
                block = self.terminal_display.document().findBlockByNumber(cursor.blockNumber())
                line = block.text()
                # Strip common prompts
                for sep in ("$ ", "> ", "# ", ">>> "):
                    if sep in line:
                        line = line.split(sep)[-1]
                        break
                line = line.strip()
                self.process.write((line + "\n").encode("utf-8"))
                self.terminal_display.insertPlainText("\n")
                self._prompt_pos = self.terminal_display.textCursor().position()
                return True
            if key == Qt.Key_Backspace:
                if self.terminal_display.textCursor().position() <= self._prompt_pos:
                    return True
            # Block editing output above prompt
            if key not in (Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down,
                           Qt.Key_Home, Qt.Key_End, Qt.Key_Shift, Qt.Key_Control):
                if self.terminal_display.textCursor().position() < self._prompt_pos:
                    self.terminal_display.moveCursor(QTextCursor.End)
        return super().eventFilter(obj, event)


# =============================================================================
# Navigation drawer
# =============================================================================
class NavigationDrawer(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_app = parent
        self.setStyleSheet("background-color: #1a1a24; border-right: 2px solid #333;")
        self.setFixedWidth(280)
        self.setVisible(False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 20, 15, 15)

        title = QLabel("PHOENIX WORKSPACE")
        title.setStyleSheet("color:#fff; font-weight:bold; font-size:14pt; margin-bottom:12px;")
        layout.addWidget(title)

        samples_header = QLabel("Samples (Phoenix 1.1)")
        samples_header.setStyleSheet("color:#1e90ff; font-weight:bold; font-size:11pt;")
        layout.addWidget(samples_header)

        for name in SAMPLES:
            btn = QPushButton(name)
            btn.setStyleSheet(
                "text-align:left; padding:10px; background:#27273a; color:#fff; "
                "border:none; border-radius:4px;"
            )
            btn.clicked.connect(lambda checked=False, n=name: self.load_sample(n))
            layout.addWidget(btn)

        layout.addSpacing(16)
        pref = QPushButton("Preferences / Runtime")
        pref.setStyleSheet(
            "padding:10px; background:#3b82f6; color:#fff; border:none; "
            "border-radius:4px; font-weight:bold;"
        )
        pref.clicked.connect(self.parent_app.open_preferences)
        layout.addWidget(pref)
        layout.addStretch()
        foot = QLabel("Asonsoft · NXT Tech · Phoenix 1.1")
        foot.setStyleSheet("color:#71717a; font-size:9pt;")
        foot.setAlignment(Qt.AlignCenter)
        layout.addWidget(foot)

    def load_sample(self, name: str):
        content = SAMPLES[name]
        fname = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") + ".phx"
        self.parent_app.new_tab(fname, content)
        self.setVisible(False)


# =============================================================================
# Find / replace
# =============================================================================
class FindReplacePanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_app = parent
        self.setStyleSheet("background:#1e1e24; border-bottom:1px solid #333;")
        self.setFixedHeight(90)
        self.setVisible(False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        row1 = QHBoxLayout()
        self.find_input = QLineEdit()
        self.find_input.setPlaceholderText("Find…")
        self.replace_input = QLineEdit()
        self.replace_input.setPlaceholderText("Replace…")
        row1.addWidget(self.find_input)
        row1.addWidget(self.replace_input)
        layout.addLayout(row1)
        row2 = QHBoxLayout()
        for label, slot in (
            ("Find Next", self.find_next),
            ("Replace", self.replace),
            ("Replace All", self.replace_all),
            ("Close", self.hide),
        ):
            b = QPushButton(label)
            b.clicked.connect(slot)
            row2.addWidget(b)
        layout.addLayout(row2)

    def get_editor(self) -> Optional[PhoenixTextEdit]:
        return self.parent_app.get_current_editor()

    def find_next(self):
        editor = self.get_editor()
        if not editor:
            return
        q = self.find_input.text()
        if not q:
            return
        if not editor.find(q):
            editor.moveCursor(QTextCursor.Start)
            editor.find(q)

    def replace(self):
        editor = self.get_editor()
        if not editor:
            return
        tc = editor.textCursor()
        if tc.hasSelection() and tc.selectedText() == self.find_input.text():
            tc.insertText(self.replace_input.text())
        self.find_next()

    def replace_all(self):
        editor = self.get_editor()
        if not editor:
            return
        q, r = self.find_input.text(), self.replace_input.text()
        if not q:
            return
        editor.setPlainText(editor.toPlainText().replace(q, r))


# =============================================================================
# Compiler suite (native phx)
# =============================================================================
class CompilerSuiteDialog(QDialog):
    def __init__(self, parent, file_path: str, runtime_cmd: List[str]):
        super().__init__(parent)
        self.setWindowTitle("Compiler & Packager")
        self.resize(480, 320)
        self.file_path = file_path
        self.runtime_cmd = runtime_cmd
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Target: {os.path.basename(file_path)}"))
        layout.addWidget(QLabel(f"Runtime: {' '.join(runtime_cmd) if runtime_cmd else '(not set)'}"))
        layout.addSpacing(8)

        for text, slot in (
            ("Compile → .pxc object", self.run_compile),
            ("Package → shell launcher (.sh)", lambda: self.run_package("sh")),
            ("Package → Windows launcher (.bat)", lambda: self.run_package("bat")),
            ("Package → payload .pxe", lambda: self.run_package("pxe")),
            ("Package → stub+payload binary", lambda: self.run_package("exe")),
        ):
            b = QPushButton(text)
            b.clicked.connect(slot)
            layout.addWidget(b)
        layout.addSpacing(10)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close)

    def _phx(self, *args: str) -> List[str]:
        if not self.runtime_cmd:
            raise RuntimeError("Runtime path not configured")
        return list(self.runtime_cmd) + list(args)

    def run_compile(self):
        try:
            cmd = self._phx("compile", self.file_path)
            self._exec(cmd, "Compilation finished.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def run_package(self, kind: str):
        base = os.path.splitext(self.file_path)[0]
        pxc = base + ".pxc"
        if not os.path.exists(pxc):
            QMessageBox.warning(self, "Missing object", "Compile to .pxc first.")
            return
        # Use a tiny temp .phx that calls @packager.* so we stay on the language API
        out_map = {
            "sh": (base + ".run.sh", f'@packager.pxc_to_sh("{pxc}", "{base}.run.sh")\ndisplay("ok")\n'),
            "bat": (base + ".run.bat", f'@packager.pxc_to_bat("{pxc}", "{base}.run.bat")\ndisplay("ok")\n'),
            "pxe": (base + ".pxe", f'@packager.pxc_to_pxe("{pxc}", "{base}.pxe")\ndisplay("ok")\n'),
            "exe": (base + ".app.bin",
                    f'let stub = "phx"\n'
                    f'if (@os.path_exists("phx.exe")) {{ stub = "phx.exe" }}\n'
                    f'@packager.pxc_to_exe("{pxc}", "{base}.app.bin", stub)\n'
                    f'display("ok")\n'),
        }
        out_path, script = out_map[kind]
        tmp = base + ".__pack__.phx"
        try:
            Path(tmp).write_text(script, encoding="utf-8")
            cmd = self._phx("run", tmp)
            self._exec(cmd, f"Package written (see {os.path.basename(out_path)}).")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def _exec(self, cmd: List[str], ok_msg: str):
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if proc.returncode == 0:
                QMessageBox.information(self, "Success", f"{ok_msg}\n\n{proc.stdout}")
            else:
                QMessageBox.critical(self, "Failed", proc.stderr or proc.stdout or "Unknown error")
        except Exception as e:
            QMessageBox.critical(self, "Fault", str(e))


# =============================================================================
# Preferences
# =============================================================================
class PreferencesDialog(QDialog):
    def __init__(self, parent, settings: dict):
        super().__init__(parent)
        self.setWindowTitle("Preferences")
        self.resize(520, 240)
        self.settings = dict(settings)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Path to native Phoenix runtime (phx / phx.exe):"))
        self.runtime_entry = QLineEdit(self.settings.get("runtime_path", ""))
        self.runtime_entry.setPlaceholderText("/path/to/phx   or   C:\\path\\phx.exe")
        layout.addWidget(self.runtime_entry)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        layout.addWidget(browse)
        self.autosave_check = QCheckBox("Autosave while typing")
        self.autosave_check.setChecked(bool(self.settings.get("autosave")))
        layout.addWidget(self.autosave_check)
        layout.addWidget(QLabel(f"Config file: {self.settings.get('_config_file', CONFIG_NAME)}"))
        row = QHBoxLayout()
        save = QPushButton("Save")
        save.clicked.connect(self.accept)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        row.addWidget(save)
        row.addWidget(cancel)
        layout.addLayout(row)

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select phx runtime", "", "All Files (*)")
        if path:
            self.runtime_entry.setText(path)

    def get_settings(self) -> dict:
        return {
            "runtime_path": self.runtime_entry.text().strip(),
            "autosave": self.autosave_check.isChecked(),
        }


# =============================================================================
# Main window
# =============================================================================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._cur_file = ""
        self._settings = load_config()
        self.setWindowTitle(WINDOW_TITLE)
        self.resize(960, 640)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.drawer = NavigationDrawer(self)
        main_layout.addWidget(self.drawer)

        workspace = QWidget()
        ws = QVBoxLayout(workspace)
        ws.setContentsMargins(0, 0, 0, 0)
        ws.setSpacing(0)

        header = QWidget()
        header.setStyleSheet("background:#141416; border-bottom:1px solid #333;")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(6, 6, 6, 6)
        burger = QPushButton("☰")
        burger.setFixedSize(40, 34)
        burger.setStyleSheet("font-size:14pt; background:#1e1e24; color:#fff; border:none; border-radius:4px;")
        burger.clicked.connect(self.toggle_navigation_drawer)
        hl.addWidget(burger)
        self.file_title_label = QLabel("Active: untitled.phx")
        self.file_title_label.setStyleSheet("color:#fff; font-weight:bold; margin-left:8px;")
        hl.addWidget(self.file_title_label)
        hl.addStretch()
        self.runtime_status = QLabel("")
        self.runtime_status.setStyleSheet("color:#71717a; font-size:9pt;")
        hl.addWidget(self.runtime_status)
        ws.addWidget(header)

        self.find_replace_panel = FindReplacePanel(self)
        ws.addWidget(self.find_replace_panel)

        self.splitter = QSplitter(Qt.Vertical)
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.setMovable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.tab_index_changed)
        self.splitter.addWidget(self.tab_widget)

        self.terminal_panel = OSTerminalPanel(self)
        self.splitter.addWidget(self.terminal_panel)
        self.splitter.setSizes([480, 280])
        ws.addWidget(self.splitter)
        main_layout.addWidget(workspace)

        self.create_actions()
        self.create_menus()
        self.create_tool_bars()
        self.statusBar().showMessage("Ready")
        self.refresh_runtime_status()
        self.new_tab()

    def runtime_cmd(self) -> List[str]:
        return resolve_runtime(self._settings)

    def refresh_runtime_status(self):
        cmd = self.runtime_cmd()
        if cmd:
            text = "Runtime: " + " ".join(cmd)
            self.runtime_status.setText(text)
            self.terminal_panel.set_runtime_hint(text)
        else:
            msg = "Runtime: NOT SET — open Preferences"
            self.runtime_status.setText(msg)
            self.terminal_panel.set_runtime_hint(msg)

    def get_current_editor(self) -> Optional[PhoenixTextEdit]:
        w = self.tab_widget.currentWidget()
        return w.findChild(PhoenixTextEdit) if w else None

    def toggle_navigation_drawer(self):
        self.drawer.setVisible(not self.drawer.isVisible())

    def new_tab(self, title=DEFAULT_FILENAME, content="// Phoenix 1.1\nmode std\n\ndisplay(\"hello\")\n"):
        frame = QWidget()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        editor = PhoenixTextEdit(
            self,
            font_family=self._settings.get("font_family", "Monospace"),
            font_size=int(self._settings.get("font_size", 12)),
        )
        editor.setPlainText(content)
        editor.document().contentsChanged.connect(self.document_was_modified)
        layout.addWidget(editor)
        frame.setProperty("file_path", "")
        frame.setProperty("modified", False)
        idx = self.tab_widget.addTab(frame, title)
        self.tab_widget.setCurrentIndex(idx)

    def close_tab(self, index: int):
        widget = self.tab_widget.widget(index)
        if widget and widget.property("modified"):
            ret = QMessageBox.warning(
                self, "Unsaved", f"Save {self.tab_widget.tabText(index)}?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            )
            if ret == QMessageBox.Save:
                self.save()
            elif ret == QMessageBox.Cancel:
                return
        self.tab_widget.removeTab(index)
        if widget:
            widget.deleteLater()
        if self.tab_widget.count() == 0:
            self.new_tab()

    def tab_index_changed(self, index: int):
        widget = self.tab_widget.widget(index)
        if not widget:
            return
        path = widget.property("file_path") or ""
        self._cur_file = path
        name = os.path.basename(path) if path else DEFAULT_FILENAME
        self.file_title_label.setText(f"Active: {name}")
        self.setWindowTitle(f"{name}[*] — {WINDOW_TITLE}")
        self.setWindowModified(bool(widget.property("modified")))

    def document_was_modified(self):
        idx = self.tab_widget.currentIndex()
        widget = self.tab_widget.widget(idx)
        if widget:
            widget.setProperty("modified", True)
            self.setWindowModified(True)
            if self._settings.get("autosave") and self._cur_file:
                self.save_file(self._cur_file)

    def load_file(self, path: str):
        try:
            content = Path(path).read_text(encoding="utf-8")
        except Exception as e:
            QMessageBox.warning(self, "Open failed", str(e))
            return
        self.new_tab(os.path.basename(path), content)
        widget = self.tab_widget.currentWidget()
        widget.setProperty("file_path", path)
        widget.setProperty("modified", False)
        self._cur_file = path
        self.tab_index_changed(self.tab_widget.currentIndex())
        self.statusBar().showMessage(f"Loaded {path}", 2500)

    def save_file(self, path: str) -> bool:
        editor = self.get_current_editor()
        if not editor:
            return False
        try:
            Path(path).write_text(editor.toPlainText(), encoding="utf-8")
        except Exception as e:
            QMessageBox.warning(self, "Save failed", str(e))
            return False
        widget = self.tab_widget.currentWidget()
        widget.setProperty("file_path", path)
        widget.setProperty("modified", False)
        self.tab_widget.setTabText(self.tab_widget.currentIndex(), os.path.basename(path))
        self._cur_file = path
        self.setWindowModified(False)
        self.statusBar().showMessage(f"Saved {path}", 2000)
        return True

    @Slot()
    def new_file(self):
        self.new_tab()

    @Slot()
    def open(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open", "", "Phoenix (*.phx);;All (*)")
        if path:
            self.load_file(path)

    @Slot()
    def save(self):
        if self._cur_file:
            return self.save_file(self._cur_file)
        return self.save_as()

    @Slot()
    def save_as(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save As", "", "Phoenix (*.phx);;All (*)")
        if path:
            if not path.endswith(".phx"):
                path += ".phx"
            return self.save_file(path)
        return False

    @Slot()
    def format_code(self):
        ed = self.get_current_editor()
        if ed:
            ed.format_code()

    @Slot()
    def show_find_replace(self):
        self.find_replace_panel.setVisible(True)
        self.find_replace_panel.find_input.setFocus()

    @Slot()
    def run_program(self):
        editor = self.get_current_editor()
        if not editor:
            return
        if not self._cur_file:
            if not self.save_as():
                return
        else:
            self.save_file(self._cur_file)

        cmd = self.runtime_cmd()
        if not cmd:
            QMessageBox.critical(
                self, "Runtime missing",
                "Set the path to your native `phx` binary in Preferences "
                f"or edit {CONFIG_NAME}.",
            )
            self.open_preferences()
            return

        self.toggle_terminal_view(True)
        script_dir = os.path.dirname(os.path.abspath(self._cur_file))
        script_name = os.path.basename(self._cur_file)

        # Quote safely for shell
        def q(s: str) -> str:
            if sys.platform.startswith("win"):
                return f'"{s}"'
            return "'" + s.replace("'", "'\\''") + "'"

        cd = f"cd {q(script_dir)}\n"
        run = " ".join(q(c) for c in cmd) + f" run {q(script_name)}\n"
        self.terminal_panel.write_command(cd)
        self.terminal_panel.write_command(run)

    @Slot()
    def open_compiler_suite(self):
        if not self._cur_file:
            QMessageBox.warning(self, "Compile", "Save the file first.")
            return
        cmd = self.runtime_cmd()
        if not cmd:
            QMessageBox.critical(self, "Runtime missing", "Configure runtime_path first.")
            return
        CompilerSuiteDialog(self, self._cur_file, cmd).exec()

    def toggle_terminal_view(self, visible: bool):
        self.terminal_panel.setVisible(visible)
        if visible:
            self.splitter.setSizes([480, 280])

    @Slot()
    def toggle_terminal_action(self):
        self.toggle_terminal_view(not self.terminal_panel.isVisible())

    @Slot()
    def open_preferences(self):
        dlg = PreferencesDialog(self, self._settings)
        if dlg.exec():
            self._settings.update(dlg.get_settings())
            save_config(self._settings)
            self.refresh_runtime_status()

    @Slot()
    def about(self):
        QMessageBox.about(
            self, "About Phoenix Editor",
            "<b>Phoenix Editor</b> for the native C++ Phoenix 1.1 runtime.<br>"
            "Asonsoft &amp; NXT Tech Industries<br>"
            "Configure <code>phx_editor_config.json</code> → <code>runtime_path</code>.",
        )

    def create_actions(self):
        self._new = QAction("&New", self, shortcut=QKeySequence.New, triggered=self.new_file)
        self._open = QAction("&Open…", self, shortcut=QKeySequence.Open, triggered=self.open)
        self._save = QAction("&Save", self, shortcut=QKeySequence.Save, triggered=self.save)
        self._save_as = QAction("Save &As…", self, shortcut=QKeySequence.SaveAs, triggered=self.save_as)
        self._find = QAction("Find / Replace", self, shortcut=QKeySequence.Find, triggered=self.show_find_replace)
        self._format = QAction("Format", self, shortcut="Ctrl+I", triggered=self.format_code)
        self._run = QAction("Run", self, shortcut="F5", triggered=self.run_program)
        self._compile = QAction("Compile / Package", self, shortcut="Ctrl+Shift+B", triggered=self.open_compiler_suite)
        self._term = QAction("Terminal", self, shortcut="Ctrl+T", triggered=self.toggle_terminal_action)
        self._pref = QAction("Preferences", self, triggered=self.open_preferences)
        self._exit = QAction("E&xit", self, shortcut="Ctrl+Q", triggered=self.close)
        self._about = QAction("&About", self, triggered=self.about)

    def create_menus(self):
        m = self.menuBar().addMenu("&File")
        for a in (self._new, self._open, self._save, self._save_as):
            m.addAction(a)
        m.addSeparator()
        m.addAction(self._exit)
        m = self.menuBar().addMenu("&Edit")
        m.addAction(self._find)
        m.addAction(self._format)
        m = self.menuBar().addMenu("&Run")
        for a in (self._run, self._compile, self._term, self._pref):
            m.addAction(a)
        m = self.menuBar().addMenu("&Help")
        m.addAction(self._about)

    def create_tool_bars(self):
        tb = self.addToolBar("Main")
        tb.setIconSize(QSize(24, 24))
        for a in (self._new, self._open, self._save, self._run, self._compile, self._term):
            tb.addAction(a)

    def closeEvent(self, event):
        for i in range(self.tab_widget.count()):
            w = self.tab_widget.widget(i)
            if w and w.property("modified"):
                ret = QMessageBox.warning(
                    self, "Quit", "Unsaved changes. Save?",
                    QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                )
                if ret == QMessageBox.Save:
                    self.save()
                elif ret == QMessageBox.Cancel:
                    event.ignore()
                    return
        event.accept()


# =============================================================================
# Entry
# =============================================================================
def main():
    parser = ArgumentParser(description="Phoenix Editor (native runtime)", formatter_class=RawTextHelpFormatter)
    parser.add_argument("file", nargs="?", help="Optional .phx to open")
    parser.add_argument("--runtime", help="Override runtime_path for this session")
    opts = parser.parse_args()

    app = QApplication(sys.argv)
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(20, 20, 25))
    palette.setColor(QPalette.WindowText, Qt.white)
    palette.setColor(QPalette.Base, QColor(11, 11, 11))
    palette.setColor(QPalette.Text, Qt.white)
    palette.setColor(QPalette.Button, QColor(30, 30, 35))
    palette.setColor(QPalette.ButtonText, Qt.white)
    app.setPalette(palette)

    win = MainWindow()
    if opts.runtime:
        win._settings["runtime_path"] = opts.runtime
        win.refresh_runtime_status()
    if opts.file:
        win.load_file(opts.file)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
