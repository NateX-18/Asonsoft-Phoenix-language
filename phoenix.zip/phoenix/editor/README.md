# Phoenix Editor (PySide6) — C++ runtime edition

IDE for **Phoenix 1.1** with the **native C++ `phx` binary** (not the old Python runtime).

## Quick setup

1. Install PySide6:
   ```bash
   pip install PySide6
   ```

2. Edit `phx_editor_config.json` next to the editor (or `~/.phx_editor_config.json`):
   ```json
   {
     "runtime_path": "/absolute/path/to/phx",
     "autosave": false,
     "font_family": "Monospace",
     "font_size": 12
   }
   ```
   Windows example:
   ```json
   { "runtime_path": "C:\\Phoenix\\phx.exe" }
   ```

3. Run:
   ```bash
   python pyside6_editor.py
   # or
   python pyside6_editor.py /path/to/script.phx
   python pyside6_editor.py --runtime /path/to/phx
   ```

If `runtime_path` is empty, the editor searches for `phx` / `phx.exe` next to the script, in `./build`, and on `PATH`.

## What changed vs the old Python-runtime editor

| Area | Old | New |
|------|-----|-----|
| Run | `python phx.py run …` | Native `phx run file.phx` |
| Config | hardcoded names | `phx_editor_config.json` |
| Keywords | partial | Full 1.1 set + `@modules`, `<~>`, `~>`, types |
| Samples | outdated schema/GUI | time/os/server/class/dict samples |
| Terminal | Android-only `/system/bin/sh` bias | bash/sh/cmd + auto-restart |
| Touch | scrollbar only | QScroller + touch drag |
| Compile dialog | `phx.py compile` | `phx compile` + packager helpers |

## Shortcuts

- **F5** — save & run current file  
- **Ctrl+Shift+B** — compile / package suite  
- **Ctrl+T** — terminal  
- **Ctrl+F** — find/replace  
- **Ctrl+I** — trim trailing space / expand tabs  

## Controls → Phoenix CLI

- **Run** → `phx run <file.phx>`
- **Compile** → `phx compile <file.phx>` → `.pxc`
- **Package** → temporary script calling `@packager.pxc_to_*`

