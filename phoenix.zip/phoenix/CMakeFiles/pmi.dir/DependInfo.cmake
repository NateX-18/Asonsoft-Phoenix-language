
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/tools/pmi_main.cpp" "CMakeFiles/pmi.dir/src/tools/pmi_main.cpp.o" "gcc" "CMakeFiles/pmi.dir/src/tools/pmi_main.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/CMakeFiles/phoenix_core.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
