file(REMOVE_RECURSE
  "CMakeFiles/pmi.dir/src/tools/pmi_main.cpp.o"
  "CMakeFiles/pmi.dir/src/tools/pmi_main.cpp.o.d"
  "pmi"
  "pmi.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/pmi.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
