# Empty compiler generated dependencies file for phx.
# This may be replaced when dependencies are built.
