file(REMOVE_RECURSE
  "CMakeFiles/phx.dir/src/main.cpp.o"
  "CMakeFiles/phx.dir/src/main.cpp.o.d"
  "phx"
  "phx.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/phx.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
