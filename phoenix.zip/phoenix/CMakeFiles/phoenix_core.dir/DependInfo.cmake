
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/libs/os/os_mod.cpp" "CMakeFiles/phoenix_core.dir/libs/os/os_mod.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/libs/os/os_mod.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/libs/packager/packager_mod.cpp" "CMakeFiles/phoenix_core.dir/libs/packager/packager_mod.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/libs/packager/packager_mod.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/libs/server/server_mod.cpp" "CMakeFiles/phoenix_core.dir/libs/server/server_mod.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/libs/server/server_mod.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/libs/time/time_mod.cpp" "CMakeFiles/phoenix_core.dir/libs/time/time_mod.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/libs/time/time_mod.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/c_api/phoenix_c.cpp" "CMakeFiles/phoenix_core.dir/src/c_api/phoenix_c.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/c_api/phoenix_c.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/common/error.cpp" "CMakeFiles/phoenix_core.dir/src/common/error.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/common/error.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/common/types.cpp" "CMakeFiles/phoenix_core.dir/src/common/types.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/common/types.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/compiler/compiler.cpp" "CMakeFiles/phoenix_core.dir/src/compiler/compiler.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/compiler/compiler.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/compiler/optimizer.cpp" "CMakeFiles/phoenix_core.dir/src/compiler/optimizer.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/compiler/optimizer.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/lexer/lexer.cpp" "CMakeFiles/phoenix_core.dir/src/lexer/lexer.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/lexer/lexer.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/lexer/token.cpp" "CMakeFiles/phoenix_core.dir/src/lexer/token.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/lexer/token.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/linker/linker.cpp" "CMakeFiles/phoenix_core.dir/src/linker/linker.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/linker/linker.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/linker/verifier.cpp" "CMakeFiles/phoenix_core.dir/src/linker/verifier.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/linker/verifier.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/parser/ast.cpp" "CMakeFiles/phoenix_core.dir/src/parser/ast.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/parser/ast.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/parser/parser.cpp" "CMakeFiles/phoenix_core.dir/src/parser/parser.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/parser/parser.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/pmi/pmi.cpp" "CMakeFiles/phoenix_core.dir/src/pmi/pmi.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/pmi/pmi.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/stdlib/native_bridge.cpp" "CMakeFiles/phoenix_core.dir/src/stdlib/native_bridge.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/stdlib/native_bridge.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/vm/bytecode.cpp" "CMakeFiles/phoenix_core.dir/src/vm/bytecode.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/vm/bytecode.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/vm/memory.cpp" "CMakeFiles/phoenix_core.dir/src/vm/memory.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/vm/memory.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/vm/sandbox.cpp" "CMakeFiles/phoenix_core.dir/src/vm/sandbox.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/vm/sandbox.cpp.o.d"
  "/storage/emulated/0/Documents/phoenix1.1.1/phoenix_fixed/src/vm/vm.cpp" "CMakeFiles/phoenix_core.dir/src/vm/vm.cpp.o" "gcc" "CMakeFiles/phoenix_core.dir/src/vm/vm.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
