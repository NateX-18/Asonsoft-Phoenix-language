file(REMOVE_RECURSE
  "libphoenix_core.a"
)
