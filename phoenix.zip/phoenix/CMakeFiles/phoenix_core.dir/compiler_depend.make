# Empty compiler generated dependencies file for phoenix_core.
# This may be replaced when dependencies are built.
