
#include "phoenix/stdlib/native_bridge.hpp"
#include <iostream>

#if defined(_WIN32)
    #include <windows.h>
#else
    #include <dlfcn.h>
#endif

namespace phoenix {

NativeBridge::NativeBridge(DiagnosticEngine& diagnostics, VM& vm)
    : m_diagnostics(diagnostics), m_vm(vm) {}

NativeBridge::~NativeBridge() {
    unload_all();
}

bool NativeBridge::load_shared_library(const std::string& module_name, const std::string& library_path) {
    if (m_loaded_handles.count(module_name)) {
        return true; // Already loaded
    }

#if defined(_WIN32)
    HMODULE handle = LoadLibraryA(library_path.c_str());
    if (!handle) {
        m_diagnostics.report(ErrorCategory::LINKER, "NativeBridge: Failed to load DLL '" + library_path + "'.", SourceLocation{"<native_bridge>", 0, 0});
        return false;
    }
    using InitFn = void(*)(VM*);
    auto init_fn = reinterpret_cast<InitFn>(GetProcAddress(handle, "phoenix_module_init"));
    if (!init_fn) {
        m_diagnostics.report(ErrorCategory::LINKER, "NativeBridge: Missing 'phoenix_module_init' entry point in " + library_path, SourceLocation{"<native_bridge>", 0, 0});
        FreeLibrary(handle);
        return false;
    }
    init_fn(&m_vm);
    m_loaded_handles[module_name] = handle;
    return true;
#else
    void* handle = dlopen(library_path.c_str(), RTLD_LAZY);
    if (!handle) {
        std::string err_msg = dlerror() ? dlerror() : "Unknown dlopen error";
        m_diagnostics.report(ErrorCategory::LINKER, "NativeBridge: Failed to load shared object '" + library_path + "': " + err_msg, SourceLocation{"<native_bridge>", 0, 0});
        return false;
    }
    using InitFn = void(*)(VM*);
    auto init_fn = reinterpret_cast<InitFn>(dlsym(handle, "phoenix_module_init"));
    if (!init_fn) {
        m_diagnostics.report(ErrorCategory::LINKER, "NativeBridge: Missing 'phoenix_module_init' entry point in " + library_path, SourceLocation{"<native_bridge>", 0, 0});
        dlclose(handle);
        return false;
    }
    init_fn(&m_vm);
    m_loaded_handles[module_name] = handle;
    return true;
#endif
}

bool NativeBridge::unload_shared_library(const std::string& module_name) {
    auto it = m_loaded_handles.find(module_name);
    if (it == m_loaded_handles.end()) return false;

#if defined(_WIN32)
    FreeLibrary(static_cast<HMODULE>(it->second));
#else
    dlclose(it->second);
#endif

    m_loaded_handles.erase(it);
    return true;
}

void NativeBridge::unload_all() {
    for (auto& [name, handle] : m_loaded_handles) {
#if defined(_WIN32)
        FreeLibrary(static_cast<HMODULE>(handle));
#else
        dlclose(handle);
#endif
    }
    m_loaded_handles.clear();
}

} // namespace phoenix

