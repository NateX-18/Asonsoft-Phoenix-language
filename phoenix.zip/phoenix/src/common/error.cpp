#include "phoenix/common/error.hpp"
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>

namespace phoenix {

std::string SourceLocation::to_string() const {
    std::ostringstream ss;
    ss << file_path << ":" << line << ":" << column;
    return ss.str();
}

PhoenixException::PhoenixException(ErrorCategory cat, std::string msg, SourceLocation loc)
    : category(cat), location(loc) {
    std::ostringstream ss;
    ss << "[" << loc.to_string() << "] Error: " << msg;
    full_message = ss.str();
}

static std::string read_source_line(const std::string& path, uint32_t line) {
    if (path.empty() || path[0] == '<' || line == 0) return "";
    std::ifstream in(path);
    if (!in) return "";
    std::string s;
    uint32_t n = 0;
    while (std::getline(in, s)) {
        ++n;
        if (n == line) return s;
    }
    return "";
}

void DiagnosticEngine::report(ErrorCategory category, const std::string& message, SourceLocation loc, DiagnosticLevel level) {
    diagnostics.push_back({level, category, message, loc});
    if (level == DiagnosticLevel::ERROR || level == DiagnosticLevel::FATAL) {
        has_errors_ = true;
    }

    const char* tag = "Info";
    const char* color = "\033[1;36m";
    if (level == DiagnosticLevel::ERROR || level == DiagnosticLevel::FATAL) {
        tag = "Error"; color = "\033[1;31m";
    } else if (level == DiagnosticLevel::WARNING) {
        tag = "Warning"; color = "\033[1;33m";
    }

    std::cerr << color << "[Phoenix " << tag << "]\033[0m ";

    // Category hint
    switch (category) {
        case ErrorCategory::LEXER:    std::cerr << "(lexer) "; break;
        case ErrorCategory::PARSER:   std::cerr << "(parser) "; break;
        case ErrorCategory::COMPILER: std::cerr << "(compiler) "; break;
        case ErrorCategory::LINKER:   std::cerr << "(linker) "; break;
        case ErrorCategory::RUNTIME:  std::cerr << "(runtime) "; break;
        case ErrorCategory::SANDBOX:  std::cerr << "(sandbox) "; break;
        case ErrorCategory::PMI:      std::cerr << "(pmi) "; break;
    }

    if (loc.line > 0) {
        std::cerr << "at " << loc.to_string() << "\n";
        std::cerr << "  " << message << "\n";

        // Source snippet
        std::string snippet = read_source_line(loc.file_path, loc.line);
        if (!snippet.empty()) {
            std::cerr << "  " << std::setw(5) << loc.line << " | " << snippet << "\n";
            if (loc.column > 0) {
                std::cerr << "       | ";
                for (uint32_t i = 1; i < loc.column && i < 200; ++i) std::cerr << ' ';
                std::cerr << "\033[1;31m^\033[0m\n";
            }
        }
    } else {
        std::cerr << message << "\n";
    }
}

void DiagnosticEngine::report_error(const std::string& message, SourceLocation loc) {
    report(ErrorCategory::RUNTIME, message, loc, DiagnosticLevel::ERROR);
}

void DiagnosticEngine::report_warning(const std::string& message, SourceLocation loc) {
    report(ErrorCategory::RUNTIME, message, loc, DiagnosticLevel::WARNING);
}

void DiagnosticEngine::clear() {
    diagnostics.clear();
    has_errors_ = false;
}

} // namespace phoenix
