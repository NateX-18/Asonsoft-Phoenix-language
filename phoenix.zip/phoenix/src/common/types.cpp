#include "phoenix/common/types.hpp"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>

namespace phoenix {

std::string Value::to_string() const {
    switch (type) {
        case ValueType::NIL: return "nil";
        case ValueType::BOOLEAN: return as.boolean ? "true" : "false";
        case ValueType::NUMBER: {
            std::ostringstream ss;
            if (std::floor(as.number) == as.number) {
                ss << static_cast<int64_t>(as.number);
            } else {
                ss << as.number;
            }
            return ss.str();
        }
        case ValueType::I8: return std::to_string(static_cast<int32_t>(static_cast<int8_t>(as.i64_val)));
        case ValueType::I16: return std::to_string(static_cast<int16_t>(as.i64_val));
        case ValueType::I32: return std::to_string(static_cast<int32_t>(as.i64_val));
        case ValueType::I64: return std::to_string(as.i64_val);
        case ValueType::U8: return std::to_string(static_cast<uint32_t>(static_cast<uint8_t>(as.u64_val)));
        case ValueType::U16: return std::to_string(static_cast<uint16_t>(as.u64_val));
        case ValueType::U32: return std::to_string(static_cast<uint32_t>(as.u64_val));
        case ValueType::U64: return std::to_string(as.u64_val);
        case ValueType::STRING: return str_val;
        case ValueType::LIST: {
            if (!list_val) return "[]";
            std::string res = "[";
            for (size_t i = 0; i < list_val->elements.size(); ++i) {
                res += list_val->elements[i].to_string();
                if (i + 1 < list_val->elements.size()) res += ", ";
            }
            res += "]";
            return res;
        }
        case ValueType::DICT: {
            if (!dict_val) return "{}";
            // Pretty-print class / system / instance objects
            auto it_type = dict_val->entries.find("__type__");
            if (it_type != dict_val->entries.end()) {
                std::string tag = it_type->second.to_string();
                if (tag == "class" || tag == "system") {
                    std::string name = "Anonymous";
                    auto it_n = dict_val->entries.find("__name__");
                    if (it_n != dict_val->entries.end()) name = it_n->second.to_string();
                    return "<" + tag + " " + name + ">";
                }
                if (tag == "instance") {
                    std::string cname = "Object";
                    auto it_c = dict_val->entries.find("__class__");
                    if (it_c != dict_val->entries.end() && it_c->second.is_dict() && it_c->second.as_dict()) {
                        auto it_n = it_c->second.as_dict()->entries.find("__name__");
                        if (it_n != it_c->second.as_dict()->entries.end())
                            cname = it_n->second.to_string();
                    }
                    // Prefer user-defined toString field if present as a string cache
                    auto it_ts = dict_val->entries.find("__str__");
                    if (it_ts != dict_val->entries.end() && it_ts->second.is_string())
                        return it_ts->second.to_string();
                    std::string res = "<" + cname;
                    for (const auto& [k, v] : dict_val->entries) {
                        if (k.size() >= 2 && k[0] == '_' && k[1] == '_') continue;
                        res += " " + k + "=" + v.to_string();
                    }
                    res += ">";
                    return res;
                }
            }
            std::string res = "{";
            size_t count = 0;
            if (!dict_val->matrix_records.empty()) {
                for (const auto& [pk, row] : dict_val->matrix_records) {
                    res += "[" + pk;
                    for (const auto& [col, val] : row) {
                        res += ", " + col + ": " + val.to_string();
                    }
                    res += "]";
                    if (++count < dict_val->matrix_records.size()) res += ", ";
                }
            } else {
                for (const auto& [k, v] : dict_val->entries) {
                    res += "\"" + k + "\": " + v.to_string();
                    if (++count < dict_val->entries.size()) res += ", ";
                }
            }
            res += "}";
            return res;
        }
        case ValueType::POINTER: return "<pointer>";
        default: return "<unknown>";
    }
}

bool Value::strict_equals(const Value& other) const {
    if (type != other.type) return false;

    switch (type) {
        case ValueType::NIL: return true;
        case ValueType::BOOLEAN: return as.boolean == other.as.boolean;
        case ValueType::NUMBER: return as.number == other.as.number;
        case ValueType::I8:
        case ValueType::I16:
        case ValueType::I32:
        case ValueType::I64: return as.i64_val == other.as.i64_val;
        case ValueType::U8:
        case ValueType::U16:
        case ValueType::U32:
        case ValueType::U64: return as.u64_val == other.as.u64_val;
        case ValueType::STRING: return str_val == other.str_val;
        case ValueType::LIST: return list_val == other.list_val;
        case ValueType::DICT: return dict_val == other.dict_val;
        case ValueType::POINTER: return as.pointer == other.as.pointer;
        default: return false;
    }
}

void Value::cast_to(const std::string& target_type) {
    if (target_type == "str" || target_type == "string") {
        str_val = to_string();
        type = ValueType::STRING;
    } else if (target_type == "int" || target_type == "i32") {
        int32_t val = static_cast<int32_t>(as_number());
        if (type == ValueType::STRING) {
            try { val = std::stoi(str_val); } catch (...) { val = 0; }
        }
        *this = Value::make_i32(val);
    } else if (target_type == "i64") {
        int64_t val = as_i64();
        if (type == ValueType::STRING) {
            try { val = std::stoll(str_val); } catch (...) { val = 0; }
        }
        *this = Value::make_i64(val);
    } else if (target_type == "i8") {
        int8_t val = static_cast<int8_t>(as_i64());
        *this = Value::make_i8(val);
    } else if (target_type == "i16") {
        int16_t val = static_cast<int16_t>(as_i64());
        *this = Value::make_i16(val);
    } else if (target_type == "u8") {
        uint8_t val = static_cast<uint8_t>(as_u64());
        *this = Value::make_u8(val);
    } else if (target_type == "u16") {
        uint16_t val = static_cast<uint16_t>(as_u64());
        *this = Value::make_u16(val);
    } else if (target_type == "u32") {
        uint32_t val = static_cast<uint32_t>(as_u64());
        *this = Value::make_u32(val);
    } else if (target_type == "u64") {
        uint64_t val = as_u64();
        if (type == ValueType::STRING) {
            try { val = std::stoull(str_val); } catch (...) { val = 0; }
        }
        *this = Value::make_u64(val);
    } else if (target_type == "float" || target_type == "f32" || target_type == "f64") {
        double val = as_number();
        if (type == ValueType::STRING) {
            try { val = std::stod(str_val); } catch (...) { val = 0.0; }
        }
        *this = Value::number(val);
    } else if (target_type == "bool") {
        *this = Value::boolean(is_truthy());
    }
}

Value Value::query_primary_key(const Value& pk_val) const {
    if (type != ValueType::DICT || !dict_val) return Value::nil();

    std::string pk_str = pk_val.to_string();
    auto it = dict_val->matrix_records.find(pk_str);
    if (it != dict_val->matrix_records.end()) {
        auto row_dict = std::make_shared<HeapDict>();
        row_dict->entries = it->second;
        return Value::dict(row_dict);
    }

    auto entry_it = dict_val->entries.find(pk_str);
    if (entry_it != dict_val->entries.end()) {
        return entry_it->second;
    }

    return Value::nil();
}

void Value::update_cell(const Value& pk_val, const std::string& col_name, const Value& new_val) {
    if (type != ValueType::DICT || !dict_val) return;

    std::string pk_str = pk_val.to_string();
    dict_val->matrix_records[pk_str][col_name] = new_val;
    dict_val->entries[pk_str + "." + col_name] = new_val;
}

} // namespace phoenix