// Phoenix Package Manager CLI — standalone `pmi` executable
#include "phoenix/pmi/pmi.hpp"
#include "phoenix/common/error.hpp"
#include "phoenix/common/config.hpp"
#include <iostream>
#include <string>
#include <cstdlib>

static void usage(const char* name) {
    std::cout
        << "Phoenix Package Manager (PMI) " << phoenix::PHX_VERSION_STRING << "\n"
        << "Usage: " << name << " <command> [args]\n\n"
        << "Commands:\n"
        << "  init <name>              Create a new package template\n"
        << "  pack <dir> <out.epkg>    Pack a directory into an .epkg\n"
        << "  install <file.epkg>      Install a package\n"
        << "  remove <name>            Remove an installed package\n"
        << "  list                     List installed packages\n"
        << "  info <name>              Fetch package info\n"
        << "  publish <file> <token>   Publish package to registry\n"
        << "  -h, --help               Show this help\n"
        << "  -v, --version            Show version\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    std::string cmd = argv[1];
    if (cmd == "-h" || cmd == "--help") {
        usage(argv[0]);
        return EXIT_SUCCESS;
    }
    if (cmd == "-v" || cmd == "--version") {
        std::cout << "PMI " << phoenix::PHX_VERSION_STRING << " (" << phoenix::PHX_VENDOR << ")\n";
        return EXIT_SUCCESS;
    }

    phoenix::DiagnosticEngine diagnostics;
    phoenix::PMI pmi(diagnostics);

    if (cmd == "init") {
        if (argc < 3) { std::cerr << "Usage: pmi init <name>\n"; return EXIT_FAILURE; }
        return pmi.init_package(argv[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "pack") {
        if (argc < 4) { std::cerr << "Usage: pmi pack <dir> <out.epkg>\n"; return EXIT_FAILURE; }
        return pmi.pack_package(argv[2], argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "install") {
        if (argc < 3) { std::cerr << "Usage: pmi install <file.epkg>\n"; return EXIT_FAILURE; }
        return pmi.install_package(argv[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "remove") {
        if (argc < 3) { std::cerr << "Usage: pmi remove <name>\n"; return EXIT_FAILURE; }
        return pmi.remove_package(argv[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "list") {
        return pmi.list_installed() ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "info") {
        if (argc < 3) { std::cerr << "Usage: pmi info <name>\n"; return EXIT_FAILURE; }
        return pmi.fetch_info(argv[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (cmd == "publish") {
        if (argc < 4) { std::cerr << "Usage: pmi publish <file.epkg> <token>\n"; return EXIT_FAILURE; }
        return pmi.publish_package(argv[2], argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    std::cerr << "Unknown command: " << cmd << "\n";
    usage(argv[0]);
    return EXIT_FAILURE;
}
