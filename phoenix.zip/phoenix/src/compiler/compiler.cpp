#include "phoenix/compiler/compiler.hpp"
#include <iostream>

namespace phoenix {

Compiler::Compiler(DiagnosticEngine& diagnostics)
    : m_diagnostics(diagnostics), m_current_chunk(std::make_shared<Chunk>()) {}

std::shared_ptr<Chunk> Compiler::compile(const ProgramAST& program) {
    for (const auto& stmt : program.statements) {
        if (stmt) stmt->accept(this);
    }
    emit_op(OpCode::OP_HALT);
    return m_current_chunk;
}

void Compiler::emit_byte(uint8_t byte, uint32_t line, uint32_t col) {
    m_current_chunk->write(byte, line, col);
}

void Compiler::emit_op(OpCode op, uint32_t line, uint32_t col) {
    m_current_chunk->write_op(op, line, col);
}

void Compiler::emit_constant_index(uint16_t idx, uint32_t line, uint32_t col) {
    // 16-bit constant pool index (was 8-bit — overflow made methods non-callable)
    emit_byte(static_cast<uint8_t>((idx >> 8) & 0xFF), line, col);
    emit_byte(static_cast<uint8_t>(idx & 0xFF), line, col);
}

size_t Compiler::emit_jump(OpCode op, uint32_t line, uint32_t col) {
    emit_op(op, line, col);
    emit_byte(0xFF, line, col);
    emit_byte(0xFF, line, col);
    return m_current_chunk->code.size() - 2;
}

void Compiler::patch_jump(size_t offset) {
    size_t jump = m_current_chunk->code.size() - offset - 2;
    if (jump > UINT16_MAX) {
        m_diagnostics.report(ErrorType::COMPILER, "Jump offset exceeds maximum limit.", SourceLocation{"<compiler>", 0, 0});
        return;
    }
    m_current_chunk->code[offset] = static_cast<uint8_t>((jump >> 8) & 0xFF);
    m_current_chunk->code[offset + 1] = static_cast<uint8_t>(jump & 0xFF);
}

void Compiler::emit_loop(size_t loop_start, uint32_t line, uint32_t col) {
    emit_op(OpCode::OP_LOOP, line, col);
    size_t jump = m_current_chunk->code.size() - loop_start + 2;
    if (jump > UINT16_MAX) {
        m_diagnostics.report(ErrorType::COMPILER, "Loop body too large.", SourceLocation{"<compiler>", line, col});
    }
    emit_byte(static_cast<uint8_t>((jump >> 8) & 0xFF), line, col);
    emit_byte(static_cast<uint8_t>(jump & 0xFF), line, col);
}

uint16_t Compiler::make_constant(Value value) {
    return m_current_chunk->add_constant(value);
}

void Compiler::begin_scope() {
    m_scope_depth++;
}

void Compiler::end_scope() {
    m_scope_depth--;
    while (!m_locals.empty() && m_locals.back().depth > m_scope_depth) {
        emit_op(OpCode::OP_POP);
        m_locals.pop_back();
    }
}

void Compiler::declare_variable(const std::string& name, uint32_t line, uint32_t col) {
    if (m_scope_depth == 0) return;
    for (auto it = m_locals.rbegin(); it != m_locals.rend(); ++it) {
        if (it->depth != -1 && it->depth < m_scope_depth) break;
        if (name == it->name) {
            m_diagnostics.report(ErrorType::COMPILER, "Redefinition of variable '" + name + "'.", SourceLocation{"<compiler>", line, col});
            return;
        }
    }
    m_locals.push_back({name, m_scope_depth, false});
}

int Compiler::resolve_local(const std::string& name) {
    for (int i = static_cast<int>(m_locals.size()) - 1; i >= 0; i--) {
        if (m_locals[i].name == name) return i;
    }
    return -1;
}

void Compiler::visit(LiteralExprAST* node) {
    uint16_t idx = make_constant(node->value);
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(idx, node->location.line, node->location.column);
}

void Compiler::visit(IdentifierExprAST* node) {
    int local_idx = resolve_local(node->name);
    if (local_idx != -1) {
        emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
        emit_byte(static_cast<uint8_t>(local_idx), node->location.line, node->location.column);
    } else {
        uint16_t name_idx = make_constant(Value::make_string(node->name));
        emit_op(OpCode::OP_GET_GLOBAL, node->location.line, node->location.column);
        emit_constant_index(name_idx, node->location.line, node->location.column);
    }
}

void Compiler::visit(ListLiteralExprAST* node) {
    for (const auto& elem : node->elements) {
        if (elem) elem->accept(this);
    }
    emit_op(OpCode::OP_BUILD_LIST, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->elements.size()), node->location.line, node->location.column);
}

void Compiler::visit(DictLiteralExprAST* node) {
    // Emit the primary key column name, then each schema column name, so the
    // VM can attach real column names to the dict instead of falling back to
    // synthetic "col_N" placeholders.
    uint16_t pk_idx = make_constant(Value::make_string(node->primary_key));
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(pk_idx, node->location.line, node->location.column);

    for (const auto& col : node->schema_columns) {
        uint16_t col_idx = make_constant(Value::make_string(col));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(col_idx, node->location.line, node->location.column);
    }

    for (const auto& row : node->rows) {
        for (const auto& val_expr : row) {
            if (val_expr) val_expr->accept(this);
        }
    }

    emit_op(OpCode::OP_BUILD_DICT, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->rows.size()), node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->schema_columns.size()), node->location.line, node->location.column);
}

void Compiler::visit(UnaryExprAST* node) {
    if (node->operand) node->operand->accept(this);
    if (node->op == TokenType::MINUS) emit_op(OpCode::OP_NEGATE, node->location.line, node->location.column);
    else if (node->op == TokenType::BANG) emit_op(OpCode::OP_NOT, node->location.line, node->location.column);
}

void Compiler::visit(BinaryExprAST* node) {
    if (node->left) node->left->accept(this);
    if (node->right) node->right->accept(this);

    uint32_t line = node->location.line;
    uint32_t col = node->location.column;

    switch (node->op_type) {
        case TokenType::PLUS: emit_op(OpCode::OP_ADD, line, col); break;
        case TokenType::MINUS: emit_op(OpCode::OP_SUBTRACT, line, col); break;
        case TokenType::STAR: emit_op(OpCode::OP_MULTIPLY, line, col); break;
        case TokenType::SLASH: emit_op(OpCode::OP_DIVIDE, line, col); break;
        case TokenType::PERCENT: emit_op(OpCode::OP_MODULO, line, col); break;
        case TokenType::EQUAL: emit_op(OpCode::OP_EQUAL, line, col); break;
        case TokenType::NOT_EQUAL: emit_op(OpCode::OP_NOT_EQUAL, line, col); break;
        case TokenType::GREATER: emit_op(OpCode::OP_GREATER, line, col); break;
        case TokenType::GREATER_EQUAL: emit_op(OpCode::OP_GREATER_EQUAL, line, col); break;
        case TokenType::LESS: emit_op(OpCode::OP_LESS, line, col); break;
        case TokenType::LESS_EQUAL: emit_op(OpCode::OP_LESS_EQUAL, line, col); break;
        default: break;
    }
}

void Compiler::visit(AssignExprAST* node) {
    // Member assignment: object.field = value
    if (node->object) {
        if (node->object) node->object->accept(this);
        if (node->value) node->value->accept(this);
        uint16_t prop_idx = make_constant(Value::make_string(node->name));
        emit_op(OpCode::OP_SET_PROPERTY, node->location.line, node->location.column);
        emit_constant_index(prop_idx, node->location.line, node->location.column);
        return;
    }

    int local_idx = resolve_local(node->name);

    if (node->op != TokenType::ASSIGN) {
        if (local_idx != -1) {
            emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
            emit_byte(static_cast<uint8_t>(local_idx), node->location.line, node->location.column);
        } else {
            uint16_t name_idx = make_constant(Value::make_string(node->name));
            emit_op(OpCode::OP_GET_GLOBAL, node->location.line, node->location.column);
            emit_constant_index(name_idx, node->location.line, node->location.column);
        }

        if (node->value) node->value->accept(this);

        switch (node->op) {
            case TokenType::PLUS_ASSIGN: emit_op(OpCode::OP_ADD, node->location.line, node->location.column); break;
            case TokenType::MINUS_ASSIGN: emit_op(OpCode::OP_SUBTRACT, node->location.line, node->location.column); break;
            case TokenType::STAR_ASSIGN: emit_op(OpCode::OP_MULTIPLY, node->location.line, node->location.column); break;
            case TokenType::SLASH_ASSIGN: emit_op(OpCode::OP_DIVIDE, node->location.line, node->location.column); break;
            default: break;
        }
    } else {
        if (node->value) node->value->accept(this);
    }

    if (local_idx != -1) {
        emit_op(OpCode::OP_SET_LOCAL, node->location.line, node->location.column);
        emit_byte(static_cast<uint8_t>(local_idx), node->location.line, node->location.column);
    } else {
        uint16_t name_idx = make_constant(Value::make_string(node->name));
        emit_op(OpCode::OP_SET_GLOBAL, node->location.line, node->location.column);
        emit_constant_index(name_idx, node->location.line, node->location.column);
    }
}

void Compiler::visit(CallExprAST* node) {
    // Method call: obj.method(args)  or  super.method(args)
    // Stack layout: [instance, method, arg0, ...] with high-bit arg_count for method calls.
    if (auto* mem = dynamic_cast<MemberExprAST*>(node->callee.get())) {
        bool is_super = false;
        if (auto* id = dynamic_cast<IdentifierExprAST*>(mem->object.get())) {
            if (id->name == "super") is_super = true;
        }

        if (is_super) {
            // super.method(args) — use local slot 0 (struct) as instance,
            // resolve method from parent class via OP_GET_PROPERTY on a synthetic path.
            // Emit: get local 0 (struct), then mark super lookup by getting "__super__." + method
            // Convention: push instance, then GET_PROPERTY with name "super::method"
            emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
            emit_byte(0, node->location.line, node->location.column); // struct
            emit_op(OpCode::OP_DUP, node->location.line, node->location.column);
            uint16_t prop_idx = make_constant(Value::make_string(std::string("super::") + mem->member));
            emit_op(OpCode::OP_GET_PROPERTY, node->location.line, node->location.column);
            emit_constant_index(prop_idx, node->location.line, node->location.column);
        } else {
            if (mem->object) mem->object->accept(this);
            emit_op(OpCode::OP_DUP, node->location.line, node->location.column);
            uint16_t prop_idx = make_constant(Value::make_string(mem->member));
            emit_op(OpCode::OP_GET_PROPERTY, node->location.line, node->location.column);
            emit_constant_index(prop_idx, node->location.line, node->location.column);
        }
        for (const auto& arg : node->arguments) {
            if (arg) arg->accept(this);
        }
        uint8_t encoded = static_cast<uint8_t>(node->arguments.size() | 0x80);
        emit_op(OpCode::OP_CALL, node->location.line, node->location.column);
        emit_byte(encoded, node->location.line, node->location.column);
        return;
    }

    // Normal function / constructor call
    if (node->callee) node->callee->accept(this);
    for (const auto& arg : node->arguments) {
        if (arg) arg->accept(this);
    }
    emit_op(OpCode::OP_CALL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->arguments.size()), node->location.line, node->location.column);
}

void Compiler::visit(NativeCallExprAST* node) {
    for (const auto& arg : node->arguments) {
        if (arg) arg->accept(this);
    }

    uint16_t fn_idx = make_constant(Value::make_string(node->function_name));
    uint16_t mod_idx = make_constant(Value::make_string(node->module_name));

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(mod_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(fn_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_INVOKE_NATIVE, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->arguments.size()), node->location.line, node->location.column);
}

void Compiler::visit(MemberExprAST* node) {
    if (node->object) node->object->accept(this);
    uint16_t prop_idx = make_constant(Value::make_string(node->member));
    emit_op(OpCode::OP_GET_PROPERTY, node->location.line, node->location.column);
    emit_constant_index(prop_idx, node->location.line, node->location.column);
}

void Compiler::visit(IndexExprAST* node) {
    if (node->target) node->target->accept(this);
    if (node->index) node->index->accept(this);
    emit_op(OpCode::OP_GET_INDEX, node->location.line, node->location.column);
}

void Compiler::visit(TypeMapExprAST* node) {
    if (node->expression) node->expression->accept(this);
    uint16_t type_idx = make_constant(Value::make_string(node->target_type));
    emit_op(OpCode::OP_TYPE_CAST, node->location.line, node->location.column);
    emit_constant_index(type_idx, node->location.line, node->location.column);
}

void Compiler::visit(TableKeyExprAST* node) {
    uint16_t table_idx = make_constant(Value::make_string(node->table_name));

    if (node->key_expr) {
        node->key_expr->accept(this);
    } else {
        emit_op(OpCode::OP_NIL, node->location.line, node->location.column);
    }

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(table_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_QUERY_TABLE, node->location.line, node->location.column);
}

void Compiler::visit(PrimaryKeyQueryExprAST* node) {
    if (node->key_expr) node->key_expr->accept(this);
    uint16_t dict_idx = make_constant(Value::make_string(node->dict_name));
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(dict_idx, node->location.line, node->location.column);
    emit_op(OpCode::OP_QUERY_TABLE, node->location.line, node->location.column);
}

void Compiler::visit(InputExprAST* node) {
    uint8_t has_prompt = 0;
    if (node->prompt) {
        node->prompt->accept(this);
        has_prompt = 1;
    }
    emit_op(OpCode::OP_INPUT, node->location.line, node->location.column);
    emit_byte(has_prompt, node->location.line, node->location.column);
}

void Compiler::visit(ExprStmtAST* node) {
    if (node->expression) node->expression->accept(this);
    emit_op(OpCode::OP_POP, node->location.line, node->location.column);
}

void Compiler::visit(VarDeclStmtAST* node) {
    declare_variable(node->name, node->location.line, node->location.column);
    if (node->initializer) {
        node->initializer->accept(this);
    } else {
        emit_op(OpCode::OP_NIL, node->location.line, node->location.column);
    }

    if (!node->type_map_annotation.empty()) {
        uint16_t type_idx = make_constant(Value::make_string(node->type_map_annotation));
        emit_op(OpCode::OP_TYPE_CAST, node->location.line, node->location.column);
        emit_constant_index(type_idx, node->location.line, node->location.column);
    }

    // Local variable: store the initializer result into its fixed slot.
    // Do NOT pop — the value must remain on the stack so the local slot
    // stays alive for the rest of the function (stack-machine local model).
    // Later temporaries are pushed above it; RETURN cleans everything.
    if (m_scope_depth > 0) {
        int slot = resolve_local(node->name);
        if (slot >= 0) {
            emit_op(OpCode::OP_SET_LOCAL, node->location.line, node->location.column);
            emit_byte(static_cast<uint8_t>(slot), node->location.line, node->location.column);
        }
        return;
    }

    uint16_t global_idx = make_constant(Value::make_string(node->name));
    emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
    emit_constant_index(global_idx, node->location.line, node->location.column);
}

void Compiler::visit(BulkDeclStmtAST* node) {
    // dtype / state / state~dtype: create each variable with a typed default
    // and define it as a global (or leave on stack as a local when nested).
    for (const auto& var_name : node->variables) {
        declare_variable(var_name, node->location.line, node->location.column);

        // Default value by declared type
        std::string dt = node->data_type;
        if (dt == "int" || dt == "i32" || dt == "i64" || dt == "u32" || dt == "u64" ||
            dt == "i8" || dt == "i16" || dt == "u8" || dt == "u16") {
            uint16_t z = make_constant(Value::make_i64(0));
            emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
            emit_constant_index(z, node->location.line, node->location.column);
        } else if (dt == "float" || dt == "number" || dt == "f64" || dt == "f32") {
            uint16_t z = make_constant(Value::number(0.0));
            emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
            emit_constant_index(z, node->location.line, node->location.column);
        } else if (dt == "bool" || dt == "boolean") {
            emit_op(OpCode::OP_FALSE, node->location.line, node->location.column);
        } else if (dt == "str" || dt == "string") {
            uint16_t z = make_constant(Value::make_string(""));
            emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
            emit_constant_index(z, node->location.line, node->location.column);
        } else {
            emit_op(OpCode::OP_NIL, node->location.line, node->location.column);
        }

        if (!dt.empty()) {
            uint16_t type_idx = make_constant(Value::make_string(dt));
            emit_op(OpCode::OP_TYPE_CAST, node->location.line, node->location.column);
            emit_constant_index(type_idx, node->location.line, node->location.column);
        }

        if (m_scope_depth == 0) {
            uint16_t global_idx = make_constant(Value::make_string(var_name));
            emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
            emit_constant_index(global_idx, node->location.line, node->location.column);
        } else {
            // Local bulk decl: bind into the slot
            int slot = resolve_local(var_name);
            if (slot >= 0) {
                emit_op(OpCode::OP_SET_LOCAL, node->location.line, node->location.column);
                emit_byte(static_cast<uint8_t>(slot), node->location.line, node->location.column);
            }
        }
    }
}

void Compiler::visit(DictSchemaAddColStmtAST* node) {
    uint16_t name_idx = make_constant(Value::make_string(node->dict_name));
    uint16_t col_idx = make_constant(Value::make_string(node->col_name));

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(name_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(col_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_ADD_COLUMN, node->location.line, node->location.column);
}

void Compiler::visit(DictStreamUpsertStmtAST* node) {
    // Push order must match VM::OP_UPSERT_ROW's pop order exactly (it pops
    // new_val, then col_name, then dict_name, then pk_val): pk_key first,
    // then dict_name, then col_name, then the new value last.
    if (node->pk_key) node->pk_key->accept(this);

    uint16_t name_idx = make_constant(Value::make_string(node->dict_name));
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(name_idx, node->location.line, node->location.column);

    uint16_t col_idx = make_constant(Value::make_string(node->target_column));
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(col_idx, node->location.line, node->location.column);

    if (node->value_or_row) node->value_or_row->accept(this);

    emit_op(OpCode::OP_UPSERT_ROW, node->location.line, node->location.column);
}

void Compiler::visit(AsmStmtAST* node) {
    for (const auto& inst : node->instructions) {
        uint16_t inst_idx = make_constant(Value::make_string(inst));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(inst_idx, node->location.line, node->location.column);
        emit_op(OpCode::OP_ASM, node->location.line, node->location.column);
    }
}

void Compiler::visit(BlockStmtAST* node) {
    begin_scope();
    for (const auto& stmt : node->statements) {
        if (stmt) stmt->accept(this);
    }
    end_scope();
}

void Compiler::visit(IfStmtAST* node) {
    if (node->condition) node->condition->accept(this);

    size_t then_jump = emit_jump(OpCode::OP_JUMP_IF_FALSE, node->location.line, node->location.column);
    emit_op(OpCode::OP_POP);

    if (node->then_branch) node->then_branch->accept(this);

    size_t else_jump = emit_jump(OpCode::OP_JUMP, node->location.line, node->location.column);
    patch_jump(then_jump);
    emit_op(OpCode::OP_POP);

    if (node->else_branch) node->else_branch->accept(this);
    patch_jump(else_jump);
}

void Compiler::visit(WhileStmtAST* node) {
    size_t loop_start = m_current_chunk->code.size();
    m_loop_stack.push_back({loop_start, {}});

    if (node->condition) node->condition->accept(this);
    size_t exit_jump = emit_jump(OpCode::OP_JUMP_IF_FALSE, node->location.line, node->location.column);
    emit_op(OpCode::OP_POP);

    if (node->body) node->body->accept(this);
    emit_loop(loop_start, node->location.line, node->location.column);

    patch_jump(exit_jump);
    emit_op(OpCode::OP_POP);

    for (size_t break_offset : m_loop_stack.back().break_jumps) {
        patch_jump(break_offset);
    }
    m_loop_stack.pop_back();
}

void Compiler::visit(ForStmtAST* node) {
    begin_scope();
    if (node->initializer) node->initializer->accept(this);

    size_t loop_start = m_current_chunk->code.size();
    m_loop_stack.push_back({loop_start, {}});

    size_t exit_jump = static_cast<size_t>(-1);
    if (node->condition) {
        node->condition->accept(this);
        exit_jump = emit_jump(OpCode::OP_JUMP_IF_FALSE, node->location.line, node->location.column);
        emit_op(OpCode::OP_POP);
    }

    if (node->body) node->body->accept(this);
    if (node->increment) {
        node->increment->accept(this);
        emit_op(OpCode::OP_POP);
    }

    emit_loop(loop_start, node->location.line, node->location.column);

    if (exit_jump != static_cast<size_t>(-1)) {
        patch_jump(exit_jump);
        emit_op(OpCode::OP_POP);
    }

    for (size_t break_offset : m_loop_stack.back().break_jumps) {
        patch_jump(break_offset);
    }
    m_loop_stack.pop_back();
    end_scope();
}

void Compiler::visit(ForeveryStmtAST* node) {
    begin_scope();

    // 1. Declare __iter_index = 0
    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(make_constant(Value::number(0)), node->location.line, node->location.column);
    declare_variable("__iter_index", node->location.line, node->location.column);

    // 2. Evaluate collection and store in __iter_list
    if (node->collection) node->collection->accept(this);
    declare_variable("__iter_list", node->location.line, node->location.column);

    // 3. Declare item_var in local scope so display(item_var) resolves correctly
    emit_op(OpCode::OP_NIL, node->location.line, node->location.column);
    declare_variable(node->item_var, node->location.line, node->location.column);

    size_t loop_start = m_current_chunk->code.size();
    m_loop_stack.push_back({loop_start, {}});

    int idx_slot = resolve_local("__iter_index");
    int list_slot = resolve_local("__iter_list");
    int item_slot = resolve_local(node->item_var);

    // 4. Condition check: __iter_index < len(__iter_list)
    emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(idx_slot), node->location.line, node->location.column);

    uint16_t len_fn = make_constant(Value::make_string("len"));
    emit_op(OpCode::OP_GET_GLOBAL, node->location.line, node->location.column);
    emit_constant_index(len_fn, node->location.line, node->location.column);

    emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(list_slot), node->location.line, node->location.column);

    emit_op(OpCode::OP_CALL, node->location.line, node->location.column);
    emit_byte(1, node->location.line, node->location.column);

    emit_op(OpCode::OP_LESS, node->location.line, node->location.column);

    size_t exit_jump = emit_jump(OpCode::OP_JUMP_IF_FALSE, node->location.line, node->location.column);
    emit_op(OpCode::OP_POP, node->location.line, node->location.column);

    // 5. Assign element: item_var = __iter_list[__iter_index]
    emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(list_slot), node->location.line, node->location.column);

    emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(idx_slot), node->location.line, node->location.column);

    emit_op(OpCode::OP_GET_INDEX, node->location.line, node->location.column);
    emit_op(OpCode::OP_SET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(item_slot), node->location.line, node->location.column);

    // 6. Loop body
    if (node->body) node->body->accept(this);

    // 7. Increment index: __iter_index = __iter_index + 1
    emit_op(OpCode::OP_GET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(idx_slot), node->location.line, node->location.column);

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(make_constant(Value::number(1)), node->location.line, node->location.column);

    emit_op(OpCode::OP_ADD, node->location.line, node->location.column);
    emit_op(OpCode::OP_SET_LOCAL, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(idx_slot), node->location.line, node->location.column);

    emit_loop(loop_start, node->location.line, node->location.column);

    patch_jump(exit_jump);
    emit_op(OpCode::OP_POP, node->location.line, node->location.column);

    for (size_t break_offset : m_loop_stack.back().break_jumps) {
        patch_jump(break_offset);
    }
    m_loop_stack.pop_back();

    end_scope();
}

void Compiler::visit(ReturnStmtAST* node) {
    if (node->value) node->value->accept(this);
    else emit_op(OpCode::OP_NIL, node->location.line, node->location.column);
    emit_op(OpCode::OP_RETURN, node->location.line, node->location.column);
}

void Compiler::visit(BreakStmtAST* node) {
    if (m_loop_stack.empty()) {
        m_diagnostics.report(ErrorType::COMPILER, "Break statement outside loop.", node->location);
        return;
    }
    size_t break_jump = emit_jump(OpCode::OP_JUMP, node->location.line, node->location.column);
    m_loop_stack.back().break_jumps.push_back(break_jump);
}

void Compiler::visit(ContinueStmtAST* node) {
    if (m_loop_stack.empty()) {
        m_diagnostics.report(ErrorType::COMPILER, "Continue statement outside loop.", node->location);
        return;
    }
    emit_loop(m_loop_stack.back().start_offset, node->location.line, node->location.column);
}

void Compiler::visit(FunctionDeclStmtAST* node) {
    uint16_t name_idx = make_constant(Value::make_string(node->name));

    Compiler fn_compiler(m_diagnostics);
    fn_compiler.m_function_type = (node->name == "new_init__" || node->name == "__init__") ? FunctionType::TYPE_INIT : FunctionType::TYPE_FUNCTION;
    fn_compiler.begin_scope();

    for (const auto& param : node->parameters) {
        fn_compiler.declare_variable(param, node->location.line, node->location.column);
    }

    if (node->body) node->body->accept(&fn_compiler);
    fn_compiler.emit_op(OpCode::OP_NIL);
    fn_compiler.emit_op(OpCode::OP_RETURN);

    auto fn_chunk = fn_compiler.m_current_chunk;

    // Transfer ownership of any nested functions compiled inside this one
    for (auto& child : fn_compiler.m_sub_chunks) {
        fn_chunk->add_child_chunk(child);
    }

    // Keep this function's chunk alive for as long as the parent chunk lives.
    // Previously only a raw pointer was stored in constants while the shared_ptr
    // died with the Compiler — causing use-after-free and wrong return values.
    m_current_chunk->add_child_chunk(fn_chunk);
    m_sub_chunks.push_back(fn_chunk);

    uint16_t fn_idx = make_constant(Value::make_pointer(fn_chunk.get()));

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(fn_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
    emit_constant_index(name_idx, node->location.line, node->location.column);
}

void Compiler::visit(ClassDeclStmtAST* node) {
    // OP_CLASS creates a class object and leaves it on the stack
    uint16_t class_idx = make_constant(Value::make_string(node->name));
    emit_op(OpCode::OP_CLASS, node->location.line, node->location.column);
    emit_constant_index(class_idx, node->location.line, node->location.column);
    // stack: [class]

    if (!node->parent_class.empty()) {
        uint16_t parent_idx = make_constant(Value::make_string(node->parent_class));
        emit_op(OpCode::OP_GET_GLOBAL, node->location.line, node->location.column);
        emit_constant_index(parent_idx, node->location.line, node->location.column);
        // stack: [class, parent]
        emit_op(OpCode::OP_INHERIT, node->location.line, node->location.column);
        // stack: [class]  (methods copied from parent)
    }

    for (const auto& method : node->methods) {
        if (!method) continue;

        // Compile method body into its own chunk (do not DEFINE_GLOBAL)
        Compiler fn_compiler(m_diagnostics);
        fn_compiler.m_function_type = (method->name == "new_init__" || method->name == "__init__")
            ? FunctionType::TYPE_INIT : FunctionType::TYPE_METHOD;
        fn_compiler.begin_scope();
        for (const auto& param : method->parameters) {
            fn_compiler.declare_variable(param, method->location.line, method->location.column);
        }
        if (method->body) method->body->accept(&fn_compiler);
        fn_compiler.emit_op(OpCode::OP_NIL);
        fn_compiler.emit_op(OpCode::OP_RETURN);

        auto fn_chunk = fn_compiler.m_current_chunk;
        for (auto& child : fn_compiler.m_sub_chunks) {
            fn_chunk->add_child_chunk(child);
        }
        m_current_chunk->add_child_chunk(fn_chunk);
        m_sub_chunks.push_back(fn_chunk);

        // Push method name, then function pointer, then OP_METHOD binds them to the class
        uint16_t method_name_idx = make_constant(Value::make_string(method->name));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(method_name_idx, node->location.line, node->location.column);

        uint16_t fn_idx = make_constant(Value::make_pointer(fn_chunk.get()));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(fn_idx, node->location.line, node->location.column);

        // stack: [class, method_name, method_fn]
        emit_op(OpCode::OP_METHOD, node->location.line, node->location.column);
        // stack: [class]
    }

    // Define the class as a global: stack top is the class object
    uint16_t name_idx = make_constant(Value::make_string(node->name));
    emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
    emit_constant_index(name_idx, node->location.line, node->location.column);
}

void Compiler::visit(SystemDeclStmtAST* node) {
    // Systems are classes with __type__ = "system"
    uint16_t sys_idx = make_constant(Value::make_string(node->name));
    emit_op(OpCode::OP_SYSTEM, node->location.line, node->location.column);
    emit_constant_index(sys_idx, node->location.line, node->location.column);

    if (!node->parent_system.empty()) {
        uint16_t parent_idx = make_constant(Value::make_string(node->parent_system));
        emit_op(OpCode::OP_GET_GLOBAL, node->location.line, node->location.column);
        emit_constant_index(parent_idx, node->location.line, node->location.column);
        emit_op(OpCode::OP_INHERIT, node->location.line, node->location.column);
    }

    for (const auto& fld : node->fields) {
        if (fld) fld->accept(this);
    }

    for (const auto& comp : node->components) {
        if (!comp) continue;

        Compiler fn_compiler(m_diagnostics);
        fn_compiler.m_function_type = (comp->name == "new_init__" || comp->name == "__init__")
            ? FunctionType::TYPE_INIT : FunctionType::TYPE_METHOD;
        fn_compiler.begin_scope();
        for (const auto& param : comp->parameters) {
            fn_compiler.declare_variable(param, comp->location.line, comp->location.column);
        }
        if (comp->body) comp->body->accept(&fn_compiler);
        fn_compiler.emit_op(OpCode::OP_NIL);
        fn_compiler.emit_op(OpCode::OP_RETURN);

        auto fn_chunk = fn_compiler.m_current_chunk;
        for (auto& child : fn_compiler.m_sub_chunks) {
            fn_chunk->add_child_chunk(child);
        }
        m_current_chunk->add_child_chunk(fn_chunk);
        m_sub_chunks.push_back(fn_chunk);

        uint16_t method_name_idx = make_constant(Value::make_string(comp->name));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(method_name_idx, node->location.line, node->location.column);

        uint16_t fn_idx = make_constant(Value::make_pointer(fn_chunk.get()));
        emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
        emit_constant_index(fn_idx, node->location.line, node->location.column);

        emit_op(OpCode::OP_METHOD, node->location.line, node->location.column);
    }

    uint16_t name_idx = make_constant(Value::make_string(node->name));
    emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
    emit_constant_index(name_idx, node->location.line, node->location.column);
}

void Compiler::visit(ModeDeclStmtAST* node) {
    uint16_t mode_idx = make_constant(Value::make_string(node->mode_name));
    emit_op(OpCode::OP_MODE, node->location.line, node->location.column);
    emit_constant_index(mode_idx, node->location.line, node->location.column);
}

void Compiler::visit(ImportStmtAST* node) {
    uint16_t path_idx = make_constant(Value::make_string(node->path));
    uint16_t alias_idx = make_constant(Value::make_string(node->alias));

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(path_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(alias_idx, node->location.line, node->location.column);

    if (node->is_load) {
        emit_op(OpCode::OP_LOAD_SCRIPT, node->location.line, node->location.column);
    } else {
        emit_op(OpCode::OP_IMPORT_MODULE, node->location.line, node->location.column);
    }
}

void Compiler::visit(AttemptStmtAST* node) {
    size_t try_jump = emit_jump(OpCode::OP_PUSH_TRY, node->location.line, node->location.column);

    if (node->try_block) node->try_block->accept(this);
    emit_op(OpCode::OP_POP_TRY, node->location.line, node->location.column);

    if (node->success_block) node->success_block->accept(this);

    size_t skip_fail_jump = emit_jump(OpCode::OP_JUMP, node->location.line, node->location.column);

    patch_jump(try_jump);
    if (!node->catch_var.empty()) {
        if (m_scope_depth > 0) {
            begin_scope();
            declare_variable(node->catch_var, node->location.line, node->location.column);
        } else {
            uint16_t global_err = make_constant(Value::make_string(node->catch_var));
            emit_op(OpCode::OP_DEFINE_GLOBAL, node->location.line, node->location.column);
            emit_constant_index(global_err, node->location.line, node->location.column);
        }
    }

    if (node->catch_block) node->catch_block->accept(this);

    if (!node->catch_var.empty() && m_scope_depth > 0) end_scope();
    patch_jump(skip_fail_jump);

    if (node->always_block) node->always_block->accept(this);
}

void Compiler::visit(DisplayStmtAST* node) {
    // Push arguments first, then module + function name for OP_INVOKE_NATIVE
    for (const auto& expr : node->expressions) {
        if (expr) expr->accept(this);
    }

    uint16_t mod_idx = make_constant(Value::make_string("sys"));
    uint16_t fn_idx  = make_constant(Value::make_string("display"));

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(mod_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_CONSTANT, node->location.line, node->location.column);
    emit_constant_index(fn_idx, node->location.line, node->location.column);

    emit_op(OpCode::OP_INVOKE_NATIVE, node->location.line, node->location.column);
    emit_byte(static_cast<uint8_t>(node->expressions.size()), node->location.line, node->location.column);
    emit_op(OpCode::OP_POP, node->location.line, node->location.column);
}

} // namespace phoenix