#include "phoenix/compiler/optimizer.hpp"

namespace phoenix {

Optimizer::Optimizer(DiagnosticEngine& diagnostics)
    : m_diagnostics(diagnostics) {}

void Optimizer::optimize_ast(ProgramAST& program) {
    (void)m_diagnostics;
    for (auto& stmt : program.statements) {
        if (auto* expr_stmt = dynamic_cast<ExprStmtAST*>(stmt.get())) {
            fold_constants(expr_stmt->expression);
        }
    }
}

void Optimizer::fold_constants(ExprPtr& expr) {
    if (!expr) return;

    if (auto* bin = dynamic_cast<BinaryExprAST*>(expr.get())) {
        fold_constants(bin->left);
        fold_constants(bin->right);

        auto* lit_left = dynamic_cast<LiteralExprAST*>(bin->left.get());
        auto* lit_right = dynamic_cast<LiteralExprAST*>(bin->right.get());

        if (lit_left && lit_right) {
            if (lit_left->value.type == ValueType::NUMBER && lit_right->value.type == ValueType::NUMBER) {
                double a = lit_left->value.as_number();
                double b = lit_right->value.as_number();
                if (bin->op_type == TokenType::PLUS) expr = std::make_unique<LiteralExprAST>(Value::number(a + b), bin->location);
                else if (bin->op_type == TokenType::MINUS) expr = std::make_unique<LiteralExprAST>(Value::number(a - b), bin->location);
                else if (bin->op_type == TokenType::STAR) expr = std::make_unique<LiteralExprAST>(Value::number(a * b), bin->location);
                else if (bin->op_type == TokenType::SLASH && b!= 0) expr = std::make_unique<LiteralExprAST>(Value::number(a / b), bin->location);
            }
        }
    }
}

void Optimizer::optimize_bytecode(std::shared_ptr<Chunk> chunk) {
    if (!chunk) return;
    peephole_pass(*chunk);
}

void Optimizer::peephole_pass(Chunk& chunk) {
    auto& code = chunk.code;
    if (code.size() < 2) return;

    std::vector<uint8_t> optimized;
    optimized.reserve(code.size());

    for (size_t i = 0; i < code.size(); ++i) {
        if (i + 2 < code.size() &&
            static_cast<OpCode>(code[i]) == OpCode::OP_CONSTANT &&
            static_cast<OpCode>(code[i + 2]) == OpCode::OP_POP) {
            i += 2;
            continue;
        }
        optimized.push_back(code[i]);
    }
    code = std::move(optimized);
}

} // namespace phoenix