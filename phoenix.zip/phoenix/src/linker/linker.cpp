#include "phoenix/linker/linker.hpp"
#include "phoenix/linker/verifier.hpp"
#include <fstream>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <unordered_map>
#include <functional>

namespace phoenix {

Linker::Linker(DiagnosticEngine& diagnostics)
    : m_diagnostics(diagnostics) {}

void Linker::write_header(std::vector<uint8_t>& buffer) {
    buffer.push_back(0x50);
    buffer.push_back(0x48);
    buffer.push_back(0x58);
    buffer.push_back(0x00);
    buffer.push_back(PHX_VERSION_MAJOR);
    buffer.push_back(PHX_VERSION_MINOR);
    buffer.push_back(PHX_VERSION_PATCH);
    buffer.push_back(0x01); // format rev 1 = multi-chunk
}

static void write_u32(std::vector<uint8_t>& buffer, uint32_t v) {
    buffer.push_back(static_cast<uint8_t>(v & 0xFF));
    buffer.push_back(static_cast<uint8_t>((v >> 8) & 0xFF));
    buffer.push_back(static_cast<uint8_t>((v >> 16) & 0xFF));
    buffer.push_back(static_cast<uint8_t>((v >> 24) & 0xFF));
}

static uint32_t read_u32(const std::vector<uint8_t>& buffer, size_t& offset) {
    if (offset + 4 > buffer.size()) return 0;
    uint32_t v = buffer[offset] | (buffer[offset + 1] << 8) |
                 (buffer[offset + 2] << 16) | (buffer[offset + 3] << 24);
    offset += 4;
    return v;
}

void Linker::serialize_value(std::vector<uint8_t>& buffer, const Value& val) {
    buffer.push_back(static_cast<uint8_t>(val.type));
    switch (val.type) {
        case ValueType::NIL: break;
        case ValueType::BOOLEAN:
            buffer.push_back(val.as_bool() ? 1 : 0);
            break;
        case ValueType::NUMBER: {
            double num = val.as_number();
            uint8_t bytes[sizeof(double)];
            std::memcpy(bytes, &num, sizeof(double));
            for (size_t i = 0; i < sizeof(double); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::I8: case ValueType::I16: case ValueType::I32: case ValueType::I64: {
            int64_t n = val.as_i64();
            uint8_t bytes[sizeof(int64_t)];
            std::memcpy(bytes, &n, sizeof(int64_t));
            for (size_t i = 0; i < sizeof(int64_t); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::U8: case ValueType::U16: case ValueType::U32: case ValueType::U64: {
            uint64_t n = val.as_u64();
            uint8_t bytes[sizeof(uint64_t)];
            std::memcpy(bytes, &n, sizeof(uint64_t));
            for (size_t i = 0; i < sizeof(uint64_t); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::STRING: {
            std::string str = val.as_string();
            write_u32(buffer, static_cast<uint32_t>(str.size()));
            for (char c : str) buffer.push_back(static_cast<uint8_t>(c));
            break;
        }
        case ValueType::POINTER:
            write_u32(buffer, 0xFFFFFFFFu);
            break;
        default: {
            std::string repr = val.to_string();
            write_u32(buffer, static_cast<uint32_t>(repr.size()));
            for (char c : repr) buffer.push_back(static_cast<uint8_t>(c));
            break;
        }
    }
}

Value Linker::deserialize_value(const std::vector<uint8_t>& buffer, size_t& offset) {
    if (offset >= buffer.size()) return Value::nil();
    ValueType type = static_cast<ValueType>(buffer[offset++]);
    switch (type) {
        case ValueType::NIL: return Value::nil();
        case ValueType::BOOLEAN:
            if (offset >= buffer.size()) return Value::nil();
            return Value::boolean(buffer[offset++] != 0);
        case ValueType::NUMBER: {
            if (offset + sizeof(double) > buffer.size()) return Value::nil();
            double num = 0;
            std::memcpy(&num, buffer.data() + offset, sizeof(double));
            offset += sizeof(double);
            return Value::number(num);
        }
        case ValueType::I8: case ValueType::I16: case ValueType::I32: case ValueType::I64: {
            if (offset + sizeof(int64_t) > buffer.size()) return Value::nil();
            int64_t n = 0;
            std::memcpy(&n, buffer.data() + offset, sizeof(int64_t));
            offset += sizeof(int64_t);
            Value v; v.type = type; v.as.i64_val = n; return v;
        }
        case ValueType::U8: case ValueType::U16: case ValueType::U32: case ValueType::U64: {
            if (offset + sizeof(uint64_t) > buffer.size()) return Value::nil();
            uint64_t n = 0;
            std::memcpy(&n, buffer.data() + offset, sizeof(uint64_t));
            offset += sizeof(uint64_t);
            Value v; v.type = type; v.as.u64_val = n; return v;
        }
        case ValueType::STRING: {
            uint32_t len = read_u32(buffer, offset);
            if (offset + len > buffer.size()) return Value::nil();
            std::string s(reinterpret_cast<const char*>(buffer.data() + offset), len);
            offset += len;
            return Value::make_string(s);
        }
        case ValueType::POINTER: {
            uint32_t idx = read_u32(buffer, offset);
            return Value::make_pointer(reinterpret_cast<void*>(static_cast<uintptr_t>(idx)));
        }
        default: {
            uint32_t len = read_u32(buffer, offset);
            if (offset + len > buffer.size()) return Value::nil();
            offset += len;
            return Value::nil();
        }
    }
}

static void collect_chunks(const std::shared_ptr<Chunk>& root,
                           std::vector<std::shared_ptr<Chunk>>& flat,
                           std::unordered_map<Chunk*, uint32_t>& index_of) {
    if (!root) return;
    std::function<void(const std::shared_ptr<Chunk>&)> walk = [&](const std::shared_ptr<Chunk>& c) {
        if (!c || index_of.count(c.get())) return;
        index_of[c.get()] = static_cast<uint32_t>(flat.size());
        flat.push_back(c);
        for (const auto& child : c->child_chunks) walk(child);
    };
    walk(root);
}

static void serialize_value_with_map(std::vector<uint8_t>& buffer, const Value& val,
                                    const std::unordered_map<Chunk*, uint32_t>& index_of) {
    buffer.push_back(static_cast<uint8_t>(val.type));
    switch (val.type) {
        case ValueType::NIL: break;
        case ValueType::BOOLEAN:
            buffer.push_back(val.as_bool() ? 1 : 0);
            break;
        case ValueType::NUMBER: {
            double num = val.as_number();
            uint8_t bytes[sizeof(double)];
            std::memcpy(bytes, &num, sizeof(double));
            for (size_t i = 0; i < sizeof(double); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::I8: case ValueType::I16: case ValueType::I32: case ValueType::I64: {
            int64_t n = val.as_i64();
            uint8_t bytes[sizeof(int64_t)];
            std::memcpy(bytes, &n, sizeof(int64_t));
            for (size_t i = 0; i < sizeof(int64_t); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::U8: case ValueType::U16: case ValueType::U32: case ValueType::U64: {
            uint64_t n = val.as_u64();
            uint8_t bytes[sizeof(uint64_t)];
            std::memcpy(bytes, &n, sizeof(uint64_t));
            for (size_t i = 0; i < sizeof(uint64_t); ++i) buffer.push_back(bytes[i]);
            break;
        }
        case ValueType::STRING: {
            std::string str = val.as_string();
            write_u32(buffer, static_cast<uint32_t>(str.size()));
            for (char c : str) buffer.push_back(static_cast<uint8_t>(c));
            break;
        }
        case ValueType::POINTER: {
            uint32_t idx = 0xFFFFFFFFu;
            if (val.as_pointer()) {
                auto it = index_of.find(static_cast<Chunk*>(val.as_pointer()));
                if (it != index_of.end()) idx = it->second;
            }
            write_u32(buffer, idx);
            break;
        }
        default: {
            std::string repr = val.to_string();
            write_u32(buffer, static_cast<uint32_t>(repr.size()));
            for (char c : repr) buffer.push_back(static_cast<uint8_t>(c));
            break;
        }
    }
}

static void serialize_one_chunk(std::vector<uint8_t>& buffer, const std::shared_ptr<Chunk>& chunk,
                                const std::unordered_map<Chunk*, uint32_t>& index_of) {
    write_u32(buffer, static_cast<uint32_t>(chunk->constants.size()));
    for (const auto& c : chunk->constants)
        serialize_value_with_map(buffer, c, index_of);
    write_u32(buffer, static_cast<uint32_t>(chunk->code.size()));
    for (uint8_t b : chunk->code) buffer.push_back(b);
    write_u32(buffer, static_cast<uint32_t>(chunk->child_chunks.size()));
    for (const auto& child : chunk->child_chunks) {
        uint32_t idx = 0xFFFFFFFFu;
        if (child) {
            auto it = index_of.find(child.get());
            if (it != index_of.end()) idx = it->second;
        }
        write_u32(buffer, idx);
    }
}

bool Linker::link_pxc(std::shared_ptr<Chunk> chunk, const std::string& output_path) {
    if (!chunk) return false;
    std::vector<std::shared_ptr<Chunk>> flat;
    std::unordered_map<Chunk*, uint32_t> index_of;
    collect_chunks(chunk, flat, index_of);

    std::vector<uint8_t> buffer;
    write_header(buffer);
    write_u32(buffer, static_cast<uint32_t>(flat.size()));
    for (const auto& c : flat) serialize_one_chunk(buffer, c, index_of);

    std::ofstream out(output_path, std::ios::binary);
    if (!out.is_open()) return false;
    out.write(reinterpret_cast<const char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
    out.close();
    return true;
}

bool Linker::link_pxe(std::shared_ptr<Chunk> chunk, const std::string& output_path, const std::string& /* runtime_path */) {
    return link_pxc(chunk, output_path);
}

std::shared_ptr<Chunk> Linker::load_pxc(const std::string& input_path) {
    std::ifstream in(input_path, std::ios::binary);
    if (!in.is_open()) return nullptr;
    std::vector<uint8_t> buffer((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    in.close();
    return load_pxc_from_memory(buffer);
}

std::shared_ptr<Chunk> Linker::load_pxc_from_memory(const std::vector<uint8_t>& buffer) {
    if (buffer.size() < 8) return nullptr;
    if (buffer[0] != 0x50 || buffer[1] != 0x48 || buffer[2] != 0x58) return nullptr;

    uint8_t format_rev = buffer[7];
    size_t offset = 8;

    if (format_rev == 0x00) {
        auto chunk = std::make_shared<Chunk>();
        uint32_t const_count = read_u32(buffer, offset);
        for (uint32_t i = 0; i < const_count; ++i)
            chunk->constants.push_back(deserialize_value(buffer, offset));
        uint32_t code_count = read_u32(buffer, offset);
        for (uint32_t i = 0; i < code_count; ++i) {
            if (offset >= buffer.size()) break;
            chunk->write(buffer[offset++], 0, 0);
        }
        return chunk;
    }

    uint32_t chunk_count = read_u32(buffer, offset);
    if (chunk_count == 0 || chunk_count > 100000) return nullptr;

    std::vector<std::shared_ptr<Chunk>> flat(chunk_count);
    for (uint32_t i = 0; i < chunk_count; ++i) flat[i] = std::make_shared<Chunk>();
    std::vector<std::vector<uint32_t>> child_indices(chunk_count);

    for (uint32_t ci = 0; ci < chunk_count; ++ci) {
        auto& chunk = flat[ci];
        uint32_t const_count = read_u32(buffer, offset);
        for (uint32_t i = 0; i < const_count; ++i)
            chunk->constants.push_back(deserialize_value(buffer, offset));
        uint32_t code_count = read_u32(buffer, offset);
        for (uint32_t i = 0; i < code_count; ++i) {
            if (offset >= buffer.size()) break;
            chunk->write(buffer[offset++], 0, 0);
        }
        uint32_t nchildren = read_u32(buffer, offset);
        for (uint32_t k = 0; k < nchildren; ++k)
            child_indices[ci].push_back(read_u32(buffer, offset));
    }

    for (uint32_t ci = 0; ci < chunk_count; ++ci) {
        auto& chunk = flat[ci];
        for (auto& c : chunk->constants) {
            if (c.type == ValueType::POINTER) {
                uint32_t idx = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(c.as_pointer()));
                if (idx < chunk_count) c = Value::make_pointer(flat[idx].get());
                else c = Value::make_pointer(nullptr);
            }
        }
        for (uint32_t child_idx : child_indices[ci]) {
            if (child_idx < chunk_count)
                chunk->child_chunks.push_back(flat[child_idx]);
        }
    }

    return flat[0];
}

} // namespace phoenix
