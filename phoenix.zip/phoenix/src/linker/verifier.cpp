
#include "phoenix/linker/verifier.hpp"

namespace phoenix {

Verifier::Verifier(DiagnosticEngine& diagnostics)
    : m_diagnostics(diagnostics) {}

VerificationResult Verifier::verify_chunk(std::shared_ptr<Chunk> chunk) {
    if (!chunk) return {false, "Null bytecode chunk pointer provided for verification."};
    if (chunk->code.empty()) return {false, "Bytecode chunk contains no executable instructions."};
    
    // Ensure final instruction terminates execution
    if (static_cast<OpCode>(chunk->code.back()) != OpCode::OP_HALT &&
        static_cast<OpCode>(chunk->code.back()) != OpCode::OP_RETURN) {
        return {false, "Bytecode chunk lacks mandatory OP_HALT or OP_RETURN termination."};
    }

    return {true, ""};
}

bool Verifier::validate_header(const std::vector<uint8_t>& binary_data) {
    if (binary_data.size() < 8) return false;
    
    // Validate Magic Signature 'P', 'H', 'X', '\0'
    if (binary_data[0] != 0x50 || binary_data[1] != 0x48 || binary_data[2] != 0x58 || binary_data[3] != 0x00) {
        return false;
    }
    return true;
}

uint32_t Verifier::compute_checksum(const std::vector<uint8_t>& data) {
    // FNV-1a Hash Implementation
    uint32_t checksum = 0x811C9DC5;
    for (uint8_t byte : data) {
        checksum ^= byte;
        checksum *= 0x01000193;
    }
    return checksum;
}

} // namespace phoenix
