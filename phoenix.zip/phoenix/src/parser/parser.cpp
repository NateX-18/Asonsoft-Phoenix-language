#include "phoenix/parser/parser.hpp"
#include <iostream>
#include <sstream>

namespace phoenix {

const Token& Parser::peek() const noexcept {
    return tokens_[current_];
}

const Token& Parser::previous() const noexcept {
    return tokens_[current_ - 1];
}

bool Parser::is_at_end() const noexcept {
    return peek().type == TokenType::TOKEN_EOF;
}

Token Parser::advance() {
    if (!is_at_end()) {
        current_++;
    }
    return previous();
}

bool Parser::check(TokenType type) const noexcept {
    if (is_at_end()) return false;
    return peek().type == type;
}

bool Parser::match(TokenType type) {
    if (check(type)) {
        advance();
        return true;
    }
    return false;
}

bool Parser::match(std::initializer_list<TokenType> types) {
    for (TokenType type : types) {
        if (check(type)) {
            advance();
            return true;
        }
    }
    return false;
}

Token Parser::consume(TokenType type, const std::string& message) {
    if (check(type)) return advance();
    report_error(peek(), message);
    throw PhoenixException(ErrorType::PARSER, message, peek().location);
}

void Parser::report_error(const Token& token, const std::string& message) {
    diagnostics_.report(ErrorType::PARSER, message, token.location);
}

void Parser::synchronize() {
    advance();

    while (!is_at_end()) {
        if (previous().type == TokenType::SEMICOLON) return;

        switch (peek().type) {
            case TokenType::KEYWORD_CLASS:
            case TokenType::KEYWORD_SYSTEM:
            case TokenType::KEYWORD_DEFINE:
            case TokenType::KEYWORD_LET:
            case TokenType::KEYWORD_LIST:
            case TokenType::KEYWORD_DICT:
            case TokenType::KEYWORD_DTYPE:
            case TokenType::KEYWORD_STATE:
            case TokenType::KEYWORD_STATE_DTYPE:
            case TokenType::KEYWORD_FOR:
            case TokenType::KEYWORD_FOREVERY:
            case TokenType::KEYWORD_IF:
            case TokenType::KEYWORD_WHILE:
            case TokenType::KEYWORD_RETURN:
            case TokenType::KEYWORD_ATTEMPT:
            case TokenType::KEYWORD_DISPLAY:
            case TokenType::KEYWORD_MODE:
                return;
            default:
                break;
        }

        advance();
    }
}

Precedence Parser::get_token_precedence(TokenType type) const noexcept {
    switch (type) {
        case TokenType::ASSIGN:
        case TokenType::PLUS_ASSIGN:
        case TokenType::MINUS_ASSIGN:
        case TokenType::STAR_ASSIGN:
        case TokenType::SLASH_ASSIGN:
            return Precedence::ASSIGNMENT;

        case TokenType::KEYWORD_OR:
        case TokenType::OR:
            return Precedence::OR;

        case TokenType::KEYWORD_AND:
        case TokenType::AND:
            return Precedence::AND;

        case TokenType::EQUAL:
        case TokenType::NOT_EQUAL:
            return Precedence::EQUALITY;

        case TokenType::LESS:
        case TokenType::LESS_EQUAL:
        case TokenType::GREATER:
        case TokenType::GREATER_EQUAL:
            return Precedence::COMPARISON;

        case TokenType::TYPE_MAP:
            return Precedence::TYPE_MAP;

        case TokenType::PLUS:
        case TokenType::MINUS:
            return Precedence::TERM;

        case TokenType::STAR:
        case TokenType::SLASH:
        case TokenType::PERCENT:
            return Precedence::FACTOR;

        case TokenType::DOT:
        case TokenType::LPAREN:
        case TokenType::LBRACKET:
            return Precedence::CALL;

        default:
            return Precedence::NONE;
    }
}

ExprPtr Parser::parse_primary() {
    Token tok = peek();

    if (match(TokenType::INT_LITERAL) || match(TokenType::FLOAT_LITERAL) || match(TokenType::STRING_LITERAL)) {
        return std::make_unique<LiteralExprAST>(previous().literal, previous().location);
    }

    if (match(TokenType::KEYWORD_TRUE)) {
        return std::make_unique<LiteralExprAST>(Value::boolean(true), previous().location);
    }

    if (match(TokenType::KEYWORD_FALSE)) {
        return std::make_unique<LiteralExprAST>(Value::boolean(false), previous().location);
    }

    if (match(TokenType::KEYWORD_NIL)) {
        return std::make_unique<LiteralExprAST>(Value::nil(), previous().location);
    }

    if (match(TokenType::KEYWORD_INPUT)) {
        return parse_input_expression();
    }

    if (match(TokenType::IDENTIFIER) || match(TokenType::KEYWORD_STRUCT) ||
        match({TokenType::KEYWORD_OPEN, TokenType::KEYWORD_CLOSE, TokenType::KEYWORD_READ,
               TokenType::KEYWORD_READLN, TokenType::KEYWORD_WRITE, TokenType::KEYWORD_SEEK,
               TokenType::KEYWORD_MKDIR, TokenType::KEYWORD_COPY, TokenType::KEYWORD_MOVE,
               TokenType::KEYWORD_DELETE})) {
        return std::make_unique<IdentifierExprAST>(previous().lexeme, previous().location);
    }

    if (match(TokenType::DOLLAR)) {
        SourceLocation loc = previous().location;
        Token table_tok = consume(TokenType::IDENTIFIER, "Expected dictionary identifier after '$'.");
        consume(TokenType::LBRACKET, "Expected '[' after table identifier.");

        bool is_primary = match(TokenType::STAR);
        ExprPtr key_expr = parse_expression();
        consume(TokenType::RBRACKET, "Expected ']' closing table field specification.");

        return std::make_unique<TableKeyExprAST>(table_tok.lexeme, std::move(key_expr), is_primary, loc);
    }

    if (match(TokenType::PRIMARY_KEY_QUERY)) {
        SourceLocation loc = previous().location;
        Token dict_tok = consume(TokenType::IDENTIFIER, "Expected dictionary name after '*$'.");
        consume(TokenType::LBRACKET, "Expected '[' for primary key query index.");
        ExprPtr key_expr = parse_expression();
        consume(TokenType::RBRACKET, "Expected ']' closing primary key query.");

        return std::make_unique<PrimaryKeyQueryExprAST>(dict_tok.lexeme, std::move(key_expr), loc);
    }

    if (match(TokenType::AT)) {
        SourceLocation loc = previous().location;
        Token target = consume(TokenType::IDENTIFIER, "Expected function or module identifier after '@'.");

        std::string mod_or_func = target.lexeme;
        std::string method_name;

        if (match(TokenType::DOT)) {
            Token method_tok = consume(TokenType::IDENTIFIER, "Expected method identifier after '.'.");
            method_name = method_tok.lexeme;
        }

        consume(TokenType::LPAREN, "Expected '(' for native function argument list.");
        std::vector<ExprPtr> args;
        if (!check(TokenType::RPAREN)) {
            do {
                args.push_back(parse_expression());
            } while (match(TokenType::COMMA));
        }
        consume(TokenType::RPAREN, "Expected ')' closing native function arguments.");

        if (method_name.empty()) {
            return std::make_unique<NativeCallExprAST>("sys", mod_or_func, std::move(args), loc);
        } else {
            return std::make_unique<NativeCallExprAST>(mod_or_func, method_name, std::move(args), loc);
        }
    }

    if (match(TokenType::LBRACKET)) {
        SourceLocation loc = previous().location;
        std::vector<ExprPtr> elements;

        if (!check(TokenType::RBRACKET)) {
            do {
                elements.push_back(parse_expression());
            } while (match(TokenType::COMMA));
        }

        consume(TokenType::RBRACKET, "Expected ']' closing list literal.");
        return std::make_unique<ListLiteralExprAST>(std::move(elements), loc);
    }

    if (match(TokenType::LPAREN)) {
        auto expr = parse_expression();
        consume(TokenType::RPAREN, "Expected ')' after grouped expression.");
        return expr;
    }

    report_error(tok, "Unexpected token '" + tok.lexeme + "' in expression.");
    throw PhoenixException(ErrorType::PARSER, "Unexpected expression token", tok.location);
}

ExprPtr Parser::parse_input_expression() {
    SourceLocation loc = previous().location;
    consume(TokenType::LPAREN, "Expected '(' after 'input'.");
    ExprPtr prompt = nullptr;
    if (!check(TokenType::RPAREN)) {
        prompt = parse_expression();
    }
    consume(TokenType::RPAREN, "Expected ')' closing input parameters.");
    return std::make_unique<InputExprAST>(std::move(prompt), loc);
}

ExprPtr Parser::parse_prefix() {
    if (match({TokenType::BANG, TokenType::MINUS})) {
        Token op_tok = previous();
        ExprPtr operand = parse_expression(Precedence::UNARY);
        return std::make_unique<UnaryExprAST>(op_tok.type, std::move(operand), op_tok.location);
    }

    return parse_primary();
}

ExprPtr Parser::parse_infix(ExprPtr left, TokenType op_type) {
    SourceLocation loc = previous().location;

    if (op_type == TokenType::TYPE_MAP) {
        Token target_type = consume(TokenType::IDENTIFIER, "Expected target type identifier after '<~>'.");
        return std::make_unique<TypeMapExprAST>(std::move(left), target_type.lexeme, loc);
    }

    if (op_type == TokenType::LPAREN) {
        std::vector<ExprPtr> args;
        if (!check(TokenType::RPAREN)) {
            do {
                args.push_back(parse_expression());
            } while (match(TokenType::COMMA));
        }
        consume(TokenType::RPAREN, "Expected ')' closing call argument list.");
        return std::make_unique<CallExprAST>(std::move(left), std::move(args), loc);
    }

    if (op_type == TokenType::DOT) {
        Token member = consume(TokenType::IDENTIFIER, "Expected member identifier after '.'.");
        return std::make_unique<MemberExprAST>(std::move(left), member.lexeme, loc);
    }

    if (op_type == TokenType::LBRACKET) {
        ExprPtr index = parse_expression();
        consume(TokenType::RBRACKET, "Expected ']' closing index expression.");
        return std::make_unique<IndexExprAST>(std::move(left), std::move(index), loc);
    }

    Precedence prec = get_token_precedence(op_type);
    Precedence next_prec = static_cast<Precedence>(static_cast<int>(prec) + 1);
    ExprPtr right = parse_expression(next_prec);
    return std::make_unique<BinaryExprAST>(op_type, std::move(left), std::move(right), loc);
}

ExprPtr Parser::parse_expression(Precedence precedence) {
    ExprPtr left = parse_prefix();

    while (precedence < get_token_precedence(peek().type)) {
        Token op_tok = advance();

        if (op_tok.type == TokenType::ASSIGN || op_tok.type == TokenType::PLUS_ASSIGN ||
            op_tok.type == TokenType::MINUS_ASSIGN || op_tok.type == TokenType::STAR_ASSIGN ||
            op_tok.type == TokenType::SLASH_ASSIGN) {

            ExprPtr value = parse_expression(Precedence::ASSIGNMENT);

            if (auto* id_ast = dynamic_cast<IdentifierExprAST*>(left.get())) {
                // Plain: name = value
                left = std::make_unique<AssignExprAST>(id_ast->name, op_tok.type, std::move(value), op_tok.location);
            } else if (auto* mem_ast = dynamic_cast<MemberExprAST*>(left.get())) {
                // Member: object.field = value  (used in new_init__)
                left = std::make_unique<AssignExprAST>(
                    std::move(mem_ast->object), mem_ast->member, op_tok.type, std::move(value), op_tok.location);
            } else {
                report_error(op_tok, "Invalid assignment target.");
                throw PhoenixException(ErrorType::PARSER, "Invalid l-value target", op_tok.location);
            }
        } else {
            left = parse_infix(std::move(left), op_tok.type);
        }
    }

    return left;
}

StmtPtr Parser::parse_var_decl_statement() {
    Token decl_tok = previous();
    VarDeclKind kind = VarDeclKind::LET;

    if (decl_tok.type == TokenType::KEYWORD_LET) kind = VarDeclKind::LET;
    else if (decl_tok.type == TokenType::KEYWORD_LIST) kind = VarDeclKind::LIST;
    else kind = VarDeclKind::DICT;

    Token name_tok = consume(TokenType::IDENTIFIER, "Expected variable identifier name.");

    ExprPtr initializer = nullptr;
    if (match(TokenType::ASSIGN)) {
        initializer = parse_expression();
    }

    std::string type_ann = "";
    if (match(TokenType::TYPE_MAP)) {
        Token t_tok = consume(TokenType::IDENTIFIER, "Expected target data type after <~>.");
        type_ann = t_tok.lexeme;
    }

    return std::make_unique<VarDeclStmtAST>(name_tok.lexeme, std::move(initializer), type_ann, decl_tok.location);
}

StmtPtr Parser::parse_bulk_decl_statement() {
    SourceLocation loc = previous().location;
    TokenType decl_type = previous().type;

    std::string data_type;
    std::string state_modifier;
    bool is_dtype = (decl_type == TokenType::KEYWORD_DTYPE || decl_type == TokenType::KEYWORD_STATE_DTYPE);
    bool is_state = (decl_type == TokenType::KEYWORD_STATE || decl_type == TokenType::KEYWORD_STATE_DTYPE);

    if (decl_type == TokenType::KEYWORD_STATE_DTYPE) {
        if (check(TokenType::KEYWORD_VOLATILE)) advance();
        Token type_tok = consume(TokenType::IDENTIFIER, "Expected target data type after 'state~dtype'.");
        data_type = type_tok.lexeme;
    }

    consume(TokenType::LBRACE, "Expected '{' enclosing bulk variable list.");
    std::vector<std::string> vars;
    if (!check(TokenType::RBRACE)) {
        do {
            Token v_tok = consume(TokenType::IDENTIFIER, "Expected variable identifier in bulk declaration.");
            vars.push_back(v_tok.lexeme);
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RBRACE, "Expected '}' closing bulk variable list.");

    if (decl_type == TokenType::KEYWORD_DTYPE) {
        consume(TokenType::STREAM_LEFT, "Expected '<~' after bulk variable list in 'dtype'.");
        Token type_tok = consume(TokenType::IDENTIFIER, "Expected data type identifier after '<~'.");
        data_type = type_tok.lexeme;
    } else if (decl_type == TokenType::KEYWORD_STATE || decl_type == TokenType::KEYWORD_STATE_DTYPE) {
        Token mod_tok;
        if (match({TokenType::KEYWORD_VOLATILE, TokenType::KEYWORD_CONSTANT})) {
            mod_tok = previous();
        } else {
            mod_tok = consume(TokenType::IDENTIFIER, "Expected state modifier (global, public, private, volatile, constant).");
        }
        state_modifier = mod_tok.lexeme;
    }

    return std::make_unique<BulkDeclStmtAST>(std::move(vars), data_type, state_modifier, is_dtype, is_state, loc);
}

StmtPtr Parser::parse_dict_statement() {
    SourceLocation loc = previous().location;
    Token name_tok = consume(TokenType::IDENTIFIER, "Expected dictionary name identifier.");

    std::vector<std::string> cols;
    std::string primary_key;

    consume(TokenType::LBRACKET, "Expected '[' starting schema columns.");
    if (!check(TokenType::RBRACKET)) {
        do {
            bool is_pk = match(TokenType::STAR);
            Token col_tok = consume(TokenType::STRING_LITERAL, "Column names must be string literals.");
            std::string c_name = col_tok.literal.is_string() ? col_tok.literal.as_string() : col_tok.lexeme;
            cols.push_back(c_name);
            if (is_pk) primary_key = c_name;
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RBRACKET, "Expected ']' closing schema columns.");
    consume(TokenType::ASSIGN, "Expected '=' before dictionary initializer matrix.");

    consume(TokenType::LBRACE, "Expected '{' starting dictionary records matrix.");
    std::vector<std::vector<ExprPtr>> rows;
    if (!check(TokenType::RBRACE)) {
        do {
            consume(TokenType::LBRACKET, "Expected '[' for row record.");
            std::vector<ExprPtr> row_vals;
            if (!check(TokenType::RBRACKET)) {
                do {
                    row_vals.push_back(parse_expression());
                } while (match(TokenType::COMMA));
            }
            consume(TokenType::RBRACKET, "Expected ']' closing row record.");
            rows.push_back(std::move(row_vals));
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RBRACE, "Expected '}' closing dictionary records matrix.");

    auto dict_expr = std::make_unique<DictLiteralExprAST>(cols, primary_key, std::move(rows), loc);
    return std::make_unique<VarDeclStmtAST>(VarDeclKind::DICT, name_tok.lexeme, std::move(dict_expr), loc);
}

StmtPtr Parser::parse_dict_schema_add_col() {
    SourceLocation loc = previous().location;
    Token name_tok = consume(TokenType::IDENTIFIER, "Expected dictionary identifier after '$'.");
    consume(TokenType::LBRACKET, "Expected '[' for column specification.");
    Token col_tok = consume(TokenType::STRING_LITERAL, "New column name must be string literal.");
    consume(TokenType::RBRACKET, "Expected ']' closing column specification.");

    std::string col_str = col_tok.literal.is_string() ? col_tok.literal.as_string() : col_tok.lexeme;
    return std::make_unique<DictSchemaAddColStmtAST>(name_tok.lexeme, col_str, loc);
}

StmtPtr Parser::parse_asm_statement() {
    SourceLocation loc = previous().location;
    consume(TokenType::LBRACE, "Expected '{' starting asm block.");
    std::vector<std::string> insts;
    while (!check(TokenType::RBRACE) && !is_at_end()) {
        Token inst_tok = consume(TokenType::STRING_LITERAL, "Asm instructions must be string literals.");
        insts.push_back(inst_tok.literal.is_string() ? inst_tok.literal.as_string() : inst_tok.lexeme);
    }
    consume(TokenType::RBRACE, "Expected '}' closing asm block.");
    return std::make_unique<AsmStmtAST>(std::move(insts), loc);
}

StmtPtr Parser::parse_block_statement() {
    SourceLocation loc = previous().location;
    std::vector<StmtPtr> statements;

    while (!check(TokenType::RBRACE) && !is_at_end()) {
        statements.push_back(parse_statement());
    }

    consume(TokenType::RBRACE, "Expected '}' closing block statement.");
    return std::make_unique<BlockStmtAST>(std::move(statements), loc);
}

StmtPtr Parser::parse_mode_statement() {
    SourceLocation loc = previous().location;
    Token mode_tok = consume(TokenType::IDENTIFIER, "Expected mode identifier (os, graphics, std, net).");
    return std::make_unique<ModeDeclStmtAST>(mode_tok.lexeme, loc);
}

StmtPtr Parser::parse_if_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LPAREN, "Expected '(' after 'if'.");
    ExprPtr condition = parse_expression();
    consume(TokenType::RPAREN, "Expected ')' closing if condition.");

    consume(TokenType::LBRACE, "Expected '{' starting if body.");
    StmtPtr then_branch = parse_block_statement();

    std::vector<ElifBranchAST> elif_branches;
    while (match(TokenType::KEYWORD_ELIF)) {
        consume(TokenType::LPAREN, "Expected '(' after 'elif'.");
        ExprPtr elif_cond = parse_expression();
        consume(TokenType::RPAREN, "Expected ')' closing elif condition.");

        consume(TokenType::LBRACE, "Expected '{' starting elif body.");
        StmtPtr elif_body = parse_block_statement();
        elif_branches.push_back(ElifBranchAST{std::move(elif_cond), std::move(elif_body)});
    }

    StmtPtr else_branch = nullptr;
    if (match(TokenType::KEYWORD_ELSE)) {
        consume(TokenType::LBRACE, "Expected '{' starting else body.");
        else_branch = parse_block_statement();
    }

    return std::make_unique<IfStmtAST>(std::move(condition), std::move(then_branch), std::move(elif_branches), std::move(else_branch), loc);
}

StmtPtr Parser::parse_while_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LPAREN, "Expected '(' after 'while'.");
    ExprPtr condition = parse_expression();
    consume(TokenType::RPAREN, "Expected ')' closing while condition.");

    consume(TokenType::LBRACE, "Expected '{' starting while body.");
    StmtPtr body = parse_block_statement();

    return std::make_unique<WhileStmtAST>(std::move(condition), std::move(body), loc);
}

StmtPtr Parser::parse_for_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LPAREN, "Expected '(' after 'for'.");

    StmtPtr initializer = nullptr;
    if (match(TokenType::KEYWORD_LET)) {
        initializer = parse_var_decl_statement();
    } else {
        initializer = parse_expr_statement();
    }
    match(TokenType::COMMA) || match(TokenType::SEMICOLON);

    ExprPtr condition = parse_expression();
    match(TokenType::COMMA) || match(TokenType::SEMICOLON);

    ExprPtr increment = parse_expression();
    consume(TokenType::RPAREN, "Expected ')' closing for loop header.");

    consume(TokenType::LBRACE, "Expected '{' starting for loop body.");
    StmtPtr body = parse_block_statement();

    return std::make_unique<ForStmtAST>(std::move(initializer), std::move(condition), std::move(increment), std::move(body), loc);
}

StmtPtr Parser::parse_forevery_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LPAREN, "Expected '(' after 'forevery'.");
    Token item_tok = consume(TokenType::IDENTIFIER, "Expected loop variable identifier in 'forevery'.");
    consume(TokenType::KEYWORD_IN, "Expected 'in' keyword in 'forevery' loop.");
    ExprPtr collection = parse_expression();
    consume(TokenType::RPAREN, "Expected ')' closing forevery loop header.");

    consume(TokenType::LBRACE, "Expected '{' starting forevery loop body.");
    StmtPtr body = parse_block_statement();

    return std::make_unique<ForeveryStmtAST>(item_tok.lexeme, std::move(collection), std::move(body), loc);
}

StmtPtr Parser::parse_function_decl_statement(const std::string& /* kind */) {
    SourceLocation loc = previous().location;

    Token name_tok = consume(TokenType::IDENTIFIER, "Expected function name after 'define'.");
    consume(TokenType::LPAREN, "Expected '(' after function identifier.");

    std::vector<std::string> params;
    if (!check(TokenType::RPAREN)) {
        do {
            Token param_tok;
            if (check(TokenType::KEYWORD_STRUCT)) {
                param_tok = advance();
            } else {
                param_tok = consume(TokenType::IDENTIFIER, "Parameter names must be valid identifiers.");
            }
            params.push_back(param_tok.lexeme);
            if (match(TokenType::COLON)) {
                consume(TokenType::IDENTIFIER, "Expected type specifier after ':'.");
            }
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RPAREN, "Expected ')' closing function parameters.");

    std::string ret_map;
    if (match(TokenType::TYPE_MAP)) {
        Token type_tok = consume(TokenType::IDENTIFIER, "Expected return type after '<~>'.");
        ret_map = type_tok.lexeme;
    }

    consume(TokenType::LBRACE, "Expected '{' starting function body block.");
    StmtPtr body = parse_block_statement();

    return std::make_unique<FunctionDeclStmtAST>(name_tok.lexeme, std::move(params), ret_map, std::move(body), loc);
}

StmtPtr Parser::parse_class_decl_statement() {
    SourceLocation loc = previous().location;

    Token name_tok = consume(TokenType::IDENTIFIER, "Expected class name after 'class'.");

    std::string parent_class = "";
    if (match(TokenType::KEYWORD_EXTENDS) || match(TokenType::COLON)) {
        Token parent_tok = consume(TokenType::IDENTIFIER, "Expected parent class name after 'extends' or ':'.");
        parent_class = parent_tok.lexeme;
    }

    consume(TokenType::LBRACE, "Expected '{' starting class body.");

    std::vector<std::unique_ptr<FunctionDeclStmtAST>> methods;

    while (!check(TokenType::RBRACE) && !is_at_end()) {
        if (match(TokenType::KEYWORD_DEFINE)) {
            auto func_node = parse_function_decl_statement("method");
            FunctionDeclStmtAST* func_ptr = dynamic_cast<FunctionDeclStmtAST*>(func_node.get());
            if (func_ptr) {
                func_node.release();
                methods.emplace_back(func_ptr);
            }
        } else {
            report_error(peek(), "Only 'define' method constructs are allowed inside class body.");
            advance();
        }
    }

    consume(TokenType::RBRACE, "Expected '}' closing class definition.");
    return std::make_unique<ClassDeclStmtAST>(name_tok.lexeme, parent_class, std::move(methods), loc);
}

StmtPtr Parser::parse_system_decl_statement() {
    SourceLocation loc = previous().location;

    Token name_tok = consume(TokenType::IDENTIFIER, "Expected system name after 'system'.");

    std::string parent_system = "";
    if (match(TokenType::KEYWORD_EXTENDS) || match(TokenType::COLON)) {
        Token parent_tok = consume(TokenType::IDENTIFIER, "Expected parent system name after 'extends' or ':'.");
        parent_system = parent_tok.lexeme;
    }

    consume(TokenType::LBRACE, "Expected '{' starting system body.");

    std::vector<StmtPtr> fields;
    std::vector<std::unique_ptr<FunctionDeclStmtAST>> components;

    while (!check(TokenType::RBRACE) && !is_at_end()) {
        if (match({TokenType::KEYWORD_DTYPE, TokenType::KEYWORD_STATE, TokenType::KEYWORD_STATE_DTYPE})) {
            fields.push_back(parse_bulk_decl_statement());
        } else if (match(TokenType::KEYWORD_DEFINE)) {
            auto func_node = parse_function_decl_statement("system_method");
            FunctionDeclStmtAST* func_ptr = dynamic_cast<FunctionDeclStmtAST*>(func_node.get());
            if (func_ptr) {
                func_node.release();
                components.emplace_back(func_ptr);
            }
        } else {
            fields.push_back(parse_statement());
        }
    }

    consume(TokenType::RBRACE, "Expected '}' closing system definition.");
    return std::make_unique<SystemDeclStmtAST>(name_tok.lexeme, parent_system, std::move(fields), std::move(components), loc);
}

StmtPtr Parser::parse_attempt_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LBRACE, "Expected '{' starting attempt block.");
    StmtPtr try_block = parse_block_statement();

    std::string catch_type;
    std::string catch_var;
    StmtPtr catch_block = nullptr;

    while (match(TokenType::KEYWORD_FAIL)) {
        Token type_tok = consume(TokenType::IDENTIFIER, "Expected exception type identifier after 'fail'.");
        catch_type = type_tok.lexeme;

        if (match(TokenType::KEYWORD_AS)) {
            Token var_tok = consume(TokenType::IDENTIFIER, "Expected variable name after 'as'.");
            catch_var = var_tok.lexeme;
        }

        consume(TokenType::LBRACE, "Expected '{' starting catch block.");
        catch_block = parse_block_statement();
    }

    StmtPtr success_block = nullptr;
    if (match(TokenType::KEYWORD_SUCCESS)) {
        consume(TokenType::LBRACE, "Expected '{' starting success block.");
        success_block = parse_block_statement();
    }

    StmtPtr always_block = nullptr;
    if (match(TokenType::KEYWORD_ALWAYS)) {
        consume(TokenType::LBRACE, "Expected '{' starting always block.");
        always_block = parse_block_statement();
    }

    return std::make_unique<AttemptStmtAST>(
        std::move(try_block), catch_type, catch_var,
        std::move(catch_block), std::move(success_block), std::move(always_block), loc
    );
}

StmtPtr Parser::parse_display_statement() {
    SourceLocation loc = previous().location;

    consume(TokenType::LPAREN, "Expected '(' after 'display'.");
    std::vector<ExprPtr> exprs;

    if (!check(TokenType::RPAREN)) {
        do {
            exprs.push_back(parse_expression());
        } while (match(TokenType::COMMA));
    }

    consume(TokenType::RPAREN, "Expected ')' closing display expression list.");
    return std::make_unique<DisplayStmtAST>(std::move(exprs), loc);
}

StmtPtr Parser::parse_import_statement() {
    SourceLocation loc = previous().location;
    bool is_load = (previous().type == TokenType::KEYWORD_LOAD);

    std::string path_str;
    if (is_load) {
        Token module_tok = consume(TokenType::STRING_LITERAL, "Expected script file path string literal after load.");
        path_str = module_tok.literal.is_string() ? module_tok.literal.as_string() : module_tok.lexeme;
    } else {
        Token module_tok = consume(TokenType::IDENTIFIER, "Expected unquoted module name identifier after import.");
        path_str = module_tok.lexeme;
    }

    std::string alias = path_str;
    if (match(TokenType::KEYWORD_AS)) {
        Token alias_tok = consume(TokenType::IDENTIFIER, "Expected alias identifier after 'as'.");
        alias = alias_tok.lexeme;
    }

    return std::make_unique<ImportStmtAST>(path_str, alias, is_load, loc);
}

StmtPtr Parser::parse_expr_statement() {
    SourceLocation loc = peek().location;
    ExprPtr expr = parse_expression();

    if (match(TokenType::STREAM_RIGHT)) {
        consume(TokenType::LPAREN, "Expected '(' for stream write or row assignment.");
        Token col_tok = consume(TokenType::STRING_LITERAL, "Target column must be string literal.");
        consume(TokenType::COMMA, "Expected ',' between column and streamed value.");
        ExprPtr val_expr = parse_expression();
        consume(TokenType::RPAREN, "Expected ')' closing stream assignment.");

        auto* idx_ast = dynamic_cast<IndexExprAST*>(expr.get());
        if (idx_ast) {
            auto* id_target = dynamic_cast<IdentifierExprAST*>(idx_ast->target.get());
            if (id_target) {
                std::string dict_name = id_target->name;
                std::string col_str = col_tok.literal.is_string() ? col_tok.literal.as_string() : col_tok.lexeme;
                return std::make_unique<DictStreamUpsertStmtAST>(dict_name, std::move(idx_ast->index), col_str, std::move(val_expr), true, loc);
            }
        }

        report_error(previous(), "Invalid stream assignment target.");
        throw PhoenixException(ErrorType::PARSER, "Target of '~>' stream assignment must be an indexable dictionary expression", loc);
    }

    match(TokenType::SEMICOLON);
    return std::make_unique<ExprStmtAST>(std::move(expr), loc);
}

StmtPtr Parser::parse_statement() {
    try {
        if (match(TokenType::KEYWORD_MODE)) {
            return parse_mode_statement();
        }
        if (match(TokenType::KEYWORD_LET) || match(TokenType::KEYWORD_LIST)) {
            return parse_var_decl_statement();
        }
        if (match(TokenType::KEYWORD_DICT)) {
            return parse_dict_statement();
        }
        if (match({TokenType::KEYWORD_DTYPE, TokenType::KEYWORD_STATE, TokenType::KEYWORD_STATE_DTYPE})) {
            return parse_bulk_decl_statement();
        }
        if (match(TokenType::DOLLAR)) {
            return parse_dict_schema_add_col();
        }
        if (match(TokenType::KEYWORD_ASM)) {
            return parse_asm_statement();
        }
        if (match(TokenType::KEYWORD_IF)) {
            return parse_if_statement();
        }
        if (match(TokenType::KEYWORD_WHILE)) {
            return parse_while_statement();
        }
        if (match(TokenType::KEYWORD_FOR)) {
            return parse_for_statement();
        }
        if (match(TokenType::KEYWORD_FOREVERY)) {
            return parse_forevery_statement();
        }
        if (match(TokenType::KEYWORD_RETURN)) {
            SourceLocation loc = previous().location;
            ExprPtr val = nullptr;
            if (!check(TokenType::SEMICOLON) && !check(TokenType::RBRACE)) {
                val = parse_expression();
            }
            match(TokenType::SEMICOLON);
            return std::make_unique<ReturnStmtAST>(std::move(val), loc);
        }
        if (match(TokenType::KEYWORD_BREAK)) {
            SourceLocation loc = previous().location;
            match(TokenType::SEMICOLON);
            return std::make_unique<BreakStmtAST>(loc);
        }
        if (match(TokenType::KEYWORD_CONTINUE)) {
            SourceLocation loc = previous().location;
            match(TokenType::SEMICOLON);
            return std::make_unique<ContinueStmtAST>(loc);
        }
        if (match(TokenType::KEYWORD_DEFINE)) {
            return parse_function_decl_statement();
        }
        if (match(TokenType::KEYWORD_CLASS)) {
            return parse_class_decl_statement();
        }
        if (match(TokenType::KEYWORD_SYSTEM)) {
            return parse_system_decl_statement();
        }
        if (match({TokenType::KEYWORD_IMPORT, TokenType::KEYWORD_LOAD})) {
            return parse_import_statement();
        }
        if (match(TokenType::KEYWORD_ATTEMPT)) {
            return parse_attempt_statement();
        }
        if (match(TokenType::KEYWORD_DISPLAY)) {
            return parse_display_statement();
        }
        if (match(TokenType::LBRACE)) {
            return parse_block_statement();
        }

        return parse_expr_statement();
    } catch (const PhoenixException& err) {
        synchronize();
        return nullptr;
    }
}

ProgramAST Parser::parse_program() {
    std::vector<StmtPtr> statements;

    while (!is_at_end()) {
        StmtPtr stmt = parse_statement();
        if (stmt) {
            statements.push_back(std::move(stmt));
        }
    }

    return ProgramAST(std::move(statements));
}

ASTNodePtr Parser::parse_expression_or_statement() {
    if (is_at_end()) return nullptr;

    if (check(TokenType::KEYWORD_LET) || check(TokenType::KEYWORD_LIST) ||
        check(TokenType::KEYWORD_DICT) || check(TokenType::KEYWORD_DTYPE) ||
        check(TokenType::KEYWORD_STATE) || check(TokenType::KEYWORD_STATE_DTYPE) ||
        check(TokenType::KEYWORD_IF) || check(TokenType::KEYWORD_WHILE) ||
        check(TokenType::KEYWORD_FOR) || check(TokenType::KEYWORD_DEFINE) ||
        check(TokenType::KEYWORD_CLASS) || check(TokenType::KEYWORD_SYSTEM) ||
        check(TokenType::KEYWORD_DISPLAY) || check(TokenType::KEYWORD_MODE)) {
        return parse_statement();
    }

    return parse_expression();
}

} // namespace phoenix