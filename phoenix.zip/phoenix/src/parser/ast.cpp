#include "phoenix/parser/ast.hpp"

namespace phoenix {

void LiteralExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void IdentifierExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ListLiteralExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void DictLiteralExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void UnaryExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void BinaryExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void AssignExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void CallExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void NativeCallExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void MemberExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void IndexExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void TypeMapExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void TableKeyExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void PrimaryKeyQueryExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void InputExprAST::accept(ASTVisitor* visitor) { visitor->visit(this); }

void ExprStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void VarDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void BulkDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void DictSchemaAddColStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void DictStreamUpsertStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void AsmStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void BlockStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void IfStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void WhileStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ForStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ForeveryStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ReturnStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void BreakStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ContinueStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void FunctionDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ClassDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void SystemDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ModeDeclStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void ImportStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void AttemptStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }
void DisplayStmtAST::accept(ASTVisitor* visitor) { visitor->visit(this); }

} // namespace phoenix