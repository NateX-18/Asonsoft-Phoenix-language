#include "phoenix/lexer/lexer.hpp"
#include <cctype>
#include <cstdlib>

namespace phoenix {

char Lexer::advance() noexcept {
    current_++;
    column_++;
    return source_[current_ - 1];
}

char Lexer::peek() const noexcept {
    if (is_at_end()) return '\0';
    return source_[current_];
}

char Lexer::peek_next() const noexcept {
    if (current_ + 1 >= source_.size()) return '\0';
    return source_[current_ + 1];
}

bool Lexer::match(char expected) noexcept {
    if (is_at_end() || source_[current_] != expected) return false;
    current_++;
    column_++;
    return true;
}

Token Lexer::make_token(TokenType type) const {
    std::string text = source_.substr(start_, current_ - start_);
    return Token(type, text, SourceLocation{file_path_, line_, start_column_});
}

Token Lexer::make_token(TokenType type, Value literal) const {
    std::string text = source_.substr(start_, current_ - start_);
    return Token(type, text, std::move(literal), SourceLocation{file_path_, line_, start_column_});
}

Token Lexer::error_token(const std::string& message) {
    diagnostics_.report(ErrorCategory::LEXER, message, SourceLocation{file_path_, line_, start_column_});
    return Token(TokenType::TOKEN_ERROR, message, SourceLocation{file_path_, line_, start_column_});
}

void Lexer::skip_whitespace_and_comments() {
    while (!is_at_end()) {
        char c = peek();
        switch (c) {
            case ' ':
            case '\r':
            case '\t':
                advance();
                break;
            case '\n':
                line_++;
                column_ = 1;
                current_++;
                break;
            case '/':
                if (peek_next() == '/') {
                    while (peek() != '\n' && !is_at_end()) advance();
                } else if (peek_next() == '*') {
                    advance(); advance();
                    while (!is_at_end()) {
                        if (peek() == '*' && peek_next() == '/') {
                            advance(); advance();
                            break;
                        }
                        if (peek() == '\n') {
                            line_++; column_ = 1; current_++;
                        } else {
                            advance();
                        }
                    }
                } else {
                    return;
                }
                break;
            default:
                return;
        }
    }
}

Token Lexer::scan_string(char quote_type) {
    std::string value;

    while (peek() != quote_type && !is_at_end()) {
        if (peek() == '\n') {
            line_++; column_ = 1; current_++;
            value += '\n';
            continue;
        }
        if (peek() == '\\') {
            advance();
            if (is_at_end()) break;
            char escaped = advance();
            switch (escaped) {
                case 'n':  value += '\n'; break;
                case 't':  value += '\t'; break;
                case 'r':  value += '\r'; break;
                case '\\': value += '\\'; break;
                case '"':  value += '"';  break;
                case '\'': value += '\''; break;
                case '0':  value += '\0'; break;
                default:   value += escaped; break;
            }
        } else {
            value += advance();
        }
    }

    if (is_at_end()) return error_token("Unterminated string literal.");
    advance();

    return make_token(TokenType::STRING_LITERAL, Value::make_string(value));
}

Token Lexer::scan_number() {
    bool is_float = false;

    // Hexadecimal (0x...)
    if (source_[start_] == '0' && (peek() == 'x' || peek() == 'X')) {
        advance();
        while (std::isxdigit(static_cast<unsigned char>(peek()))) advance();
        std::string text = source_.substr(start_, current_ - start_);
        uint64_t val = std::strtoull(text.c_str(), nullptr, 16);
        return make_token(TokenType::INT_LITERAL, Value::make_u64(val));
    }

    // Binary (0b...)
    if (source_[start_] == '0' && (peek() == 'b' || peek() == 'B')) {
        advance();
        while (peek() == '0' || peek() == '1') advance();
        std::string text = source_.substr(start_ + 2, current_ - (start_ + 2));
        uint64_t val = std::strtoull(text.c_str(), nullptr, 2);
        return make_token(TokenType::INT_LITERAL, Value::make_u64(val));
    }

    // Octal (0o...)
    if (source_[start_] == '0' && (peek() == 'o' || peek() == 'O')) {
        advance();
        while (peek() >= '0' && peek() <= '7') advance();
        std::string text = source_.substr(start_ + 2, current_ - (start_ + 2));
        uint64_t val = std::strtoull(text.c_str(), nullptr, 8);
        return make_token(TokenType::INT_LITERAL, Value::make_u64(val));
    }

    while (std::isdigit(static_cast<unsigned char>(peek()))) advance();

    if (peek() == '.' && std::isdigit(static_cast<unsigned char>(peek_next()))) {
        is_float = true;
        advance();
        while (std::isdigit(static_cast<unsigned char>(peek()))) advance();
    }

    std::string text = source_.substr(start_, current_ - start_);

    if (is_float) {
        double val = std::strtod(text.c_str(), nullptr);
        return make_token(TokenType::FLOAT_LITERAL, Value::number(val));
    } else {
        int64_t val = std::strtoll(text.c_str(), nullptr, 10);
        return make_token(TokenType::INT_LITERAL, Value::make_i64(val));
    }
}

Token Lexer::scan_identifier() {
    while (std::isalnum(static_cast<unsigned char>(peek())) || peek() == '_' || peek() == '~' || peek() == '.') {
        if (peek() == '~' && peek_next() != 'd' && source_.substr(current_, 7) != "~dtype") {
            break;
        }
        if (peek() == '.' && source_.substr(start_, current_ - start_) != "struct") {
            break;
        }
        advance();
    }

    std::string_view text = std::string_view(source_).substr(start_, current_ - start_);
    TokenType type = lookup_keyword(text);

    return make_token(type);
}

Token Lexer::scan_token() {
    start_ = current_;
    start_column_ = column_;

    char c = advance();

    if (std::isalpha(static_cast<unsigned char>(c)) || c == '_') {
        return scan_identifier();
    }

    if (std::isdigit(static_cast<unsigned char>(c))) {
        return scan_number();
    }

    switch (c) {
        case '(': return make_token(TokenType::LPAREN);
        case ')': return make_token(TokenType::RPAREN);
        case '{': return make_token(TokenType::LBRACE);
        case '}': return make_token(TokenType::RBRACE);
        case '[': return make_token(TokenType::LBRACKET);
        case ']': return make_token(TokenType::RBRACKET);
        case ',': return make_token(TokenType::COMMA);
        case '.': return make_token(TokenType::DOT);
        case ':': return make_token(TokenType::COLON);
        case ';': return make_token(TokenType::SEMICOLON);
        case '$': return make_token(TokenType::DOLLAR);
        case '@': return make_token(TokenType::AT);

        case '+':
            return make_token(match('=') ? TokenType::PLUS_ASSIGN : TokenType::PLUS);
        case '-':
            return make_token(match('=') ? TokenType::MINUS_ASSIGN : TokenType::MINUS);
        case '*':
            if (match('$')) return make_token(TokenType::PRIMARY_KEY_QUERY);
            return make_token(match('=') ? TokenType::STAR_ASSIGN : TokenType::STAR);
        case '/':
            return make_token(match('=') ? TokenType::SLASH_ASSIGN : TokenType::SLASH);
        case '%':
            return make_token(TokenType::PERCENT);
        case '=':
            return make_token(match('=') ? TokenType::EQUAL : TokenType::ASSIGN);
        case '!':
            return make_token(match('=') ? TokenType::NOT_EQUAL : TokenType::BANG);

        case '~':
            if (match('>')) return make_token(TokenType::STREAM_RIGHT);
            return error_token("Unexpected character '~'. Did you mean '~>'?");

        case '&':
            if (match('&')) return make_token(TokenType::AND);
            return error_token("Unexpected single '&', expected '&&'.");
        case '|':
            if (match('|')) return make_token(TokenType::OR);
            return error_token("Unexpected single '|', expected '||'.");

        case '<':
            if (match('~')) {
                if (match('>')) {
                    return make_token(TokenType::TYPE_MAP); // <~> Universal Type Mapping
                }
                return make_token(TokenType::STREAM_LEFT);  // <~ Bulk Type Streaming
            }
            return make_token(match('=') ? TokenType::LESS_EQUAL : TokenType::LESS);

        case '>':
            return make_token(match('=') ? TokenType::GREATER_EQUAL : TokenType::GREATER);

        case '"':
        case '\'':
            return scan_string(c);

        default:
            return error_token(std::string("Unexpected character '") + c + "'.");
    }
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;

    while (!is_at_end()) {
        skip_whitespace_and_comments();
        if (is_at_end()) break;

        Token tok = scan_token();
        tokens.push_back(tok);

        if (tok.type == TokenType::TOKEN_ERROR) break;
    }

    tokens.push_back(Token(TokenType::TOKEN_EOF, "", SourceLocation{file_path_, line_, column_}));
    return tokens;
}

} // namespace phoenix