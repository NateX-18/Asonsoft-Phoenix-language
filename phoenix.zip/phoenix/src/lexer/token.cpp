#include "phoenix/lexer/token.hpp"
#include <unordered_map>
#include <sstream>

namespace phoenix {

std::string token_type_to_string(TokenType type) {
    switch (type) {
        case TokenType::TOKEN_EOF:          return "EOF";
        case TokenType::TOKEN_ERROR:        return "ERROR";
        case TokenType::IDENTIFIER:         return "IDENTIFIER";
        case TokenType::INT_LITERAL:        return "INT_LITERAL";
        case TokenType::FLOAT_LITERAL:      return "FLOAT_LITERAL";
        case TokenType::STRING_LITERAL:     return "STRING_LITERAL";

        case TokenType::KEYWORD_LET:         return "let";
        case TokenType::KEYWORD_LIST:        return "list";
        case TokenType::KEYWORD_DICT:        return "dict";
        case TokenType::KEYWORD_DEFINE:      return "define";
        case TokenType::KEYWORD_CLASS:       return "class";
        case TokenType::KEYWORD_EXTENDS:     return "extends";
        case TokenType::KEYWORD_SYSTEM:      return "system";
        case TokenType::KEYWORD_STRUCT:      return "struct";
        case TokenType::KEYWORD_MODE:        return "mode";
        case TokenType::KEYWORD_IMPORT:      return "import";
        case TokenType::KEYWORD_LOAD:        return "load";
        case TokenType::KEYWORD_RETURN:      return "return";
        case TokenType::KEYWORD_IF:          return "if";
        case TokenType::KEYWORD_ELIF:        return "elif";
        case TokenType::KEYWORD_ELSE:        return "else";
        case TokenType::KEYWORD_WHILE:       return "while";
        case TokenType::KEYWORD_FOR:         return "for";
        case TokenType::KEYWORD_FOREVERY:    return "forevery";
        case TokenType::KEYWORD_IN:          return "in";
        case TokenType::KEYWORD_BREAK:       return "break";
        case TokenType::KEYWORD_CONTINUE:    return "continue";
        case TokenType::KEYWORD_AND:         return "and";
        case TokenType::KEYWORD_OR:          return "or";
        case TokenType::KEYWORD_ATTEMPT:     return "attempt";
        case TokenType::KEYWORD_FAIL:        return "fail";
        case TokenType::KEYWORD_SUCCESS:     return "success";
        case TokenType::KEYWORD_ALWAYS:      return "always";
        case TokenType::KEYWORD_DISPLAY:     return "display";
        case TokenType::KEYWORD_INPUT:       return "input";
        case TokenType::KEYWORD_AS:          return "as";
        case TokenType::KEYWORD_NATIVE:      return "native";
        case TokenType::KEYWORD_NIL:         return "nil";
        case TokenType::KEYWORD_TRUE:        return "true";
        case TokenType::KEYWORD_FALSE:       return "false";
        case TokenType::KEYWORD_OPEN:        return "open";
        case TokenType::KEYWORD_WRITE:       return "write";
        case TokenType::KEYWORD_READ:        return "read";
        case TokenType::KEYWORD_READLN:      return "readln";
        case TokenType::KEYWORD_CLOSE:       return "close";
        case TokenType::KEYWORD_SEEK:        return "seek";
        case TokenType::KEYWORD_MKDIR:       return "mkdir";
        case TokenType::KEYWORD_COPY:        return "copy";
        case TokenType::KEYWORD_MOVE:        return "move";
        case TokenType::KEYWORD_DELETE:      return "delete";
        case TokenType::KEYWORD_DTYPE:       return "dtype";
        case TokenType::KEYWORD_STATE:       return "state";
        case TokenType::KEYWORD_STATE_DTYPE: return "state~dtype";
        case TokenType::KEYWORD_ASM:         return "asm";
        case TokenType::KEYWORD_VOLATILE:    return "volatile";
        case TokenType::KEYWORD_CONSTANT:    return "constant";

        case TokenType::PLUS:               return "+";
        case TokenType::MINUS:              return "-";
        case TokenType::STAR:               return "*";
        case TokenType::SLASH:              return "/";
        case TokenType::PERCENT:            return "%";
        case TokenType::ASSIGN:             return "=";
        case TokenType::EQUAL:              return "==";
        case TokenType::NOT_EQUAL:          return "!=";
        case TokenType::LESS:               return "<";
        case TokenType::LESS_EQUAL:         return "<=";
        case TokenType::GREATER:            return ">";
        case TokenType::GREATER_EQUAL:      return ">=";
        case TokenType::BANG:               return "!";
        case TokenType::AND:                return "&&";
        case TokenType::OR:                 return "||";
        case TokenType::PLUS_ASSIGN:        return "+=";
        case TokenType::MINUS_ASSIGN:       return "-=";
        case TokenType::STAR_ASSIGN:        return "*=";
        case TokenType::SLASH_ASSIGN:       return "/=";

        case TokenType::TYPE_MAP:           return "<~>";
        case TokenType::STREAM_RIGHT:       return "~>";
        case TokenType::STREAM_LEFT:        return "<~";
        case TokenType::DOLLAR:             return "$";
        case TokenType::PRIMARY_KEY_QUERY:  return "*$";
        case TokenType::AT:                 return "@";

        case TokenType::LPAREN:             return "(";
        case TokenType::RPAREN:             return ")";
        case TokenType::LBRACE:             return "{";
        case TokenType::RBRACE:             return "}";
        case TokenType::LBRACKET:           return "[";
        case TokenType::RBRACKET:           return "]";
        case TokenType::COMMA:              return ",";
        case TokenType::DOT:                return ".";
        case TokenType::COLON:              return ":";
        case TokenType::SEMICOLON:          return ";";
        default:                            return "<unknown>";
    }
}

TokenType lookup_keyword(std::string_view identifier) {
    static const std::unordered_map<std::string_view, TokenType> keywords = {
        {"let",         TokenType::KEYWORD_LET},
        {"list",        TokenType::KEYWORD_LIST},
        {"dict",        TokenType::KEYWORD_DICT},
        {"define",      TokenType::KEYWORD_DEFINE},
        {"class",       TokenType::KEYWORD_CLASS},
        {"extends",     TokenType::KEYWORD_EXTENDS},
        {"system",      TokenType::KEYWORD_SYSTEM},
        {"struct",      TokenType::KEYWORD_STRUCT},
        {"mode",        TokenType::KEYWORD_MODE},
        {"import",      TokenType::KEYWORD_IMPORT},
        {"load",        TokenType::KEYWORD_LOAD},
        {"return",      TokenType::KEYWORD_RETURN},
        {"if",          TokenType::KEYWORD_IF},
        {"elif",        TokenType::KEYWORD_ELIF},
        {"else",        TokenType::KEYWORD_ELSE},
        {"while",       TokenType::KEYWORD_WHILE},
        {"for",         TokenType::KEYWORD_FOR},
        {"forevery",    TokenType::KEYWORD_FOREVERY},
        {"in",          TokenType::KEYWORD_IN},
        {"break",       TokenType::KEYWORD_BREAK},
        {"continue",    TokenType::KEYWORD_CONTINUE},
        {"and",         TokenType::KEYWORD_AND},
        {"or",          TokenType::KEYWORD_OR},
        {"attempt",     TokenType::KEYWORD_ATTEMPT},
        {"fail",        TokenType::KEYWORD_FAIL},
        {"success",     TokenType::KEYWORD_SUCCESS},
        {"always",      TokenType::KEYWORD_ALWAYS},
        {"display",     TokenType::KEYWORD_DISPLAY},
        {"input",       TokenType::KEYWORD_INPUT},
        {"as",          TokenType::KEYWORD_AS},
        {"native",      TokenType::KEYWORD_NATIVE},
        {"nil",         TokenType::KEYWORD_NIL},
        {"true",        TokenType::KEYWORD_TRUE},
        {"false",       TokenType::KEYWORD_FALSE},
        {"open",        TokenType::KEYWORD_OPEN},
        {"write",       TokenType::KEYWORD_WRITE},
        {"read",        TokenType::KEYWORD_READ},
        {"readln",      TokenType::KEYWORD_READLN},
        {"close",       TokenType::KEYWORD_CLOSE},
        {"seek",        TokenType::KEYWORD_SEEK},
        {"mkdir",       TokenType::KEYWORD_MKDIR},
        {"copy",        TokenType::KEYWORD_COPY},
        {"move",        TokenType::KEYWORD_MOVE},
        {"delete",      TokenType::KEYWORD_DELETE},
        {"dtype",       TokenType::KEYWORD_DTYPE},
        {"state",       TokenType::KEYWORD_STATE},
        {"state~dtype", TokenType::KEYWORD_STATE_DTYPE},
        {"asm",         TokenType::KEYWORD_ASM},
        {"volatile",    TokenType::KEYWORD_VOLATILE},
        {"constant",    TokenType::KEYWORD_CONSTANT}
    };

    auto it = keywords.find(identifier);
    if (it != keywords.end()) {
        return it->second;
    }
    return TokenType::IDENTIFIER;
}

std::string Token::to_string() const {
    std::ostringstream ss;
    ss << "Token(" << token_type_to_string(type) << ", '" << lexeme << "'";
    if (type == TokenType::INT_LITERAL || type == TokenType::FLOAT_LITERAL || type == TokenType::STRING_LITERAL) {
        ss << ", literal=" << literal.to_string();
    }
    ss << " [" << location.to_string() << "])";
    return ss.str();
}

} // namespace phoenix