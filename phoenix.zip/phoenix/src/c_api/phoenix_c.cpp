#include "phoenix/c_api/phoenix_c.h"
#include "phoenix/common/types.hpp"
#include "phoenix/lexer/lexer.hpp"
#include "phoenix/parser/parser.hpp"
#include "phoenix/compiler/compiler.hpp"
#include "phoenix/vm/vm.hpp"
#include <cstdlib>
#include <cstring>
#include <vector>
#include <fstream>

struct PhxValue {
    phoenix::Value internal_val;
    std::string cached_str;
};

extern "C" {

PhxValue* phx_value_nil(void) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::nil();
    return v;
}

PhxValue* phx_value_bool(bool val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::boolean(val);
    return v;
}

PhxValue* phx_value_number(double val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::number(val);
    return v;
}

PhxValue* phx_value_i32(int32_t val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::make_i32(val);
    return v;
}

PhxValue* phx_value_i64(int64_t val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::make_i64(val);
    return v;
}

PhxValue* phx_value_u32(uint32_t val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::make_u32(val);
    return v;
}

PhxValue* phx_value_u64(uint64_t val) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::make_u64(val);
    return v;
}

PhxValue* phx_value_string(const char* str) {
    auto* v = new PhxValue();
    v->internal_val = phoenix::Value::make_string(str ? str : "");
    return v;
}

void phx_value_free(PhxValue* val) {
    delete val;
}

PhxValueType phx_value_get_type(const PhxValue* val) {
    if (!val) return PHX_TYPE_NIL;
    switch (val->internal_val.type) {
        case phoenix::ValueType::NIL: return PHX_TYPE_NIL;
        case phoenix::ValueType::BOOLEAN: return PHX_TYPE_BOOL;
        case phoenix::ValueType::NUMBER: return PHX_TYPE_NUMBER;
        case phoenix::ValueType::I8: return PHX_TYPE_I8;
        case phoenix::ValueType::I16: return PHX_TYPE_I16;
        case phoenix::ValueType::I32: return PHX_TYPE_I32;
        case phoenix::ValueType::I64: return PHX_TYPE_I64;
        case phoenix::ValueType::U8: return PHX_TYPE_U8;
        case phoenix::ValueType::U16: return PHX_TYPE_U16;
        case phoenix::ValueType::U32: return PHX_TYPE_U32;
        case phoenix::ValueType::U64: return PHX_TYPE_U64;
        case phoenix::ValueType::STRING: return PHX_TYPE_STRING;
        case phoenix::ValueType::LIST: return PHX_TYPE_LIST;
        case phoenix::ValueType::DICT: return PHX_TYPE_DICT;
        default: return PHX_TYPE_POINTER;
    }
}

bool phx_value_to_bool(const PhxValue* val) {
    return val ? val->internal_val.is_truthy() : false;
}

double phx_value_to_number(const PhxValue* val) {
    return val ? val->internal_val.as_number() : 0.0;
}

int64_t phx_value_to_i64(const PhxValue* val) {
    return val ? val->internal_val.as_i64() : 0;
}

uint64_t phx_value_to_u64(const PhxValue* val) {
    return val ? val->internal_val.as_u64() : 0;
}

const char* phx_value_to_string(const PhxValue* val) {
    if (!val) return "";
    const_cast<PhxValue*>(val)->cached_str = val->internal_val.to_string();
    return val->cached_str.c_str();
}

PhxVM* phx_vm_create(void) {
    static phoenix::DiagnosticEngine default_diagnostics;
    auto* internal_vm = new phoenix::VM(default_diagnostics);
    return reinterpret_cast<PhxVM*>(internal_vm);
}

void phx_vm_destroy(PhxVM* vm) {
    if (!vm) return;
    delete reinterpret_cast<phoenix::VM*>(vm);
}

bool phx_vm_eval_string(PhxVM* vm, const char* code) {
    if (!vm || !code) return false;
    auto* internal_vm = reinterpret_cast<phoenix::VM*>(vm);
    phoenix::DiagnosticEngine diag;
    phoenix::Lexer lexer(code, diag, "<eval>");
    phoenix::Parser parser(lexer.tokenize(), diag);
    phoenix::Compiler compiler(diag);
    auto chunk = compiler.compile(parser.parse_program());
    return internal_vm->interpret(chunk) == phoenix::InterpretResult::OK;
}

bool phx_vm_run_file(PhxVM* vm, const char* filepath) {
    if (!vm || !filepath) return false;
    std::ifstream file(filepath);
    if (!file.is_open()) return false;
    std::string source((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    return phx_vm_eval_string(vm, source.c_str());
}

void phx_register_native_function(PhxVM* vm, const char* module_name, const char* function_name, PhxNativeFunc fn) {
    if (!vm || !module_name || !function_name || !fn) return;

    auto* internal_vm = reinterpret_cast<phoenix::VM*>(vm);
    std::string mod_str = module_name;
    std::string fn_str = function_name;

    internal_vm->register_native_module(mod_str, fn_str, [fn](const std::vector<phoenix::Value>& args, phoenix::VM& vm_ref) -> phoenix::Value {
        std::vector<PhxValue> wrapped_args(args.size());
        std::vector<PhxValue*> c_args(args.size());

        for (size_t i = 0; i < args.size(); ++i) {
            wrapped_args[i].internal_val = args[i];
            c_args[i] = &wrapped_args[i];
        }

        PhxVM* c_vm = reinterpret_cast<PhxVM*>(&vm_ref);
        PhxValue* ret = fn(c_vm, static_cast<int>(args.size()), c_args.data());

        if (!ret) return phoenix::Value::nil();

        phoenix::Value result = ret->internal_val;
        delete ret;
        return result;
    });
}

} // extern "C"