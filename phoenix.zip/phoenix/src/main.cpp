 
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#if defined(_WIN32)
#  include <windows.h>
#else
#  include <unistd.h>
#  include <limits.h>
#endif

// Phoenix Engine Internal Public Headers
#include "phoenix/common/config.hpp"
#include "phoenix/common/error.hpp"
#include "phoenix/common/types.hpp"
#include "phoenix/lexer/lexer.hpp"
#include "phoenix/parser/parser.hpp"
#include "phoenix/compiler/compiler.hpp"
#include "phoenix/vm/vm.hpp"
#include "phoenix/linker/linker.hpp"
#include "phoenix/linker/verifier.hpp"
#include "phoenix/pmi/pmi.hpp"

namespace phx = phoenix;

static void print_version() {
    std::cout << "Asonsoft Phoenix Language Native Engine\n";
    std::cout << "Version: " << phx::PHX_VERSION_MAJOR << "." << static_cast<int>(phx::PHX_VERSION_MINOR) << "." << static_cast<int>(phx::PHX_VERSION_PATCH) << "\n";
    std::cout << "Vendor: " << phx::PHX_VENDOR << "\n";
    std::cout << "Motto: \"" << phx::PHX_MOTTO << "\"\n";
    std::cout << "Target ABI: " << phx::PHX_TARGET_ABI << " (" << phx::PHX_BUILD_CONFIG << ")\n";
}
 
static void print_usage(const char* exec_name) {
    std::cout << "Usage: " << exec_name << " [command] [options] <file>\n\n";
    std::cout << "Commands:\n";
    std::cout << "  (no args)             Launch interactive REPL developer console with multiline brace support\n";
    std::cout << "  run <file>            Execute a script (.phx), compiled binary (.pxc), or package (.pxe)\n";
    std::cout << "  compile <file>        Compile source script (.phx) into object payload (.pxc)\n";
    std::cout << "  check <file>          Run syntax validator & static linter on script (.phx)\n";
    std::cout << "  verify <file>         Validate integrity and cryptographic signature of (.pxe)\n";
    std::cout << "  --lk-pxe <in> <out>   Assemble and link standalone executable package (.pxe)\n";
    std::cout << "  pmi <cmd> [args]      Phoenix Package Manager (init/pack/install/list/...)\n";
    std::cout << "  -v, --version         Display Phoenix engine build & version information\n";
    std::cout << "  -h, --help            Display this help message\n\n";
}

static void run_repl() {
    std::cout << "Phoenix " << phx::PHX_VERSION_STRING << " Interactive REPL [" << phx::PHX_BUILD_CONFIG << "]\n";
    std::cout << "Type 'exit()' or press Ctrl+C to terminate session. Supports multiline blocks ({...})\n";
    std::cout << "---------------------------------------------------------------------\n";

    phx::DiagnosticEngine diagnostics;
    phx::VM vm(diagnostics);

    // Retain every compiled chunk for the lifetime of the REPL session.
    // Function bodies are stored as raw pointers inside Values; the owning
    // shared_ptr must stay alive or later calls become use-after-free.
    std::vector<std::shared_ptr<phx::Chunk>> retained_chunks;

    std::string accumulated_code;
    int brace_depth = 0;
    size_t line_number = 1;

    while (true) {
        std::string prompt = (brace_depth == 0) ? ("phx:" + std::to_string(line_number) + "> ") : "... ";
        std::cout << prompt;
        std::cout.flush();

        std::string line;
        if (!std::getline(std::cin, line)) {
            std::cout << "\nExiting REPL.\n";
            break;
        }

        if (brace_depth == 0) {
            if (line == "exit()" || line == "quit()" || line == ".exit") {
                break;
            }
            if (line == ".clear") {
                accumulated_code.clear();
                brace_depth = 0;
                continue;
            }
        }

        // Track multiline brace depth
        for (char c : line) {
            if (c == '{') brace_depth++;
            else if (c == '}') {
                if (brace_depth > 0) brace_depth--;
            }
        }

        accumulated_code += line + "\n";

        if (brace_depth > 0) {
            continue; // Keep accumulating multiline input
        }

        std::string source = accumulated_code;
        accumulated_code.clear();
        line_number++;

        if (source.find_first_not_of(" \t\n\r") == std::string::npos) {
            continue;
        }

        try {
            diagnostics.clear();

            phx::Lexer lexer(source, diagnostics, "<repl>");
            auto tokens = lexer.tokenize();

            if (diagnostics.has_errors()) continue;

            phx::Parser parser(tokens, diagnostics);
            auto program = parser.parse_program();

            if (parser.has_errors() || diagnostics.has_errors()) continue;

            phx::Compiler compiler(diagnostics);
            auto chunk = compiler.compile(program);

            if (diagnostics.has_errors()) continue;

            // Keep chunk (and all nested function chunks) alive for the session
            retained_chunks.push_back(chunk);

            vm.interpret(chunk);

        } catch (const phx::PhoenixException& err) {
            std::cerr << "Engine Error: " << err.what() << "\n";
        } catch (const std::exception& e) {
            std::cerr << "Engine Exception: " << e.what() << "\n";
        }
    }
}

static std::string read_file_contents(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::in | std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file: " + filepath);
    }
    std::ostringstream contents;
    contents << file.rdbuf();
    return contents.str();
}

static int execute_run(const std::string& filepath) {
    std::filesystem::path path(filepath);
    std::string ext = path.extension().string();

    try {
        phx::DiagnosticEngine diagnostics;
        phx::VM vm(diagnostics);

        if (ext == ".phx") {
            std::string source = read_file_contents(filepath);

            phx::Lexer lexer(source, diagnostics, filepath);
            auto tokens = lexer.tokenize();

            phx::Parser parser(tokens, diagnostics);
            auto program = parser.parse_program();

            if (parser.has_errors() || diagnostics.has_errors()) return EXIT_FAILURE;

            phx::Compiler compiler(diagnostics);
            auto chunk = compiler.compile(program);

            if (diagnostics.has_errors()) return EXIT_FAILURE;

            if (chunk) {
                chunk->source_name = filepath;
                for (auto& d : chunk->debug_lines) d.file_path = filepath;
                for (auto& child : chunk->child_chunks) {
                    if (!child) continue;
                    child->source_name = filepath;
                    for (auto& d : child->debug_lines) d.file_path = filepath;
                }
            }

            vm.interpret(chunk);
        } else if (ext == ".pxc" || ext == ".pxe") {
            phx::Linker linker(diagnostics);
            auto chunk = linker.load_pxc(filepath);
            if (!chunk || diagnostics.has_errors()) {
                std::cerr << "Failed to load binary object: " << filepath << "\n";
                return EXIT_FAILURE;
            }
            vm.interpret(chunk);
        } else {
            std::cerr << "Error: Unrecognized Phoenix file extension '" << ext << "'.\n";
            return EXIT_FAILURE;
        }
    } catch (const phx::PhoenixException& err) {
        std::cerr << "Engine Error: " << err.what() << "\n";
        return EXIT_FAILURE;
    } catch (const std::exception& e) {
        std::cerr << "Fatal Engine Error: " << e.what() << "\n";
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

static int execute_compile(const std::string& input_file) {
    try {
        std::filesystem::path in_path(input_file);
        std::filesystem::path out_path = in_path;
        out_path.replace_extension(".pxc");

        std::string source = read_file_contents(input_file);

        phx::DiagnosticEngine diagnostics;
        phx::Lexer lexer(source, diagnostics, input_file);
        auto tokens = lexer.tokenize();

        phx::Parser parser(tokens, diagnostics);
        auto program = parser.parse_program();

        if (parser.has_errors() || diagnostics.has_errors()) return EXIT_FAILURE;

        phx::Compiler compiler(diagnostics);
        auto chunk = compiler.compile(program);

        if (diagnostics.has_errors()) return EXIT_FAILURE;

        if (chunk) {
            chunk->source_name = input_file;
            for (auto& d : chunk->debug_lines) d.file_path = input_file;
            for (auto& child : chunk->child_chunks) {
                if (!child) continue;
                child->source_name = input_file;
                for (auto& d : child->debug_lines) d.file_path = input_file;
            }
        }

        phx::Linker linker(diagnostics);
        if (linker.link_pxc(chunk, out_path.string())) {
            std::cout << "Compilation succeeded: " << out_path.string() << "\n";
            return EXIT_SUCCESS;
        }
        return EXIT_FAILURE;
    } catch (const std::exception& e) {
        std::cerr << "Compilation Error: " << e.what() << "\n";
        return EXIT_FAILURE;
    }
}

static int execute_check(const std::string& input_file) {
    try {
        std::string source = read_file_contents(input_file);
        phx::DiagnosticEngine diagnostics;
        phx::Lexer lexer(source, diagnostics, input_file);
        auto tokens = lexer.tokenize();

        phx::Parser parser(tokens, diagnostics);
        auto program = parser.parse_program();

        if (parser.has_errors() || diagnostics.has_errors()) return EXIT_FAILURE;

        std::cout << "Syntax check passed: " << input_file << " is valid Phoenix source.\n";
        return EXIT_SUCCESS;
    } catch (const std::exception& e) {
        std::cerr << "Syntax Error: " << e.what() << "\n";
        return EXIT_FAILURE;
    }
}

static int execute_linker(const std::string& mode, const std::string& input_file, const std::string& output_file) {
    try {
        phx::DiagnosticEngine diagnostics;
        phx::Linker linker(diagnostics);

        if (mode == "--lk-pxe") {
            auto chunk = linker.load_pxc(input_file);
            if (!chunk || !linker.link_pxe(chunk, output_file, "./phx_runtime")) {
                return EXIT_FAILURE;
            }
        } else {
            return EXIT_FAILURE;
        }
        std::cout << "Linking completed successfully: " << output_file << "\n";
        return EXIT_SUCCESS;
    } catch (const std::exception& e) {
        std::cerr << "Linker Error: " << e.what() << "\n";
        return EXIT_FAILURE;
    }
}

static int execute_verify(const std::string& package_file) {
    phx::DiagnosticEngine diagnostics;
    phx::Verifier verifier(diagnostics);

    std::ifstream in(package_file, std::ios::binary);
    if (!in.is_open()) return EXIT_FAILURE;
    std::vector<uint8_t> buffer((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());

    if (verifier.validate_header(buffer)) {
        std::cout << "Package Signature OK: " << package_file << "\n";
        return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}


// ---- Embedded PHXPAYLD footer (packager stub + .pxc payload) ----
#pragma pack(push, 1)
struct PhxPayloadFooter {
    char     magic[8];   // "PHXPAYLD"
    uint32_t version;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
    uint32_t crc32;
    uint32_t reserved;
};
#pragma pack(pop)

static uint32_t phx_crc32(const uint8_t* data, size_t len) {
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int b = 0; b < 8; ++b) {
            uint32_t mask = -(crc & 1u);
            crc = (crc >> 1) ^ (0xEDB88320u & mask);
        }
    }
    return ~crc;
}

static std::string get_self_path(const char* argv0) {
#if defined(_WIN32)
    char buf[MAX_PATH];
    DWORD n = GetModuleFileNameA(nullptr, buf, MAX_PATH);
    if (n > 0 && n < MAX_PATH) return std::string(buf, n);
#else
    char buf[PATH_MAX];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n > 0) {
        buf[n] = '\0';
        return std::string(buf);
    }
#endif
    return argv0 ? std::string(argv0) : std::string();
}

// Returns EXIT_* if payload was found and executed; -1 if no payload (continue normal CLI).
static int try_run_embedded_payload(const char* argv0) {
    std::string self = get_self_path(argv0);
    if (self.empty()) return -1;

    std::ifstream in(self, std::ios::binary);
    if (!in) return -1;
    std::vector<uint8_t> file((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    in.close();

    if (file.size() < sizeof(PhxPayloadFooter) + 8) return -1;

    PhxPayloadFooter foot{};
    std::memcpy(&foot, file.data() + file.size() - sizeof(PhxPayloadFooter), sizeof(foot));
    if (std::memcmp(foot.magic, "PHXPAYLD", 8) != 0) return -1;
    if (foot.version != 1) return -1;
    if (foot.offset + foot.size + sizeof(PhxPayloadFooter) > file.size()) return -1;

    const uint8_t* payload = file.data() + static_cast<size_t>(foot.offset);
    size_t psz = static_cast<size_t>(foot.size);
    if (phx_crc32(payload, psz) != foot.crc32) {
        std::cerr << "[Phoenix] Embedded payload CRC mismatch.\n";
        return EXIT_FAILURE;
    }

    std::vector<uint8_t> pxc(payload, payload + psz);
    // Must look like a PXC header (PHX...)
    if (pxc.size() < 8 || pxc[0] != 0x50 || pxc[1] != 0x48 || pxc[2] != 0x58) {
        std::cerr << "[Phoenix] Embedded payload is not a valid .pxc.\n";
        return EXIT_FAILURE;
    }

    phx::DiagnosticEngine diagnostics;
    phx::Linker linker(diagnostics);
    auto chunk = linker.load_pxc_from_memory(pxc);
    if (!chunk) {
        std::cerr << "[Phoenix] Failed to load embedded .pxc payload.\n";
        return EXIT_FAILURE;
    }

    phx::VM vm(diagnostics);
    auto result = vm.interpret(chunk);
    return (result == phx::InterpretResult::OK) ? EXIT_SUCCESS : EXIT_FAILURE;
}


int main(int argc, char* argv[]) {
    // If this binary was packaged with @packager.pxc_to_exe, run the embedded
    // .pxc and exit — do not open the REPL or require CLI args.
    {
        int embedded = try_run_embedded_payload(argc > 0 ? argv[0] : nullptr);
        if (embedded >= 0) return embedded;
    }

    if (argc < 2) {
        run_repl();
        return EXIT_SUCCESS;
    }

    std::string arg1 = argv[1];

    if (arg1 == "-v" || arg1 == "--version") {
        print_version();
        return EXIT_SUCCESS;
    }
    if (arg1 == "-h" || arg1 == "--help") {
        print_usage(argv[0]);
        return EXIT_SUCCESS;
    }

    // CLI Parameter Bounds Guard fixing Defect #15
    if (arg1 == "run") {
        if (argc < 3) { std::cerr << "Error: Missing input file argument for 'run'.\n"; return EXIT_FAILURE; }
        return execute_run(argv[2]);
    }
    if (arg1 == "compile") {
        if (argc < 3) { std::cerr << "Error: Missing input file argument for 'compile'.\n"; return EXIT_FAILURE; }
        return execute_compile(argv[2]);
    }
    if (arg1 == "check") {
        if (argc < 3) { std::cerr << "Error: Missing input file argument for 'check'.\n"; return EXIT_FAILURE; }
        return execute_check(argv[2]);
    }
    if (arg1 == "verify") {
        if (argc < 3) { std::cerr << "Error: Missing package argument for 'verify'.\n"; return EXIT_FAILURE; }
        return execute_verify(argv[2]);
    }
    if (arg1 == "--lk-pxe") {
        if (argc < 4) { std::cerr << "Error: Missing input and output file arguments for '--lk-pxe'.\n"; return EXIT_FAILURE; }
        return execute_linker(arg1, argv[2], argv[3]);
    }

    if (arg1 == "pmi") {
        phx::DiagnosticEngine diagnostics;
        phx::PMI pmi(diagnostics);
        if (argc < 3) {
            std::cerr << "Usage: phx pmi <init|pack|install|remove|list|info|publish> [args]\n";
            return EXIT_FAILURE;
        }
        std::string sub = argv[2];
        if (sub == "init" && argc >= 4) return pmi.init_package(argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "pack" && argc >= 5) return pmi.pack_package(argv[3], argv[4]) ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "install" && argc >= 4) return pmi.install_package(argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "remove" && argc >= 4) return pmi.remove_package(argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "list") return pmi.list_installed() ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "info" && argc >= 4) return pmi.fetch_info(argv[3]) ? EXIT_SUCCESS : EXIT_FAILURE;
        if (sub == "publish" && argc >= 5) return pmi.publish_package(argv[3], argv[4]) ? EXIT_SUCCESS : EXIT_FAILURE;
        std::cerr << "Unknown or incomplete pmi command. Try: phx pmi init mypkg\n";
        return EXIT_FAILURE;
    }

    return execute_run(arg1);
}

