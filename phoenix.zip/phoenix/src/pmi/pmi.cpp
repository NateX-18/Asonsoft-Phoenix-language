
#include "phoenix/pmi/pmi.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <filesystem>
#include <algorithm>

namespace fs = std::filesystem;

#ifndef SERVER_URL
#define SERVER_URL "http://localhost"
#endif

namespace phoenix {


std::string PMI::sanitize_path_param(const std::string& param) {
    // Defense against command injection and path traversal (Defects #10 & #11)
    std::string clean = param;
    clean.erase(std::remove_if(clean.begin(), clean.end(), [](char c) {
        return c == ';' || c == '&' || c == '|' || c == '`' || c == '$' || c == '"' || c == '\'';
    }), clean.end());
    return clean;
}

bool PMI::init_package(const std::string& raw_package_name) {
    std::string package_name = sanitize_path_param(raw_package_name);
    std::string dir = "./" + package_name;
    if (!fs::exists(dir)) {
        fs::create_directories(dir);
    }

    std::string manifest_path = dir + "/package.json";
    if (fs::exists(manifest_path)) {
        std::cout << "[PMI] package.json already exists in " << dir << std::endl;
        return true;
    }

    std::ofstream out(manifest_path);
    if (!out.is_open()) {
        m_diagnostics.report(ErrorCategory::PMI, "Failed to create package.json in " + dir, SourceLocation{"<pmi>", 0, 0});
        return false;
    }

    out << "{\n"
        << "  \"name\": \"" << package_name << "\",\n"
        << "  \"version\": \"1.0.0\",\n"
        << "  \"description\": \"Native Phoenix extension module\",\n"
        << "  \"author\": \"Developer\",\n"
        << "  \"entry_point\": \"" << package_name << ".so\",\n"
        << "  \"dependencies\": []\n"
        << "}\n";

    out.close();

    // Scaffold a native module .cpp the user can fill in
    std::string cpp_path = dir + "/" + package_name + "_mod.cpp";
    if (!fs::exists(cpp_path)) {
        std::ofstream cpp(cpp_path);
        cpp << "// Native Phoenix module: " << package_name << "\n"
            << "// Build: clang++ -shared -fPIC -std=c++20 -I<path/to/phoenix/include> \\\n"
            << "//          " << package_name << "_mod.cpp -o " << package_name << ".so\\n"
            << "// Install: place " << package_name << ".so under ./epkg/" << package_name << "/\\n\n"
            << "#include \"phoenix/vm/vm.hpp\"\n"
            << "#include \"phoenix/common/types.hpp\"\n\n"
            << "using namespace phoenix;\n\n"
            << "extern \"C\" void phoenix_module_init(VM* vm) {\n"
            << "    if (!vm) return;\n\n"
            << "    vm->register_native_module(\"" << package_name << "\", \"hello\",\n"
            << "        [](const std::vector<Value>& args, VM&) {\n"
            << "            std::string name = args.empty() ? \"world\" : args[0].to_string();\n"
            << "            return Value::make_string(\"Hello, \" + name + \"!\");\n"
            << "        });\n"
            << "}\n";
        cpp.close();
        std::cout << "[PMI] Wrote scaffold " << cpp_path << std::endl;
    }

    // README
    std::string readme = dir + "/README.md";
    if (!fs::exists(readme)) {
        std::ofstream r(readme);
        r << "# " << package_name << "\n\n"
          << "Phoenix native extension module.\n\n"
          << "## Build\n\n"
          << "```bash\n"
          << "clang++ -shared -fPIC -std=c++20 -I../include " << package_name << "_mod.cpp -o " << package_name << ".so\n"
          << "```\n\n"
          << "## Install\n\n"
          << "```bash\n"
          << "pmi pack " << package_name << " " << package_name << ".epkg\n"
          << "pmi install " << package_name << ".epkg\n"
          << "```\n\n"
          << "## Use in Phoenix\n\n"
          << "```phx\n"
          << "display(@" << package_name << ".hello(\"Nat\"))\n"
          << "```\n";
        r.close();
    }

    std::cout << "[PMI] Initialized module template in " << dir << std::endl;
    return true;
}

bool PMI::pack_package(const std::string& raw_source_dir, const std::string& raw_output_epkg) {
    std::string source_dir = sanitize_path_param(raw_source_dir);
    std::string output_epkg = sanitize_path_param(raw_output_epkg);

    if (!fs::exists(source_dir + "/package.json")) {
        m_diagnostics.report(ErrorCategory::PMI, "Missing package.json in " + source_dir, SourceLocation{"<pmi>", 0, 0});
        return false;
    }

    std::cout << "[PMI] Packaging " << source_dir << " -> " << output_epkg << "..." << std::endl;
    return zip_directory(source_dir, output_epkg);
}

bool PMI::publish_package(const std::string& raw_epkg_file, const std::string& api_token) {
    std::string epkg_file = sanitize_path_param(raw_epkg_file);
    if (!fs::exists(epkg_file)) {
        m_diagnostics.report(ErrorCategory::PMI, "Package file " + epkg_file + " does not exist.", SourceLocation{"<pmi>", 0, 0});
        return false;
    }

    std::string upload_endpoint = std::string(SERVER_URL) + "/upload";
    std::cout << "[PMI] Uploading " << epkg_file << " to " << upload_endpoint << "..." << std::endl;

    if (http_upload(upload_endpoint, epkg_file, api_token)) {
        std::cout << "[PMI] Successfully published " << epkg_file << " to registry!" << std::endl;
        return true;
    } else {
        m_diagnostics.report(ErrorCategory::PMI, "Failed to upload package to PMI server.", SourceLocation{"<pmi>", 0, 0});
        return false;
    }
}

bool PMI::install_package(const std::string& raw_package_name) {
    std::string package_name = sanitize_path_param(raw_package_name);
    std::string download_url = std::string(SERVER_URL) + "/download?pkg=" + package_name;
    std::string temp_epkg = "./" + package_name + ".epkg";
    std::string target_dir = "./epkg/" + package_name;

    std::cout << "[PMI] Downloading " << package_name << " from " << download_url << "..." << std::endl;

    if (!http_download(download_url, temp_epkg)) {
        m_diagnostics.report(ErrorCategory::PMI, "Failed to download package '" + package_name + "' from PMI registry.", SourceLocation{"<pmi>", 0, 0});
        return false;
    }

    if (!fs::exists("./epkg")) {
        fs::create_directory("./epkg");
    }

    std::cout << "[PMI] Extracting package into " << target_dir << "..." << std::endl;
    bool status = unzip_epkg(temp_epkg, target_dir);

    // Clean up temporary archive
    if (fs::exists(temp_epkg)) {
        fs::remove(temp_epkg);
    }

    if (status) {
        std::cout << "[PMI] Package '" << package_name << "' installed successfully." << std::endl;
    }
    return status;
}

bool PMI::remove_package(const std::string& raw_package_name) {
    std::string package_name = sanitize_path_param(raw_package_name);
    // Hardened Path Traversal Shield fixing Defect #11
    std::string target_dir = "./epkg/" + package_name;
    
    fs::path target_path(target_dir);
    if (target_path.lexically_normal().string().find("..") != std::string::npos) {
        m_diagnostics.report(ErrorCategory::PMI, "Security Violation: Directory traversal detected in package removal parameter.", SourceLocation{"<pmi>", 0, 0});
        return false;
    }

    if (fs::exists(target_dir)) {
        fs::remove_all(target_dir);
        std::cout << "[PMI] Uninstalled package '" << package_name << "'." << std::endl;
        return true;
    }
    std::cout << "[PMI] Package '" << package_name << "' is not installed in ./epkg/" << std::endl;
    return false;
}

bool PMI::list_installed() {
    std::string epkg_dir = "./epkg";
    if (!fs::exists(epkg_dir) || !fs::is_directory(epkg_dir)) {
        std::cout << "[PMI] No external packages currently installed in ./epkg/" << std::endl;
        return true;
    }

    std::cout << "=== Installed PMI Modules (./epkg/) ===" << std::endl;
    for (const auto& entry : fs::directory_iterator(epkg_dir)) {
        if (entry.is_directory()) {
            std::cout << " - " << entry.path().filename().string() << std::endl;
        }
    }
    return true;
}

bool PMI::fetch_info(const std::string& raw_package_name) {
    std::string package_name = sanitize_path_param(raw_package_name);
    std::string info_url = std::string(SERVER_URL) + "/info?pkg=" + package_name;
    std::cout << "[PMI] Querying server info for '" << package_name << "' from " << info_url << "..." << std::endl;
    
    std::string cmd = "curl -s \"" + info_url + "\"";
    int ret = ::system(cmd.c_str());
    return (ret == 0);
}

bool PMI::unzip_epkg(const std::string& epkg_path, const std::string& target_dir) {
    fs::create_directories(target_dir);

    std::ifstream in(epkg_path, std::ios::binary);
    if (!in) return false;
    char magic[4] = {};
    in.read(magic, 4);
    if (std::string(magic, 4) == "EPKG") {
        uint32_t ver = 0, count = 0;
        in.read(reinterpret_cast<char*>(&ver), 4);
        in.read(reinterpret_cast<char*>(&count), 4);
        for (uint32_t i = 0; i < count; ++i) {
            uint32_t nlen = 0, dlen = 0;
            in.read(reinterpret_cast<char*>(&nlen), 4);
            std::string name(nlen, '\0');
            in.read(name.data(), nlen);
            in.read(reinterpret_cast<char*>(&dlen), 4);
            std::vector<char> data(dlen);
            if (dlen) in.read(data.data(), dlen);
            fs::path out_path = fs::path(target_dir) / name;
            fs::create_directories(out_path.parent_path());
            std::ofstream out(out_path, std::ios::binary);
            if (dlen) out.write(data.data(), dlen);
        }
        return true;
    }
    in.close();

    // Fall back to system unzip for classic zip archives
#if defined(_WIN32)
    std::string cmd = "powershell -Command \"Expand-Archive -Path '" + epkg_path + "' -DestinationPath '" + target_dir + "' -Force\"";
#else
    std::string cmd = "unzip -q -o \"" + epkg_path + "\" -d \"" + target_dir + "\"";
#endif
    return (::system(cmd.c_str()) == 0);
}


bool PMI::zip_directory(const std::string& source_dir, const std::string& output_epkg) {
    // Try system zip first when available
#if !defined(_WIN32)
    if (::system("command -v zip >/dev/null 2>&1") == 0) {
        std::string abs_out = fs::absolute(output_epkg).string();
        std::string cmd = "cd \"" + source_dir + "\" && zip -q -r \"" + abs_out + "\" .";
        if (::system(cmd.c_str()) == 0) {
            std::cout << "[PMI] Packed with system zip -> " << output_epkg << std::endl;
            return true;
        }
    }
#else
    {
        std::string cmd = "powershell -Command \"Compress-Archive -Path '" + source_dir +
            "/*' -DestinationPath '" + output_epkg + "' -Force\"";
        if (::system(cmd.c_str()) == 0) return true;
    }
#endif

    // Portable EPKG v1 writer (no external tools — works on Android/Cxxdroid)
    // magic "EPKG" + version u32 + file_count u32
    // each: name_len u32 + name + data_len u32 + data
    std::vector<std::pair<std::string, std::vector<char>>> files;
    try {
        for (auto& entry : fs::recursive_directory_iterator(source_dir)) {
            if (!entry.is_regular_file()) continue;
            std::string rel = fs::relative(entry.path(), source_dir).generic_string();
            std::ifstream in(entry.path(), std::ios::binary);
            if (!in) continue;
            std::vector<char> data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
            files.emplace_back(rel, std::move(data));
        }
    } catch (...) {
        return false;
    }

    std::ofstream out(output_epkg, std::ios::binary);
    if (!out) return false;
    out.write("EPKG", 4);
    uint32_t ver = 1;
    out.write(reinterpret_cast<const char*>(&ver), 4);
    uint32_t count = static_cast<uint32_t>(files.size());
    out.write(reinterpret_cast<const char*>(&count), 4);
    for (auto& [name, data] : files) {
        uint32_t nlen = static_cast<uint32_t>(name.size());
        uint32_t dlen = static_cast<uint32_t>(data.size());
        out.write(reinterpret_cast<const char*>(&nlen), 4);
        out.write(name.data(), static_cast<std::streamsize>(nlen));
        out.write(reinterpret_cast<const char*>(&dlen), 4);
        if (dlen) out.write(data.data(), static_cast<std::streamsize>(dlen));
    }
    out.close();
    std::cout << "[PMI] Wrote portable EPKG (" << count << " files) -> " << output_epkg << std::endl;
    return true;
}


bool PMI::http_download(const std::string& url, const std::string& destination_path) {
    std::string cmd = "curl -s -L -o \"" + destination_path + "\" \"" + url + "\"";
    return (::system(cmd.c_str()) == 0);
}

bool PMI::http_upload(const std::string& url, const std::string& file_path, const std::string& api_token) {
    std::string cmd = "curl -s -X POST -H \"Authorization: Bearer " + api_token + "\" -F \"package=@" + file_path + "\" \"" + url + "\"";
    return (::system(cmd.c_str()) == 0);
}

PackageManifest PMI::parse_manifest(const std::string& json_path) {
    PackageManifest manifest;
    manifest.name = "unknown";
    manifest.version = "0.0.0";

    std::ifstream file(json_path);
    if (!file.is_open()) return manifest;

    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string content = buffer.str();

    size_t name_pos = content.find("\"name\":");
    if (name_pos != std::string::npos) {
        size_t start = content.find("\"", name_pos + 7) + 1;
        size_t end = content.find("\"", start);
        manifest.name = content.substr(start, end - start);
    }
    return manifest;
}

} // namespace phoenix

