#include "phoenix/vm/vm.hpp"
#include "phoenix/lexer/lexer.hpp"
#include "phoenix/parser/parser.hpp"
#include "phoenix/compiler/compiler.hpp"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>
#include <filesystem>

#if defined(_WIN32)
    #include <windows.h>
#else
    #include <dlfcn.h>
#endif

namespace fs = std::filesystem;

namespace phoenix {

VM::VM(DiagnosticEngine& diagnostics, SandboxPolicy policy)
    : m_diagnostics(diagnostics), m_sandbox(diagnostics, policy) {
    m_stack.reserve(PHX_MAX_STACK_SIZE);
    init_builtins();
}

VM::~VM() = default;

void VM::push(Value val) {
    if (m_stack.size() >= m_max_stack_size) {
        raise_runtime_error("Stack overflow.");
        return;
    }
    m_stack.push_back(std::move(val));
}

Value VM::pop() {
    if (m_stack.empty()) {
        raise_runtime_error("Stack underflow.");
        return Value::nil();
    }
    Value val = std::move(m_stack.back());
    m_stack.pop_back();
    return val;
}

Value VM::peek(size_t distance) const {
    if (distance >= m_stack.size()) return Value::nil();
    return m_stack[m_stack.size() - 1 - distance];
}

void VM::set_global(const std::string& name, Value val) {
    m_globals[name] = std::move(val);
}

Value VM::get_global(const std::string& name) {
    auto it = m_globals.find(name);
    if (it != m_globals.end()) return it->second;
    return Value::nil();
}

void VM::register_native_module(const std::string& mod_name, const std::string& fn_name, NativeFn fn) {
    m_native_modules[mod_name][fn_name] = std::move(fn);
}

// Registered from libs/{time,os,server}/*_mod.cpp (linked into phoenix_core)
void register_phx_time_module(VM* vm);
void register_phx_os_module(VM* vm);
void register_phx_server_module(VM* vm);
void register_phx_packager_module(VM* vm);

void VM::init_builtins() {
    // Built-in comprehensive modules (always available)
    register_phx_time_module(this);
    register_phx_os_module(this);
    register_phx_server_module(this);
    register_phx_packager_module(this);
    // ---- Network: net / http / urlrequest ----
    // Uses system curl when available for portable HTTP without linking libcurl.
    auto http_request = [](const std::string& method, const std::string& url,
                           const std::string& body, const std::string& headers) -> Value {
        // Sanitize URL for shell
        std::string safe_url;
        for (char c : url) {
            if (c == '\'' || c == ';' || c == '&' || c == '|' || c == '`' || c == '$') continue;
            safe_url.push_back(c);
        }
        std::string cmd = "curl -sS -X " + method + " ";
        if (!headers.empty()) {
            std::string h = headers;
            for (char& c : h) { if (c == '\'') c = ' '; }
            cmd += "-H '" + h + "' ";
        }
        if (!body.empty() && (method == "POST" || method == "PUT" || method == "PATCH")) {
            std::string b = body;
            for (char& c : b) { if (c == '\'') c = ' '; }
            cmd += "-d '" + b + "' ";
        }
        cmd += "'" + safe_url + "' 2>/dev/null";
        FILE* pipe = popen(cmd.c_str(), "r");
        if (!pipe) return Value::make_string("");
        std::string result;
        char buf[4096];
        while (fgets(buf, sizeof(buf), pipe)) result += buf;
        pclose(pipe);
        return Value::make_string(result);
    };

    register_native_module("http", "get", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("GET", args[0].to_string(), "",
            args.size() > 1 ? args[1].to_string() : "");
    });
    register_native_module("http", "post", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("POST", args[0].to_string(),
            args.size() > 1 ? args[1].to_string() : "",
            args.size() > 2 ? args[2].to_string() : "Content-Type: application/json");
    });
    register_native_module("http", "put", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("PUT", args[0].to_string(),
            args.size() > 1 ? args[1].to_string() : "",
            args.size() > 2 ? args[2].to_string() : "");
    });
    register_native_module("http", "delete", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("DELETE", args[0].to_string(), "",
            args.size() > 1 ? args[1].to_string() : "");
    });

    register_native_module("urlrequest", "get", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("GET", args[0].to_string(), "", "");
    });
    register_native_module("urlrequest", "fetch", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        std::string method = args.size() > 1 ? args[1].to_string() : "GET";
        std::string body = args.size() > 2 ? args[2].to_string() : "";
        return http_request(method, args[0].to_string(), body, "");
    });

    register_native_module("net", "get", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("GET", args[0].to_string(), "", "");
    });
    register_native_module("net", "post", [http_request](const std::vector<Value>& args, VM&) {
        if (args.empty()) return Value::make_string("");
        return http_request("POST", args[0].to_string(),
            args.size() > 1 ? args[1].to_string() : "",
            "Content-Type: application/json");
    });
    register_native_module("net", "resolve", [](const std::vector<Value>& args, VM&) {
        // Hostname passthrough placeholder (full DNS needs platform sockets)
        if (args.empty()) return Value::make_string("");
        return Value::make_string(args[0].to_string());
    });


    // Terminal Display Output
    register_native_module("sys", "display", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        for (size_t i = 0; i < args.size(); ++i) {
            std::cout << args[i].to_string();
            if (i + 1 < args.size()) std::cout << " ";
        }
        std::cout << std::endl;
        return Value::nil();
    });

    // Terminal Input
    register_native_module("sys", "input", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (!args.empty()) {
            std::cout << args[0].to_string();
            std::cout.flush();
        }
        std::string line;
        std::getline(std::cin, line);
        return Value::make_string(line);
    });

    // Collection Length
    register_native_module("sys", "len", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.empty()) return Value::make_i64(0);
        const Value& v = args[0];
        if (v.is_string()) return Value::make_i64(static_cast<int64_t>(v.as_string().size()));
        if (v.is_list() && v.as_list()) return Value::make_i64(static_cast<int64_t>(v.as_list()->elements.size()));
        if (v.is_dict() && v.as_dict()) return Value::make_i64(static_cast<int64_t>(v.as_dict()->entries.size()));
        return Value::make_i64(0);
    });

    // File Open
    register_native_module("sys", "open", [](const std::vector<Value>& args, VM& vm) {
        if (args.empty()) return Value::nil();
        std::string path = args[0].to_string();
        std::string mode = args.size() > 1 ? args[1].to_string() : "r";

        if (!vm.get_sandbox().validate_file_access(path, mode == "w" || mode == "a")) {
            return Value::nil();
        }

        std::ios_base::openmode flags = std::ios::in;
        if (mode == "w") flags = std::ios::out | std::ios::trunc;
        else if (mode == "a") flags = std::ios::out | std::ios::app;

        auto file = std::make_shared<std::fstream>(path, flags);
        if (!file->is_open()) return Value::nil();

        uint64_t fid = vm.next_file_id++;
        vm.open_files[fid] = file;
        return Value::number(static_cast<double>(fid));
    });

    // File Close
    register_native_module("sys", "close", [](const std::vector<Value>& args, VM& vm) {
        if (args.empty()) return Value::boolean(false);
        uint64_t fid = static_cast<uint64_t>(args[0].as_number());
        if (vm.open_files.count(fid)) {
            vm.open_files[fid]->close();
            vm.open_files.erase(fid);
            return Value::boolean(true);
        }
        return Value::boolean(false);
    });

    // File Read Entire File
    register_native_module("sys", "read", [](const std::vector<Value>& args, VM& vm) {
        if (args.empty()) return Value::make_string("");
        uint64_t fid = static_cast<uint64_t>(args[0].as_number());
        if (!vm.open_files.count(fid)) return Value::make_string("");

        auto& file = vm.open_files[fid];
        file->clear();
        std::string content((std::istreambuf_iterator<char>(*file)), std::istreambuf_iterator<char>());
        return Value::make_string(content);
    });

    // File Read Single Line
    register_native_module("sys", "readln", [](const std::vector<Value>& args, VM& vm) {
        if (args.empty()) return Value::make_string("");
        uint64_t fid = static_cast<uint64_t>(args[0].as_number());
        if (!vm.open_files.count(fid)) return Value::make_string("");

        std::string line;
        std::getline(*vm.open_files[fid], line);
        return Value::make_string(line);
    });

    // File Write
    register_native_module("sys", "write", [](const std::vector<Value>& args, VM& vm) {
        if (args.size() < 2) return Value::number(0);
        uint64_t fid = static_cast<uint64_t>(args[0].as_number());
        if (!vm.open_files.count(fid)) return Value::number(0);

        std::string text = args[1].to_string();
        *vm.open_files[fid] << text;
        vm.open_files[fid]->flush();
        return Value::number(static_cast<double>(text.length()));
    });

    // File Seek
    register_native_module("sys", "seek", [](const std::vector<Value>& args, VM& vm) {
        if (args.size() < 2) return Value::boolean(false);
        uint64_t fid = static_cast<uint64_t>(args[0].as_number());
        if (!vm.open_files.count(fid)) return Value::boolean(false);

        int64_t pos = args[1].as_i64();
        auto& file = vm.open_files[fid];
        file->clear();
        file->seekg(pos);
        file->seekp(pos);
        return Value::boolean(true);
    });

    // Directory Creation
    register_native_module("sys", "mkdir", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.empty()) return Value::boolean(false);
        std::string dir = args[0].to_string();
        try {
            return Value::boolean(fs::create_directories(dir));
        } catch (...) {
            return Value::boolean(false);
        }
    });

    // File Copy
    register_native_module("sys", "copy", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.size() < 2) return Value::boolean(false);
        try {
            fs::copy(args[0].to_string(), args[1].to_string(), fs::copy_options::overwrite_existing);
            return Value::boolean(true);
        } catch (...) { return Value::boolean(false); }
    });

    // File Move / Rename
    register_native_module("sys", "move", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.size() < 2) return Value::boolean(false);
        try {
            fs::rename(args[0].to_string(), args[1].to_string());
            return Value::boolean(true);
        } catch (...) { return Value::boolean(false); }
    });

    // File or Directory Delete
    register_native_module("sys", "delete", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.empty()) return Value::boolean(false);
        try {
            return Value::boolean(fs::remove_all(args[0].to_string()) > 0);
        } catch (...) { return Value::boolean(false); }
    });

    // Native Math Functions
    register_native_module("math", "sqrt", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.empty()) return Value::number(0.0);
        return Value::number(std::sqrt(args[0].as_number()));
    });

    // Native Filesystem Helpers
    register_native_module("fs", "exists", [](const std::vector<Value>& args, VM& vm) {
        (void)vm;
        if (args.empty()) return Value::boolean(false);
        return Value::boolean(fs::exists(args[0].to_string()));
    });

    // Bind Global Function Call Shortcuts
    set_global("display", Value::make_string("built_in_display"));
    set_global("input", Value::make_string("built_in_input"));
    set_global("len", Value::make_string("built_in_len"));
    set_global("open", Value::make_string("built_in_open"));
    set_global("close", Value::make_string("built_in_close"));
    set_global("read", Value::make_string("built_in_read"));
    set_global("readln", Value::make_string("built_in_readln"));
    set_global("write", Value::make_string("built_in_write"));
    set_global("seek", Value::make_string("built_in_seek"));
    set_global("mkdir", Value::make_string("built_in_mkdir"));
    set_global("copy", Value::make_string("built_in_copy"));
    set_global("move", Value::make_string("built_in_move"));
    set_global("delete", Value::make_string("built_in_delete"));
}

bool VM::load_external_native_package(const std::string& module_name) {
#if defined(_WIN32)
    std::string lib_path = "./epkg/" + module_name + "/" + module_name + ".dll";
    HMODULE handle = LoadLibraryA(lib_path.c_str());
    if (!handle) {
        lib_path = "./pkg/" + module_name + ".dll";
        handle = LoadLibraryA(lib_path.c_str());
        if (!handle) return false;
    }

    using InitFunc = void(*)(VM*);
    auto init_fn = reinterpret_cast<InitFunc>(GetProcAddress(handle, "phoenix_module_init"));
    if (!init_fn) return false;
    init_fn(this);
    return true;
#else
    std::vector<std::string> candidates = {
        "./epkg/" + module_name + "/" + module_name + ".so",
        "./pkg/" + module_name + ".so",
        "./libphx_" + module_name + ".so",
        "./build/libphx_" + module_name + ".so",
        "libphx_" + module_name + ".so"
    };
    void* handle = nullptr;
    for (const auto& lib_path : candidates) {
        handle = dlopen(lib_path.c_str(), RTLD_LAZY);
        if (handle) break;
    }
    if (!handle) return false;

    using InitFunc = void(*)(VM*);
    auto init_fn = reinterpret_cast<InitFunc>(dlsym(handle, "phoenix_module_init"));
    if (!init_fn) return false;
    init_fn(this);
    return true;
#endif
}

void VM::raise_runtime_error(const std::string& message) {
    if (!m_try_stack.empty()) {
        TryFrame try_frame = m_try_stack.back();
        m_try_stack.pop_back();

        m_stack.resize(try_frame.stack_depth);
        m_frames.resize(try_frame.call_frame_depth);

        push(Value::make_string(message));
        if (!m_frames.empty()) {
            m_frames.back().ip = try_frame.catch_ip;
        }
        return;
    }

    SourceLocation loc{"<runtime>", 0, 0};
    if (!m_frames.empty()) {
        const CallFrame& top = m_frames.back();
        // ip was already advanced past the failing opcode — use ip-1 when possible
        size_t ip = top.ip > 0 ? top.ip - 1 : 0;
        if (top.chunk && ip < top.chunk->debug_lines.size()) {
            loc = top.chunk->debug_lines[ip];
            if (loc.file_path.empty()) loc.file_path = "<runtime>";
        }
    }

    // Build a multi-line message with call stack
    std::string full = message;
    if (m_frames.size() > 1) {
        full += "\n  Call stack (most recent last):";
        for (size_t i = 0; i < m_frames.size(); ++i) {
            const CallFrame& f = m_frames[i];
            size_t ip = f.ip > 0 ? f.ip - 1 : 0;
            uint32_t line = 0, col = 0;
            std::string file = "<chunk>";
            if (f.chunk && ip < f.chunk->debug_lines.size()) {
                line = f.chunk->debug_lines[ip].line;
                col = f.chunk->debug_lines[ip].column;
                if (!f.chunk->debug_lines[ip].file_path.empty())
                    file = f.chunk->debug_lines[ip].file_path;
            }
            full += "\n    #" + std::to_string(i) + " " + file + ":" +
                    std::to_string(line) + ":" + std::to_string(col) +
                    "  (ip=" + std::to_string(ip) + ")";
        }
    }

    m_diagnostics.report(ErrorCategory::RUNTIME, full, loc);
    m_frames.clear();
}

InterpretResult VM::interpret(std::shared_ptr<Chunk> chunk) {
    if (!chunk) return InterpretResult::RUNTIME_ERROR;

    m_frames.clear();
    m_try_stack.clear();

    m_frames.push_back({chunk, 0, 0});
    return run();
}

uint8_t VM::read_byte() {
    CallFrame& frame = m_frames.back();
    return frame.chunk->code[frame.ip++];
}

uint16_t VM::read_short() {
    CallFrame& frame = m_frames.back();
    uint16_t val = static_cast<uint16_t>(frame.chunk->code[frame.ip] << 8);
    val |= frame.chunk->code[frame.ip + 1];
    frame.ip += 2;
    return val;
}

Value VM::read_constant() {
    uint16_t idx = read_short();
    auto& consts = m_frames.back().chunk->constants;
    if (idx >= consts.size()) return Value::nil();
    return consts[idx];
}

InterpretResult VM::run() {
    while (!m_frames.empty()) {
        CallFrame& frame = m_frames.back();

        if (frame.ip >= frame.chunk->code.size()) {
            m_frames.pop_back();
            continue;
        }

        OpCode instruction = static_cast<OpCode>(read_byte());

        switch (instruction) {
            case OpCode::OP_NOP: break;

            case OpCode::OP_CONSTANT: push(read_constant()); break;
            case OpCode::OP_NIL: push(Value::nil()); break;
            case OpCode::OP_TRUE: push(Value::boolean(true)); break;
            case OpCode::OP_FALSE: push(Value::boolean(false)); break;

            case OpCode::OP_POP: pop(); break;
            case OpCode::OP_DUP: push(peek(0)); break;

            case OpCode::OP_DEFINE_GLOBAL: {
                std::string name = read_constant().as_string();
                set_global(name, pop());
                break;
            }

            case OpCode::OP_GET_GLOBAL: {
                std::string name = read_constant().as_string();
                push(get_global(name));
                break;
            }

            case OpCode::OP_SET_GLOBAL: {
                std::string name = read_constant().as_string();
                m_globals[name] = peek(0);
                break;
            }

            case OpCode::OP_GET_LOCAL: {
                uint8_t slot = read_byte();
                size_t index = frame.stack_base + slot;
                if (index >= m_stack.size()) {
                    // Local slot not yet materialised — treat as nil
                    push(Value::nil());
                } else {
                    push(m_stack[index]);
                }
                break;
            }

            case OpCode::OP_SET_LOCAL: {
                uint8_t slot = read_byte();
                size_t index = frame.stack_base + slot;
                // Grow the stack so the local slot exists and survives later POPs
                if (index >= m_stack.size()) {
                    m_stack.resize(index + 1);
                }
                m_stack[index] = peek(0);
                break;
            }

            case OpCode::OP_BUILD_LIST: {
                uint8_t count = read_byte();
                auto list_obj = std::make_shared<HeapList>();
                list_obj->elements.resize(count);
                for (int i = count - 1; i >= 0; i--) {
                    list_obj->elements[i] = pop();
                }
                push(Value::list(list_obj));
                break;
            }

            case OpCode::OP_BUILD_DICT: {
                uint8_t row_count = read_byte();
                uint8_t col_count = read_byte();
                auto dict_obj = std::make_shared<HeapDict>();

                // Row values were pushed last, so they come off the stack first.
                std::vector<std::vector<Value>> rows(row_count);
                for (int r = row_count - 1; r >= 0; r--) {
                    std::vector<Value> row(col_count);
                    for (int c = col_count - 1; c >= 0; c--) {
                        row[c] = pop();
                    }
                    rows[r] = std::move(row);
                }

                // Schema column names were pushed in order after the primary key
                // name, so they come off the stack next, in reverse.
                std::vector<std::string> schema_columns(col_count);
                for (int c = col_count - 1; c >= 0; c--) {
                    schema_columns[c] = pop().as_string();
                }

                // Primary key column name was pushed first, so it comes off last.
                std::string pk_name = pop().as_string();

                dict_obj->schema_columns = schema_columns;
                dict_obj->primary_key_column = pk_name;

                for (int r = 0; r < row_count; r++) {
                    const auto& row = rows[r];
                    if (!row.empty()) {
                        std::string pk = row[0].to_string();
                        for (size_t c = 0; c < row.size() && c < schema_columns.size(); ++c) {
                            dict_obj->matrix_records[pk][schema_columns[c]] = row[c];
                        }
                        dict_obj->entries[pk] = row.size() > 1 ? row[1] : Value::nil();
                    }
                }
                push(Value::dict(dict_obj));
                break;
            }

            case OpCode::OP_GET_INDEX: {
                Value index = pop();
                Value target = pop();

                if (target.type == ValueType::LIST && target.as_list()) {
                    int idx = static_cast<int>(index.as_number());
                    auto& elems = target.as_list()->elements;
                    if (idx >= 0 && idx < static_cast<int>(elems.size())) {
                        push(elems[idx]);
                    } else {
                        raise_runtime_error("List index out of bounds.");
                    }
                } else if (target.type == ValueType::STRING) {
                    int idx = static_cast<int>(index.as_number());
                    std::string str = target.as_string();
                    if (idx >= 0 && idx < static_cast<int>(str.size())) {
                        push(Value::make_string(std::string(1, str[idx])));
                    } else {
                        raise_runtime_error("String index out of bounds.");
                    }
                } else if (target.type == ValueType::DICT && target.as_dict()) {
                    std::string key = index.to_string();
                    auto dict_ptr = target.as_dict();
                    if (dict_ptr->matrix_records.count(key)) {
                        auto row_dict = std::make_shared<HeapDict>();
                        row_dict->entries = dict_ptr->matrix_records[key];
                        push(Value::dict(row_dict));
                    } else if (dict_ptr->entries.count(key)) {
                        push(dict_ptr->entries[key]);
                    } else {
                        push(Value::nil());
                    }
                } else {
                    raise_runtime_error("Attempted index access on invalid target.");
                }
                break;
            }

            case OpCode::OP_QUERY_TABLE: {
                Value dict_name_val = pop();
                Value pk_val = pop();
                std::string key = dict_name_val.to_string();
                if (m_globals.find(key) != m_globals.end()) {
                    Value& dict = m_globals[key];
                    push(dict.query_primary_key(pk_val));
                } else {
                    raise_runtime_error("Relational dictionary '" + key + "' does not exist.");
                }
                break;
            }

            case OpCode::OP_TYPE_CAST: {
                std::string target_type = read_constant().as_string();
                Value val = pop();
                val.cast_to(target_type);
                push(val);
                break;
            }

            case OpCode::OP_INPUT: {
                uint8_t has_prompt = read_byte();
                if (has_prompt == 1) {
                    Value prompt = pop();
                    std::cout << prompt.to_string();
                    std::cout.flush();
                }
                std::string line;
                std::getline(std::cin, line);
                push(Value::make_string(line));
                break;
            }

            case OpCode::OP_MODE: {
                current_mode = read_constant().as_string();
                // Mode-tuned evaluation stack ceilings
                // graphics: heavy frame/scene temps
                // net: concurrent buffers
                // os: deep call chains / drivers
                // std: general CLI
                // micro: constrained embedded profile
                if (current_mode == "graphics") {
                    m_max_stack_size = 65536;
                } else if (current_mode == "net") {
                    m_max_stack_size = 32768;
                } else if (current_mode == "os") {
                    m_max_stack_size = 49152;
                } else if (current_mode == "micro" || current_mode == "embedded") {
                    m_max_stack_size = 2048;
                } else if (current_mode == "std" || current_mode == "standard") {
                    m_max_stack_size = 16384;
                } else {
                    m_max_stack_size = 16384; // unknown modes → std
                }
                m_stack.reserve(m_max_stack_size);
                break;
            }

            case OpCode::OP_ADD_COLUMN: {
                std::string col_name = pop().as_string();
                std::string dict_name = pop().as_string();
                if (m_globals.find(dict_name) != m_globals.end() && m_globals[dict_name].is_dict()) {
                    m_globals[dict_name].as_dict()->schema_columns.push_back(col_name);
                }
                break;
            }

            case OpCode::OP_UPSERT_ROW: {
                Value new_val = pop();
                std::string col_name = pop().as_string();
                std::string dict_name = pop().as_string();
                Value pk_val = pop();
                if (m_globals.find(dict_name) != m_globals.end() && m_globals[dict_name].is_dict()) {
                    m_globals[dict_name].update_cell(pk_val, col_name, new_val);
                }
                break;
            }

            case OpCode::OP_ASM: {
                pop();
                break;
            }

            case OpCode::OP_ADD: {
                Value b = pop(); Value a = pop();
                if (a.type == ValueType::STRING || b.type == ValueType::STRING) {
                    push(Value::make_string(a.to_string() + b.to_string()));
                } else {
                    push(Value::number(a.as_number() + b.as_number()));
                }
                break;
            }

            case OpCode::OP_SUBTRACT: {
                Value b = pop(); Value a = pop();
                push(Value::number(a.as_number() - b.as_number()));
                break;
            }

            case OpCode::OP_MULTIPLY: {
                Value b = pop(); Value a = pop();
                push(Value::number(a.as_number() * b.as_number()));
                break;
            }

            case OpCode::OP_DIVIDE: {
                Value b = pop(); Value a = pop();
                if (b.as_number() == 0) {
                    raise_runtime_error("Division by zero.");
                    break;
                }
                push(Value::number(a.as_number() / b.as_number()));
                break;
            }

            case OpCode::OP_EQUAL: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(a.strict_equals(b)));
                break;
            }

            case OpCode::OP_LESS: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(a.as_number() < b.as_number()));
                break;
            }

            case OpCode::OP_GREATER: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(a.as_number() > b.as_number()));
                break;
            }

            case OpCode::OP_NOT_EQUAL: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(!a.strict_equals(b)));
                break;
            }

            case OpCode::OP_GREATER_EQUAL: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(a.as_number() >= b.as_number()));
                break;
            }

            case OpCode::OP_LESS_EQUAL: {
                Value b = pop(); Value a = pop();
                push(Value::boolean(a.as_number() <= b.as_number()));
                break;
            }

            case OpCode::OP_MODULO: {
                Value b = pop(); Value a = pop();
                if (b.as_number() == 0) {
                    raise_runtime_error("Division by zero.");
                    break;
                }
                push(Value::number(std::fmod(a.as_number(), b.as_number())));
                break;
            }

            case OpCode::OP_NEGATE: {
                push(Value::number(-pop().as_number()));
                break;
            }

            case OpCode::OP_NOT: {
                push(Value::boolean(!pop().is_truthy()));
                break;
            }

            case OpCode::OP_JUMP: {
                uint16_t offset = read_short();
                frame.ip += offset;
                break;
            }

            case OpCode::OP_JUMP_IF_FALSE: {
                uint16_t offset = read_short();
                if (!peek(0).is_truthy()) frame.ip += offset;
                break;
            }

            case OpCode::OP_LOOP: {
                uint16_t offset = read_short();
                frame.ip -= offset;
                break;
            }

            case OpCode::OP_LOAD_SCRIPT: {
                std::string alias = pop().as_string();
                std::string path = pop().as_string();
                if (fs::exists(path)) {
                    std::ifstream f(path);
                    std::string src((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
                    Lexer l(src, m_diagnostics, path);
                    Parser p(l.tokenize(), m_diagnostics);
                    Compiler c(m_diagnostics);
                    auto chk = c.compile(p.parse_program());
                    interpret(chk);
                    set_global(alias, Value::make_string("module_" + alias));
                }
                break;
            }

            case OpCode::OP_IMPORT_MODULE: {
                std::string alias = pop().as_string();
                std::string mod_name = pop().as_string();
                load_external_native_package(mod_name);
                set_global(alias, Value::make_string("module_" + alias));
                break;
            }

            case OpCode::OP_INVOKE_NATIVE: {
                uint8_t arg_count = read_byte();
                Value fn_val = pop();
                Value mod_val = pop();
                std::string fn_name = fn_val.as_string();
                std::string mod_name = mod_val.as_string();

                std::vector<Value> args(arg_count);
                for (int i = arg_count - 1; i >= 0; i--) args[i] = pop();

                if (m_native_modules.count(mod_name) == 0 || m_native_modules[mod_name].count(fn_name) == 0) {
                    if (!load_external_native_package(mod_name)) {
                        raise_runtime_error("Native module @" + mod_name + "." + fn_name + "() missing.");
                        break;
                    }
                }

                push(m_native_modules[mod_name][fn_name](args, *this));
                break;
            }

            case OpCode::OP_CALL: {
                uint8_t raw_count = read_byte();
                bool is_method_call = (raw_count & 0x80) != 0;
                uint8_t arg_count = raw_count & 0x7F;

                // ---- Method call: stack is [instance, method, args...] ----
                if (is_method_call) {
                    std::vector<Value> user_args(arg_count);
                    for (int i = static_cast<int>(arg_count) - 1; i >= 0; --i) user_args[i] = pop();
                    Value method = pop();
                    Value instance = pop();

                    if (method.is_string() && method.as_string() == "__builtin_address__") {
                        // struct.__address__(addr) → struct.address = addr
                        if (!user_args.empty() && instance.is_dict() && instance.as_dict()) {
                            instance.as_dict()->entries["address"] = user_args[0];
                        }
                        push(instance);
                        break;
                    }
                    if (method.type != ValueType::POINTER || method.as_pointer() == nullptr) {
                        raise_runtime_error("Method is not callable: got " + method.to_string());
                        break;
                    }
                    auto* fn_chunk = static_cast<Chunk*>(method.as_pointer());
                    size_t stack_base = m_stack.size();
                    push(instance); // first parameter = struct / self
                    for (const auto& a : user_args) push(a);

                    m_frames.push_back({
                        std::shared_ptr<Chunk>(fn_chunk, [](Chunk*){}),
                        0,
                        stack_base
                    });
                    break;
                }

                Value callee = peek(arg_count);

                // ---- Constructor: calling a class / system object ----
                if (callee.is_dict() && callee.as_dict()) {
                    auto& entries = callee.as_dict()->entries;
                    std::string type_tag = entries.count("__type__") ? entries["__type__"].to_string() : "";
                    if (type_tag == "class" || type_tag == "system") {
                        std::vector<Value> args(arg_count);
                        for (int i = static_cast<int>(arg_count) - 1; i >= 0; --i) args[i] = pop();
                        pop(); // class object

                        auto instance = std::make_shared<HeapDict>();
                        instance->entries["__type__"] = Value::make_string("instance");
                        instance->entries["__class__"] = callee;
                        Value instance_val = Value::dict(instance);

                        Value init_fn = Value::nil();
                        if (entries.count("__methods__")) {
                            Value methods = entries["__methods__"];
                            if (methods.is_dict() && methods.as_dict()) {
                                if (methods.as_dict()->entries.count("new_init__"))
                                    init_fn = methods.as_dict()->entries["new_init__"];
                                else if (methods.as_dict()->entries.count("__init__"))
                                    init_fn = methods.as_dict()->entries["__init__"];
                            }
                        }

                        if (init_fn.type == ValueType::POINTER && init_fn.as_pointer() != nullptr) {
                            auto* fn_chunk = static_cast<Chunk*>(init_fn.as_pointer());
                            size_t stack_base = m_stack.size();
                            push(instance_val);
                            for (const auto& a : args) push(a);
                            // Mark so OP_RETURN yields the instance instead of init's return value
                            set_global("__ctor_instance__", instance_val);
                            m_frames.push_back({
                                std::shared_ptr<Chunk>(fn_chunk, [](Chunk*){}),
                                0,
                                stack_base
                            });
                        } else {
                            push(instance_val);
                        }
                        break;
                    }
                }

                if (callee.type == ValueType::POINTER && callee.as_pointer() != nullptr) {
                    // User-defined function (Chunk*)
                    // Incoming stack layout:
                    //   [ ... | callee | arg0 | arg1 | ... | argN-1 ]
                    //
                    // Desired layout for the new frame (matches compiler local slots):
                    //   [ ... | arg0 | arg1 | ... | argN-1 ]
                    //           ↑
                    //        stack_base  →  local slot 0 = first parameter
                    auto* fn_chunk = static_cast<Chunk*>(callee.as_pointer());

                    size_t stack_base;
                    if (arg_count == 0) {
                        // No arguments: just remove the callee, base is current top
                        m_stack.pop_back();
                        stack_base = m_stack.size();
                    } else {
                        size_t callee_slot = m_stack.size() - arg_count - 1;
                        // Shift arguments down so they overwrite the callee
                        for (uint8_t i = 0; i < arg_count; ++i) {
                            m_stack[callee_slot + i] = std::move(m_stack[callee_slot + 1 + i]);
                        }
                        m_stack.pop_back();   // drop the leftover duplicate at the top
                        stack_base = callee_slot;   // now points at arg0
                    }

                    m_frames.push_back({
                        std::shared_ptr<Chunk>(fn_chunk, [](Chunk*){}),
                        0,               // ip
                        stack_base
                    });
                } else if (callee.type == ValueType::STRING) {
                    std::string fn_str = callee.as_string();
                    std::vector<Value> args(arg_count);
                    for (int i = arg_count - 1; i >= 0; i--) args[i] = pop();
                    pop(); // pop callee identifier

                    if (fn_str == "built_in_display") {
                        push(m_native_modules["sys"]["display"](args, *this));
                    } else if (fn_str == "built_in_input") {
                        push(m_native_modules["sys"]["input"](args, *this));
                    } else if (fn_str == "built_in_len") {
                        push(m_native_modules["sys"]["len"](args, *this));
                    } else if (fn_str == "built_in_open") {
                        push(m_native_modules["sys"]["open"](args, *this));
                    } else if (fn_str == "built_in_close") {
                        push(m_native_modules["sys"]["close"](args, *this));
                    } else if (fn_str == "built_in_read") {
                        push(m_native_modules["sys"]["read"](args, *this));
                    } else if (fn_str == "built_in_readln") {
                        push(m_native_modules["sys"]["readln"](args, *this));
                    } else if (fn_str == "built_in_write") {
                        push(m_native_modules["sys"]["write"](args, *this));
                    } else if (fn_str == "built_in_seek") {
                        push(m_native_modules["sys"]["seek"](args, *this));
                    } else if (fn_str == "built_in_mkdir") {
                        push(m_native_modules["sys"]["mkdir"](args, *this));
                    } else if (fn_str == "built_in_copy") {
                        push(m_native_modules["sys"]["copy"](args, *this));
                    } else if (fn_str == "built_in_move") {
                        push(m_native_modules["sys"]["move"](args, *this));
                    } else if (fn_str == "built_in_delete") {
                        push(m_native_modules["sys"]["delete"](args, *this));
                    } else if (m_globals.count(fn_str) && m_globals[fn_str].type == ValueType::POINTER) {
                        // Fallback path: function looked up by global name
                        auto* fn_chunk = static_cast<Chunk*>(m_globals[fn_str].as_pointer());

                        // Push arguments so they become the locals starting at stack_base
                        size_t stack_base = m_stack.size();
                        for (const auto& arg : args) {
                            push(arg);
                        }

                        m_frames.push_back({
                            std::shared_ptr<Chunk>(fn_chunk, [](Chunk*){}),
                            0,
                            stack_base
                        });
                    } else {
                        raise_runtime_error("Value is not callable: '" + fn_str + "'.");
                        break;
                    }
                } else {
                    raise_runtime_error("Value is not callable.");
                    break;
                }
                break;
            }

            case OpCode::OP_CLASS: {
                std::string class_name = read_constant().as_string();
                auto cls = std::make_shared<HeapDict>();
                cls->entries["__type__"] = Value::make_string("class");
                cls->entries["__name__"] = Value::make_string(class_name);
                cls->entries["__methods__"] = Value::dict(std::make_shared<HeapDict>());
                push(Value::dict(cls));
                break;
            }

            case OpCode::OP_SYSTEM: {
                std::string sys_name = read_constant().as_string();
                auto sys = std::make_shared<HeapDict>();
                sys->entries["__type__"] = Value::make_string("system");
                sys->entries["__name__"] = Value::make_string(sys_name);
                sys->entries["__methods__"] = Value::dict(std::make_shared<HeapDict>());
                push(Value::dict(sys));
                break;
            }

            case OpCode::OP_METHOD: {
                // stack: [class, method_name, method_fn]
                Value method_fn = pop();
                Value method_name = pop();
                Value cls_val = peek(0);
                if (cls_val.is_dict() && cls_val.as_dict()) {
                    Value methods = cls_val.as_dict()->entries["__methods__"];
                    if (!methods.is_dict() || !methods.as_dict()) {
                        methods = Value::dict(std::make_shared<HeapDict>());
                    }
                    methods.as_dict()->entries[method_name.to_string()] = method_fn;
                    cls_val.as_dict()->entries["__methods__"] = methods;
                }
                break;
            }

            case OpCode::OP_INHERIT: {
                // stack: [class, parent]
                Value parent = pop();
                Value cls_val = peek(0);
                if (cls_val.is_dict() && cls_val.as_dict() && parent.is_dict() && parent.as_dict()) {
                    Value parent_methods = parent.as_dict()->entries["__methods__"];
                    if (parent_methods.is_dict() && parent_methods.as_dict()) {
                        Value methods = cls_val.as_dict()->entries["__methods__"];
                        if (!methods.is_dict() || !methods.as_dict()) {
                            methods = Value::dict(std::make_shared<HeapDict>());
                        }
                        for (const auto& [name, fn] : parent_methods.as_dict()->entries) {
                            if (!methods.as_dict()->entries.count(name)) {
                                methods.as_dict()->entries[name] = fn;
                            }
                        }
                        cls_val.as_dict()->entries["__methods__"] = methods;
                    }
                    cls_val.as_dict()->entries["__parent__"] = parent;
                }
                break;
            }

            case OpCode::OP_GET_PROPERTY: {
                std::string prop = read_constant().as_string();
                Value obj = pop();
                Value result = Value::nil();
                if (obj.is_dict() && obj.as_dict()) {
                    auto& entries = obj.as_dict()->entries;

                    // super::method — skip the instance's own class, start at parent
                    bool super_lookup = false;
                    std::string method_name = prop;
                    if (prop.rfind("super::", 0) == 0) {
                        super_lookup = true;
                        method_name = prop.substr(7);
                    }

                    if (!super_lookup && entries.count(prop)) {
                        result = entries[prop];
                    } else {
                        Value cls = obj;
                        if (entries.count("__class__")) cls = entries["__class__"];
                        if (super_lookup && cls.is_dict() && cls.as_dict() &&
                            cls.as_dict()->entries.count("__parent__")) {
                            cls = cls.as_dict()->entries["__parent__"];
                        }
                        while (cls.is_dict() && cls.as_dict()) {
                            auto& ce = cls.as_dict()->entries;
                            if (ce.count("__methods__")) {
                                Value methods = ce["__methods__"];
                                if (methods.is_dict() && methods.as_dict() &&
                                    methods.as_dict()->entries.count(method_name)) {
                                    result = methods.as_dict()->entries[method_name];
                                    break;
                                }
                            }
                            if (ce.count("__parent__")) cls = ce["__parent__"];
                            else break;
                        }
                    }
                }
                // Synthetic instance helpers
                if (result.is_nil() && prop == "__address__") {
                    result = Value::make_string("__builtin_address__");
                }
                push(result);
                break;
            }

            case OpCode::OP_SET_PROPERTY: {
                std::string prop = read_constant().as_string();
                Value val = pop();
                Value obj = pop();
                if (obj.is_dict() && obj.as_dict()) {
                    obj.as_dict()->entries[prop] = val;
                    push(val);
                } else {
                    raise_runtime_error("Cannot set property on non-object value.");
                }
                break;
            }

            case OpCode::OP_RETURN: {
                Value result = pop();
                size_t base = m_frames.back().stack_base;
                m_frames.pop_back();

                while (m_stack.size() > base) m_stack.pop_back();

                // If this frame was a constructor (new_init__), yield the instance.
                // Only replace when the constructor returned nil (normal Phoenix style).
                auto it = m_globals.find("__ctor_instance__");
                if (it != m_globals.end() && !it->second.is_nil() && result.is_nil()) {
                    result = it->second;
                    m_globals.erase(it);
                }

                push(result);
                break;
            }

            case OpCode::OP_PUSH_TRY: {
                uint16_t catch_offset = read_short();
                m_try_stack.push_back({
                    frame.ip + catch_offset,
                    m_stack.size(),
                    m_frames.size()
                });
                break;
            }

            case OpCode::OP_POP_TRY: {
                if (!m_try_stack.empty()) m_try_stack.pop_back();
                break;
            }

            case OpCode::OP_RAISE: {
                raise_runtime_error(pop().to_string());
                break;
            }

            case OpCode::OP_SYSTEM_CMD: {
                std::string cmd = pop().to_string();
                if (!m_sandbox.validate_system_command(cmd)) {
                    push(Value::number(-1));
                } else {
                    push(Value::number(::system(cmd.c_str())));
                }
                break;
            }


            case OpCode::OP_SET_INDEX: {
                Value value = pop();
                Value index = pop();
                Value target = pop();
                if (target.type == ValueType::LIST && target.as_list()) {
                    int idx = static_cast<int>(index.as_number());
                    auto& elems = target.as_list()->elements;
                    if (idx >= 0 && idx < static_cast<int>(elems.size())) {
                        elems[idx] = value;
                        push(value);
                    } else {
                        raise_runtime_error("List index out of bounds on set.");
                    }
                } else if (target.type == ValueType::DICT && target.as_dict()) {
                    target.as_dict()->entries[index.to_string()] = value;
                    push(value);
                } else {
                    raise_runtime_error("Cannot set index on this value.");
                }
                break;
            }

            case OpCode::OP_MUTATE_TABLE: {
                // Generic table mutation placeholder
                Value val = pop();
                Value key = pop();
                Value table = pop();
                if (table.is_dict() && table.as_dict()) {
                    table.as_dict()->entries[key.to_string()] = val;
                    push(val);
                } else {
                    raise_runtime_error("MUTATE_TABLE target is not a dict.");
                }
                break;
            }

            case OpCode::OP_BIT_AND: {
                Value b = pop(); Value a = pop();
                push(Value::make_i64(a.as_i64() & b.as_i64()));
                break;
            }
            case OpCode::OP_BIT_OR: {
                Value b = pop(); Value a = pop();
                push(Value::make_i64(a.as_i64() | b.as_i64()));
                break;
            }
            case OpCode::OP_BIT_XOR: {
                Value b = pop(); Value a = pop();
                push(Value::make_i64(a.as_i64() ^ b.as_i64()));
                break;
            }
            case OpCode::OP_BIT_NOT: {
                Value a = pop();
                push(Value::make_i64(~a.as_i64()));
                break;
            }

            case OpCode::OP_HALT: return InterpretResult::OK;

            default:
                raise_runtime_error("Unrecognized opcode encountered.");
                return InterpretResult::RUNTIME_ERROR;
        }
    }

    return InterpretResult::OK;
}

} // namespace phoenix