
#include "phoenix/vm/sandbox.hpp"
#include <algorithm>
#include <filesystem>

namespace fs = std::filesystem;

namespace phoenix {

SandboxEnforcer::SandboxEnforcer(DiagnosticEngine& diagnostics, SandboxPolicy policy)
    : m_diagnostics(diagnostics), m_policy(policy) {
    // Current working directory is allowed by default
    allow_directory(fs::current_path().string());
}

void SandboxEnforcer::allow_directory(const std::string& dir_path) {
    std::string canonical = canonicalize_path(dir_path);
    if (!canonical.empty()) {
        m_allowed_directories.push_back(canonical);
    }
}

std::string SandboxEnforcer::canonicalize_path(const std::string& raw_path) {
    try {
        fs::path p(raw_path);
        if (fs::exists(p)) {
            return fs::weakly_canonical(p).string();
        }
        return fs::absolute(p).lexically_normal().string();
    } catch (...) {
        return raw_path;
    }
}

bool SandboxEnforcer::is_path_allowed(const std::string& path) const {
    if (m_policy == SandboxPolicy::UNRESTRICTED) return true;

    std::string canonical = const_cast<SandboxEnforcer*>(this)->canonicalize_path(path);
    if (canonical.empty()) return false;

    for (std::string allowed : m_allowed_directories) {
        // Enforce trailing slash on root comparison to fix Defect #12 (e.g., /app vs /app_secret)
        if (!allowed.empty() && allowed.back() != fs::path::preferred_separator) {
            allowed += fs::path::preferred_separator;
        }

        std::string check_target = canonical;
        if (!check_target.empty() && check_target.back() != fs::path::preferred_separator) {
            check_target += fs::path::preferred_separator;
        }

        if (check_target.rfind(allowed, 0) == 0 || canonical == allowed.substr(0, allowed.size() - 1)) {
            return true;
        }
    }

    return false;
}

bool SandboxEnforcer::validate_file_access(const std::string& file_path, bool write_access) {
    if (m_policy == SandboxPolicy::UNRESTRICTED) return true;

    if (m_policy == SandboxPolicy::ISOLATED && write_access) {
        m_diagnostics.report(ErrorCategory::SANDBOX, "Sandbox Violation: File write operation prohibited under ISOLATED policy.", SourceLocation{"<sandbox>", 0, 0});
        return false;
    }

    if (m_policy == SandboxPolicy::READ_ONLY && write_access) {
        m_diagnostics.report(ErrorCategory::SANDBOX, "Sandbox Violation: File write operation prohibited under READ_ONLY policy.", SourceLocation{"<sandbox>", 0, 0});
        return false;
    }

    if (!is_path_allowed(file_path)) {
        m_diagnostics.report(ErrorCategory::SANDBOX, "Sandbox Violation: Access denied to path outside allowed directory bounds: " + file_path, SourceLocation{"<sandbox>", 0, 0});
        return false;
    }

    return true;
}

bool SandboxEnforcer::validate_system_command(const std::string& command) {
    if (m_policy == SandboxPolicy::UNRESTRICTED) return true;

    // Prevent malicious shell execution operators
    if (command.find(';') != std::string::npos ||
        command.find("&&") != std::string::npos ||
        command.find("||") != std::string::npos ||
        command.find('`') != std::string::npos) {
        m_diagnostics.report(ErrorCategory::SANDBOX, "Sandbox Violation: Command contains forbidden shell chaining operators.", SourceLocation{"<sandbox>", 0, 0});
        return false;
    }

    m_diagnostics.report(ErrorCategory::SANDBOX, "Sandbox Violation: Execution of external system command '" + command + "' blocked by policy.", SourceLocation{"<sandbox>", 0, 0});
    return false;
}

} // namespace phoenix

