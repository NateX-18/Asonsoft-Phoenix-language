
#include "phoenix/vm/memory.hpp"
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>

namespace phoenix {

// MemoryArena Implementation
MemoryArena::MemoryArena(size_t chunk_size) : m_default_chunk_size(chunk_size) {
    allocate_chunk(m_default_chunk_size);
}

MemoryArena::~MemoryArena() {
    ChunkHeader* current = m_head;
    while (current) {
        ChunkHeader* next = current->next;
        std::free(current);
        current = next;
    }
}

void MemoryArena::allocate_chunk(size_t min_size) {
    size_t size = std::max(m_default_chunk_size, min_size);
    void* raw = std::malloc(sizeof(ChunkHeader) + size);
    if (!raw) return;
    auto* chunk = static_cast<ChunkHeader*>(raw);
    chunk->capacity = size;
    chunk->used = 0;
    chunk->next = m_head;
    m_head = chunk;
}

void* MemoryArena::allocate(size_t bytes) {
    // 8-byte alignment
    bytes = (bytes + 7) & ~7;

    if (!m_head || (m_head->used + bytes > m_head->capacity)) {
        allocate_chunk(bytes);
    }

    if (!m_head) return nullptr;

    void* ptr = reinterpret_cast<uint8_t*>(m_head) + sizeof(ChunkHeader) + m_head->used;
    m_head->used += bytes;
    return ptr;
}

void MemoryArena::reset() {
    ChunkHeader* current = m_head;
    while (current) {
        current->used = 0;
        current = current->next;
    }
}

// Dynamic Table Schema Registry Implementation
void DynamicTableRegistry::register_table(const std::string& table_name, std::shared_ptr<HeapDict> initial_schema) {
    m_tables[table_name] = initial_schema ? initial_schema : std::make_shared<HeapDict>();
}

std::shared_ptr<HeapDict> DynamicTableRegistry::get_table(const std::string& table_name) {
    auto it = m_tables.find(table_name);
    if (it != m_tables.end()) {
        return it->second;
    }
    auto new_table = std::make_shared<HeapDict>();
    m_tables[table_name] = new_table;
    return new_table;
}

bool DynamicTableRegistry::query_and_mutate(const std::string& table_name, const std::string& pattern, const Value& value) {
    auto table = get_table(table_name);
    if (!table) return false;

    table->entries[pattern] = value;
    return true;
}

// Memory Manager Implementation
MemoryManager::MemoryManager() = default;

MemoryManager::~MemoryManager() {
    for (Value* obj : m_heap_objects) {
        delete obj;
    }
    m_heap_objects.clear();
}

void MemoryManager::track_allocation(size_t bytes) {
    m_allocated_bytes += bytes;
}

Value* MemoryManager::allocate_value(Value val) {
    Value* ptr = new Value(std::move(val));
    m_heap_objects.push_back(ptr);
    track_allocation(sizeof(Value));
    return ptr;
}

void MemoryManager::mark_value(Value* val) {
    if (!val || val->marked) return;
    val->marked = true;

    if (val->type == ValueType::LIST && val->list_val) {
        for (auto& elem : val->list_val->elements) {
            mark_value(&elem);
        }
    } else if (val->type == ValueType::DICT && val->dict_val) {
        for (auto& [k, v] : val->dict_val->entries) {
            mark_value(&v);
        }
        for (auto& [pk, row] : val->dict_val->matrix_records) {
            for (auto& [col, cell] : row) {
                mark_value(&cell);
            }
        }
    }
}

void MemoryManager::run_garbage_collection(std::vector<Value>& root_stack, std::unordered_map<std::string, Value>& globals) {
    // Mark & Sweep GC Pass
    for (Value* obj : m_heap_objects) {
        if (obj) obj->marked = false;
    }

    // Phase 1: Mark from VM Evaluation Stack
    for (auto& val : root_stack) {
        mark_value(&val);
    }

    // Phase 2: Mark from Global Variable Registry
    for (auto& [name, val] : globals) {
        mark_value(&val);
    }

    // Phase 3: Sweep Unreachable Objects
    auto it = m_heap_objects.begin();
    while (it != m_heap_objects.end()) {
        if (!(*it)->marked) {
            delete *it;
            it = m_heap_objects.erase(it);
        } else {
            ++it;
        }
    }

    if (m_allocated_bytes > m_next_gc_threshold) {
        m_next_gc_threshold *= 2;
    }
}

} // namespace phoenix
