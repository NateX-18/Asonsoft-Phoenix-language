#include "phoenix/vm/bytecode.hpp"
#include <iostream>
#include <iomanip>

namespace phoenix {

static size_t simple_instruction(const char* name, size_t offset) {
    std::cout << name << "\n";
    return offset + 1;
}

static size_t byte_instruction(const char* name, const Chunk& chunk, size_t offset) {
    uint8_t slot = chunk.code[offset + 1];
    std::cout << std::left << std::setw(18) << name << " " << static_cast<int>(slot) << "\n";
    return offset + 2;
}

static size_t constant_instruction(const char* name, const Chunk& chunk, size_t offset) {
    uint8_t constant = chunk.code[offset + 1];
    std::cout << std::left << std::setw(18) << name << " " << static_cast<int>(constant) << " '";
    std::cout << chunk.constants[constant].to_string() << "'\n";
    return offset + 2;
}

static size_t jump_instruction(const char* name, int sign, const Chunk& chunk, size_t offset) {
    uint16_t jump = static_cast<uint16_t>(chunk.code[offset + 1] << 8);
    jump |= chunk.code[offset + 2];
    std::cout << std::left << std::setw(18) << name << " " << offset << " -> " << (offset + 3 + sign * jump) << "\n";
    return offset + 3;
}

void Chunk::disassemble(const std::string& name) const {
    std::cout << "=== " << name << " ===" << std::endl;
    for (size_t offset = 0; offset < code.size();) {
        offset = disassemble_instruction(offset);
    }
}

size_t Chunk::disassemble_instruction(size_t offset) const {
    std::cout << std::setw(4) << std::setfill('0') << offset << " ";

    if (offset < debug_lines.size()) {
        std::cout << std::setw(4) << std::setfill(' ') << debug_lines[offset].line << " ";
    } else {
        std::cout << "   | ";
    }

    uint8_t instruction = code[offset];
    switch (static_cast<OpCode>(instruction)) {
        case OpCode::OP_NOP: return simple_instruction("OP_NOP", offset);
        case OpCode::OP_CONSTANT: return constant_instruction("OP_CONSTANT", *this, offset);
        case OpCode::OP_NIL: return simple_instruction("OP_NIL", offset);
        case OpCode::OP_TRUE: return simple_instruction("OP_TRUE", offset);
        case OpCode::OP_FALSE: return simple_instruction("OP_FALSE", offset);
        case OpCode::OP_POP: return simple_instruction("OP_POP", offset);
        case OpCode::OP_DUP: return simple_instruction("OP_DUP", offset);

        case OpCode::OP_DEFINE_GLOBAL: return constant_instruction("OP_DEFINE_GLOBAL", *this, offset);
        case OpCode::OP_GET_GLOBAL: return constant_instruction("OP_GET_GLOBAL", *this, offset);
        case OpCode::OP_SET_GLOBAL: return constant_instruction("OP_SET_GLOBAL", *this, offset);
        case OpCode::OP_GET_LOCAL: return byte_instruction("OP_GET_LOCAL", *this, offset);
        case OpCode::OP_SET_LOCAL: return byte_instruction("OP_SET_LOCAL", *this, offset);

        case OpCode::OP_BUILD_LIST: return byte_instruction("OP_BUILD_LIST", *this, offset);
        case OpCode::OP_BUILD_DICT: return byte_instruction("OP_BUILD_DICT", *this, offset);
        case OpCode::OP_GET_INDEX: return simple_instruction("OP_GET_INDEX", offset);
        case OpCode::OP_SET_INDEX: return simple_instruction("OP_SET_INDEX", offset);
        case OpCode::OP_GET_PROPERTY: return constant_instruction("OP_GET_PROPERTY", *this, offset);
        case OpCode::OP_SET_PROPERTY: return constant_instruction("OP_SET_PROPERTY", *this, offset);

        case OpCode::OP_QUERY_TABLE: return simple_instruction("OP_QUERY_TABLE", offset);
        case OpCode::OP_MUTATE_TABLE: return simple_instruction("OP_MUTATE_TABLE", offset);
        case OpCode::OP_TYPE_CAST: return constant_instruction("OP_TYPE_CAST", *this, offset);
        case OpCode::OP_INPUT: return byte_instruction("OP_INPUT", *this, offset);
        case OpCode::OP_MODE: return constant_instruction("OP_MODE", *this, offset);

        case OpCode::OP_ADD: return simple_instruction("OP_ADD", offset);
        case OpCode::OP_SUBTRACT: return simple_instruction("OP_SUBTRACT", offset);
        case OpCode::OP_MULTIPLY: return simple_instruction("OP_MULTIPLY", offset);
        case OpCode::OP_DIVIDE: return simple_instruction("OP_DIVIDE", offset);
        case OpCode::OP_MODULO: return simple_instruction("OP_MODULO", offset);
        case OpCode::OP_NEGATE: return simple_instruction("OP_NEGATE", offset);

        case OpCode::OP_NOT: return simple_instruction("OP_NOT", offset);
        case OpCode::OP_EQUAL: return simple_instruction("OP_EQUAL", offset);
        case OpCode::OP_NOT_EQUAL: return simple_instruction("OP_NOT_EQUAL", offset);
        case OpCode::OP_GREATER: return simple_instruction("OP_GREATER", offset);
        case OpCode::OP_GREATER_EQUAL: return simple_instruction("OP_GREATER_EQUAL", offset);
        case OpCode::OP_LESS: return simple_instruction("OP_LESS", offset);
        case OpCode::OP_LESS_EQUAL: return simple_instruction("OP_LESS_EQUAL", offset);
        case OpCode::OP_BIT_AND: return simple_instruction("OP_BIT_AND", offset);
        case OpCode::OP_BIT_OR: return simple_instruction("OP_BIT_OR", offset);
        case OpCode::OP_BIT_XOR: return simple_instruction("OP_BIT_XOR", offset);
        case OpCode::OP_BIT_NOT: return simple_instruction("OP_BIT_NOT", offset);

        case OpCode::OP_JUMP: return jump_instruction("OP_JUMP", 1, *this, offset);
        case OpCode::OP_JUMP_IF_FALSE: return jump_instruction("OP_JUMP_IF_FALSE", 1, *this, offset);
        case OpCode::OP_LOOP: return jump_instruction("OP_LOOP", -1, *this, offset);

        case OpCode::OP_CALL: return byte_instruction("OP_CALL", *this, offset);
        case OpCode::OP_INVOKE_NATIVE: return byte_instruction("OP_INVOKE_NATIVE", *this, offset);
        case OpCode::OP_RETURN: return simple_instruction("OP_RETURN", offset);

        case OpCode::OP_PUSH_TRY: return jump_instruction("OP_PUSH_TRY", 1, *this, offset);
        case OpCode::OP_POP_TRY: return simple_instruction("OP_POP_TRY", offset);
        case OpCode::OP_RAISE: return simple_instruction("OP_RAISE", offset);
        case OpCode::OP_SYSTEM_CMD: return simple_instruction("OP_SYSTEM_CMD", offset);

        case OpCode::OP_LOAD_SCRIPT: return constant_instruction("OP_LOAD_SCRIPT", *this, offset);
        case OpCode::OP_IMPORT_MODULE: return constant_instruction("OP_IMPORT_MODULE", *this, offset);

        case OpCode::OP_CLASS: return constant_instruction("OP_CLASS", *this, offset);
        case OpCode::OP_METHOD: return constant_instruction("OP_METHOD", *this, offset);
        case OpCode::OP_SYSTEM: return constant_instruction("OP_SYSTEM", *this, offset);
        case OpCode::OP_INHERIT: return simple_instruction("OP_INHERIT", offset);
        case OpCode::OP_HALT: return simple_instruction("OP_HALT", offset);

        default:
            std::cout << "Unknown opcode " << static_cast<int>(instruction) << "\n";
            return offset + 1;
    }
}

} // namespace phoenix